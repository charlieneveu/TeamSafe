import { Switch, Route, Router } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/hooks/useAuth";
import { useIsMobile } from "@/hooks/use-mobile";
import { AlertUpdateProvider } from "@/lib/websocket";
import { Loader2 } from "lucide-react";

// Pages
import TeamAuthPage from "@/pages/team-auth-page";
import Dashboard from "@/pages/dashboard";
import TeamManagement from "@/pages/team-management";
import PromoteFirstUser from "@/pages/promote-first-user";
import ProfileSettings from "@/pages/profile-settings";
import Alerts from "@/pages/alerts";
import Help from "@/pages/help";
import NotFound from "@/pages/not-found";

// Layout Components
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";

function AppRouter() {
  const { user, isLoading } = useAuth();
  const isMobile = useIsMobile();

  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-2" />
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  // Check if this is a public route (password reset or email verification)
  if (window.location.pathname === '/reset-password' || window.location.pathname === '/verify-email') {
    return <TeamAuthPage />;
  }

  // Not authenticated - show team auth page
  if (!user) {
    return <TeamAuthPage />;
  }

  // Authenticated - show app with navigation
  return (
    <AlertUpdateProvider userId={user.id}>
      <div className="h-screen flex">
        {!isMobile ? (
          <>
            <Sidebar />
            <main className="flex-1 overflow-auto">
              <Switch>
                <Route path="/" component={Dashboard} />
                <Route path="/team-management" component={TeamManagement} />
                <Route path="/profile-settings" component={ProfileSettings} />
                <Route path="/promote-first-user" component={PromoteFirstUser} />
                <Route path="/alerts" component={Alerts} />
                <Route path="/help" component={Help} />

                <Route component={NotFound} />
              </Switch>
            </main>
          </>
        ) : (
          <div className="flex-1 flex flex-col">
            <MobileNav />
            <main className="flex-1 overflow-auto">
              <Switch>
                <Route path="/" component={Dashboard} />
                <Route path="/team-management" component={TeamManagement} />
                <Route path="/profile-settings" component={ProfileSettings} />
                <Route path="/promote-first-user" component={PromoteFirstUser} />
                <Route path="/alerts" component={Alerts} />
                <Route path="/help" component={Help} />

                <Route component={NotFound} />
              </Switch>
            </main>
          </div>
        )}
      </div>
    </AlertUpdateProvider>
  );
}


function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Router>
            <Toaster />
            <AppRouter />
          </Router>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
