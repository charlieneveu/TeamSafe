import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Crown, Shield } from "lucide-react";

export default function PromoteFirstUser() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const promoteMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("/api/promote-first-user", "POST");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Promoted to Duty Manager",
        description: "You are now a duty manager and can access team management features.",
      });
      // Redirect to team management after promotion
      setTimeout(() => {
        window.location.href = "/team-management";
      }, 2000);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to promote user.",
        variant: "destructive",
      });
    },
  });

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <Card className="w-full max-w-md" data-testid="card-promote-first-user">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Crown className="h-16 w-16 text-primary" />
          </div>
          <CardTitle>Become a Duty Manager</CardTitle>
          <CardDescription>
            It looks like this is a new TeamSafe system with no duty managers. 
            You can promote yourself to duty manager to start managing your team.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <div className="text-sm text-muted-foreground">
            <p className="mb-2">As a duty manager, you'll be able to:</p>
            <ul className="text-left space-y-1">
              <li>• View and manage all team members</li>
              <li>• Change user roles (clinician/duty manager)</li>
              <li>• Remove team members from the system</li>
              <li>• Access team management features</li>
            </ul>
          </div>
          
          <Button 
            onClick={() => promoteMutation.mutate()}
            disabled={promoteMutation.isPending}
            className="w-full"
            size="lg"
            data-testid="button-promote"
          >
            <Shield className="h-4 w-4 mr-2" />
            {promoteMutation.isPending ? "Promoting..." : "Become Duty Manager"}
          </Button>
          
          <p className="text-xs text-muted-foreground">
            This option is only available when there are no duty managers in the system.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}