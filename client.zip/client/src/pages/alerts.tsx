import { useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { shouldShowUnauthorizedToast } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, TriangleAlert, Clock, CheckCircle, Phone, Eye } from "lucide-react";
import type { Alert } from "@shared/schema";

export default function Alerts() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // No need for manual auth redirect - handled by App.tsx

  // Fetch alerts
  const { data: alerts = [], isLoading: alertsLoading } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
    enabled: !!user,
  });

  // Mark alert as read mutation
  const markAlertReadMutation = useMutation({
    mutationFn: async (alertId: string) => {
      return await apiRequest("PATCH", `/api/alerts/${alertId}/read`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
    },
    onError: (error) => {
      if (shouldShowUnauthorizedToast(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  // Mark alert as resolved mutation
  const markAlertResolvedMutation = useMutation({
    mutationFn: async (alertId: string) => {
      return await apiRequest("PATCH", `/api/alerts/${alertId}/resolve`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/team-status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/safety-status"] });
      toast({
        title: "Alert Resolved",
        description: "Alert has been marked as resolved.",
      });
    },
    onError: (error) => {
      if (shouldShowUnauthorizedToast(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to resolve alert. Please try again.",
        variant: "destructive",
      });
    },
  });


  // Refresh alerts
  const refreshAlerts = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p>Loading alerts...</p>
        </div>
      </div>
    );
  }

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${Math.floor(diffHours / 24)}d ago`;
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case "safety_overdue":
        return <TriangleAlert className="h-5 w-5" />;
      case "extended_visit":
        return <Clock className="h-5 w-5" />;
      default:
        return <TriangleAlert className="h-5 w-5" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-50 border-red-200 text-red-900";
      case "medium":
        return "bg-yellow-50 border-yellow-200 text-yellow-900";
      case "low":
        return "bg-blue-50 border-blue-200 text-blue-900";
      default:
        return "bg-gray-50 border-gray-200 text-gray-900";
    }
  };

  const activeAlerts = alerts.filter((alert) => !alert.isResolved);
  const resolvedAlerts = alerts.filter((alert) => alert.isResolved);

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold" data-testid="text-alerts-title">Alerts</h2>
          <p className="text-muted-foreground">Safety notifications and system alerts</p>
        </div>
        <Button 
          variant="outline"
          onClick={refreshAlerts}
          data-testid="button-refresh-alerts"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Active Alerts */}
      <Card className="mb-6" data-testid="card-active-alerts">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <TriangleAlert className="h-5 w-5 text-destructive" />
              <span>Active Alerts</span>
            </CardTitle>
            <Badge variant="destructive" data-testid="text-active-alerts-count">
              {activeAlerts.length}
            </Badge>
          </div>
          <CardDescription>
            Unresolved safety alerts requiring attention
          </CardDescription>
        </CardHeader>
        <CardContent>
          {alertsLoading ? (
            <div className="flex items-center justify-center py-8">
              <RefreshCw className="h-6 w-6 animate-spin" />
            </div>
          ) : activeAlerts.length === 0 ? (
            <div className="text-center py-8">
              <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
              <p className="text-muted-foreground">No active alerts</p>
              <p className="text-sm text-muted-foreground">All team members are safe</p>
            </div>
          ) : (
            <div className="space-y-4">
              {activeAlerts.map((alert: any) => (
                <div 
                  key={alert.id}
                  className="border rounded-lg p-4 bg-gray-50 border-gray-200"
                  data-testid={`card-alert-${alert.id}`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <div className="mt-1 text-gray-600">
                        {getAlertIcon(alert.type)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h4 className="font-semibold" data-testid={`text-alert-title-${alert.id}`}>
                            {alert.title}
                          </h4>
                          {!alert.isRead && (
                            <Badge variant="outline" className="text-xs">
                              NEW
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm mb-3" data-testid={`text-alert-description-${alert.id}`}>
                          {alert.description}
                        </p>
                        {alert.location && (
                          <p className="text-sm text-blue-600 mb-2" data-testid={`text-alert-location-${alert.id}`}>
                            📍 {alert.location}
                          </p>
                        )}
                        <p className="text-xs text-muted-foreground">
                          {formatTimeAgo(alert.createdAt)}
                        </p>
                        {(alert as any).user && (
                          <p className="text-xs text-muted-foreground mt-1" data-testid={`text-alert-user-${alert.id}`}>
                            For: {(alert as any).user.firstName} {(alert as any).user.lastName}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      {!alert.isRead && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => markAlertReadMutation.mutate(alert.id)}
                          data-testid={`button-mark-read-${alert.id}`}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      )}
                      {alert.type === "safety_overdue" && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          className="text-blue-600 hover:text-blue-800"
                          data-testid={`button-call-${alert.id}`}
                        >
                          <Phone className="h-4 w-4" />
                        </Button>
                      )}
                      <Button 
                        size="sm" 
                        onClick={() => markAlertResolvedMutation.mutate(alert.id)}
                        disabled={markAlertResolvedMutation.isPending}
                        data-testid={`button-resolve-${alert.id}`}
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Resolve
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Resolved Alerts */}
      {resolvedAlerts.length > 0 && (
        <Card data-testid="card-resolved-alerts">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span>Resolved Alerts</span>
              </CardTitle>
              <Badge variant="secondary" data-testid="text-resolved-alerts-count">
                {resolvedAlerts.length}
              </Badge>
            </div>
            <CardDescription>
              Recently resolved alerts and notifications
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {resolvedAlerts.slice(0, 10).map((alert: any) => (
                <div 
                  key={alert.id}
                  className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg"
                  data-testid={`card-resolved-alert-${alert.id}`}
                >
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <div>
                      <p className="font-medium text-green-900" data-testid={`text-resolved-alert-title-${alert.id}`}>
                        {alert.title}
                      </p>
                      <p className="text-sm text-green-700" data-testid={`text-resolved-alert-description-${alert.id}`}>
                        {alert.description}
                      </p>
                      {alert.location && (
                        <p className="text-sm text-green-600" data-testid={`text-resolved-alert-location-${alert.id}`}>
                          📍 {alert.location}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-green-600">
                      Resolved {formatTimeAgo(alert.resolvedAt)}
                    </p>
                    <p className="text-xs text-green-500">
                      Created {formatTimeAgo(alert.createdAt)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
