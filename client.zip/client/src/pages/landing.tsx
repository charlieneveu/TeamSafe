import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, MapPin, Users, AlertTriangle } from "lucide-react";
import teamSafeLogo from "@assets/teamsafe-logo.png";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-b from-primary/5 to-background">
        <div className="container mx-auto px-4 py-16 sm:py-24">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-3 mb-6">
              <img src={teamSafeLogo} alt="TeamSafe" className="h-12 w-12" />
              <h1 className="text-4xl font-bold text-foreground">TeamSafe</h1>
            </div>
            <h2 className="text-3xl sm:text-5xl font-bold text-foreground mb-6">
              Team Safety & Wellness
              <span className="text-primary block">Management System</span>
            </h2>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Keep your team safe and healthy with real-time location tracking, 
              automated safety alerts, and comprehensive wellness management.
            </p>
            <Button 
              size="lg" 
              className="text-lg px-8 py-3"
              onClick={() => window.location.href = '/api/login'}
              data-testid="button-login"
            >
              Sign In to Get Started
            </Button>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h3 className="text-3xl font-bold text-foreground mb-4">
            Comprehensive Safety Management
          </h3>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Everything you need to ensure the safety and wellness of team members 
            working in various professional settings.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="text-center">
              <MapPin className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>Visit Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">
                Log visit locations and expected durations with automatic 
                location detection for accurate tracking.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="text-center">
              <Shield className="h-12 w-12 text-success mx-auto mb-4" />
              <CardTitle>Safety Check-ins</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">
                Quick and easy safety confirmations to let your team know 
                you're safe at the end of each visit.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="text-center">
              <AlertTriangle className="h-12 w-12 text-warning mx-auto mb-4" />
              <CardTitle>Automated Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">
                Automatic notifications to duty managers when safety 
                check-ins are overdue or extended visits occur.
              </CardDescription>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="text-center">
              <Users className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>Team Dashboard</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-center">
                Real-time overview of all team members with color-coded 
                status indicators for instant situational awareness.
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Safety First Section */}
      <div className="bg-muted/50 py-16">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-3xl font-bold text-foreground mb-6">
            Safety First, Always
          </h3>
          <p className="text-muted-foreground text-lg mb-8 max-w-3xl mx-auto">
            TeamSafe was designed for teams working in various professional settings. 
            Our intuitive interface and reliable tracking ensure that safety and wellness 
            remain a priority without interfering with productivity.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="text-3xl font-bold text-success mb-2">24/7</div>
              <p className="text-muted-foreground">Continuous monitoring and alert system</p>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary mb-2">&lt; 30s</div>
              <p className="text-muted-foreground">Quick check-in process</p>
            </div>
            <div>
              <div className="text-3xl font-bold text-warning mb-2">Real-time</div>
              <p className="text-muted-foreground">Instant status updates and location tracking</p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t bg-background py-8">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <img src={teamSafeLogo} alt="TeamSafe" className="h-6 w-6" />
            <span className="font-semibold">TeamSafe</span>
          </div>
          <p className="text-muted-foreground">
            Keeping teams safe and healthy in their work environment
          </p>
        </div>
      </footer>
    </div>
  );
}
