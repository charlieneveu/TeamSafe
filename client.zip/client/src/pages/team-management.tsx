import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { shouldShowUnauthorizedToast } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { RefreshCw, Users, Shield, UserMinus, Crown, User as UserIcon, UserPlus, Phone, ChevronDown, Check } from "lucide-react";
import { createManualUserSchema, type User, type CreateManualUser, type Team } from "@shared/schema";

type TeamMembership = {
  id: string;
  teamId: string;
  role: string;
  team: Team;
  isActive: boolean;
};

export default function TeamManagement() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showAddUserDialog, setShowAddUserDialog] = useState(false);

  // Fetch user's team memberships for team switching
  const { data: memberships = [], isLoading: membershipsLoading } = useQuery<TeamMembership[]>({
    queryKey: ["/api/teams/memberships"],
    enabled: !!user,
  });

  // Switch team mutation
  const switchTeamMutation = useMutation({
    mutationFn: (teamId: string) => apiRequest('POST', '/api/teams/switch', { teamId }),
    onSuccess: async () => {
      toast({ 
        title: "Team switched!", 
        description: "You've switched to a different team." 
      });
      await queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/teams/memberships"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/teams/current"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/team-status"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/team-management"] });
      window.location.reload();
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to switch team", 
        description: error.message || "Could not switch teams",
        variant: "destructive" 
      });
    },
  });

  const activeTeam = memberships.find(m => m.isActive);

  // Form for adding new users
  const form = useForm<CreateManualUser>({
    resolver: zodResolver(createManualUserSchema),
    defaultValues: {
      username: "",
      password: "",
      email: "",
      firstName: "",
      lastName: "",
      role: "teamsafe_member",
    },
  });

  // No need for manual auth redirect - handled by App.tsx

  // All authenticated users can access team management

  // Fetch all team members
  const { data: teamMembers = [], isLoading: teamLoading } = useQuery<User[]>({
    queryKey: ["/api/team-management"],
    enabled: !!user,
  });

  // Update user role mutation
  const updateRoleMutation = useMutation({
    mutationFn: async ({ userId, role }: { userId: string; role: string }) => {
      await apiRequest("PATCH", `/api/team-management/${userId}/role`, { role });
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/team-management"] });
      queryClient.invalidateQueries({ queryKey: ["/api/team-status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/team/members"] });
      // If user changed their own role, also invalidate auth endpoints
      if (variables.userId === user?.id) {
        queryClient.invalidateQueries({ queryKey: ["/api/user"] });
        queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      }
      toast({
        title: "Role Updated",
        description: "User role has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      if (shouldShowUnauthorizedToast(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update user role. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Delete user mutation
  const deleteUserMutation = useMutation({
    mutationFn: async (userId: string) => {
      await apiRequest("DELETE", `/api/team-management/${userId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/team-management"] });
      queryClient.invalidateQueries({ queryKey: ["/api/team-status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/team/members"] });
      toast({
        title: "User Removed",
        description: "User has been removed from the team successfully.",
      });
    },
    onError: (error: Error) => {
      if (shouldShowUnauthorizedToast(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to remove user. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Add user mutation
  const addUserMutation = useMutation({
    mutationFn: async (userData: CreateManualUser) => {
      await apiRequest("POST", "/api/team-management/users", userData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/team-management"] });
      queryClient.invalidateQueries({ queryKey: ["/api/team-status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/team/members"] });
      toast({
        title: "Team Member Added",
        description: "New team member has been added successfully.",
      });
      setShowAddUserDialog(false);
      form.reset();
    },
    onError: (error: Error) => {
      if (shouldShowUnauthorizedToast(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to add team member. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleRoleChange = (userId: string, newRole: string) => {
    updateRoleMutation.mutate({ userId, role: newRole });
  };

  const handleDeleteUser = (userId: string) => {
    deleteUserMutation.mutate(userId);
  };

  const onSubmitAddUser = (data: CreateManualUser) => {
    addUserMutation.mutate(data);
  };

  const getRoleIcon = (role: string) => {
    return role === "duty_manager" ? <Crown className="h-4 w-4" /> : <UserIcon className="h-4 w-4" />;
  };

  const getRoleBadgeVariant = (role: string) => {
    return role === "duty_manager" ? "default" : "secondary";
  };


  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <RefreshCw className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Users className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold" data-testid="title-team-management">Team Management</h1>
            <p className="text-muted-foreground">Manage team members and roles</p>
          </div>
        </div>
        <div className="flex space-x-2">
          <Dialog open={showAddUserDialog} onOpenChange={setShowAddUserDialog}>
              <DialogTrigger asChild>
                <Button data-testid="button-add-team-member">
                  <UserPlus className="h-4 w-4 mr-2" />
                  Add Team Member
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Team Member</DialogTitle>
                  <DialogDescription>
                    Manually add a new team member to your TeamSafe system.
                  </DialogDescription>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmitAddUser)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="username"
                              {...field}
                              data-testid="input-add-user-username"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input
                              type="password"
                              placeholder="password"
                              {...field}
                              data-testid="input-add-user-password"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <Input
                              type="email"
                              placeholder="user@example.com"
                              {...field}
                              data-testid="input-add-user-email"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="firstName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>First Name</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="John"
                                {...field}
                                data-testid="input-add-user-firstName"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="lastName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Last Name</FormLabel>
                            <FormControl>
                              <Input
                                placeholder="Doe"
                                {...field}
                                data-testid="input-add-user-lastName"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormField
                      control={form.control}
                      name="role"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Role</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-add-user-role">
                                <SelectValue placeholder="Select a role" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="teamsafe_member">Team Member</SelectItem>
                              <SelectItem value="duty_manager">Duty Manager</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <DialogFooter>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setShowAddUserDialog(false)}
                        data-testid="button-cancel-add-user"
                      >
                        Cancel
                      </Button>
                      <Button 
                        type="submit" 
                        disabled={addUserMutation.isPending}
                        data-testid="button-submit-add-user"
                      >
                        {addUserMutation.isPending ? "Adding..." : "Add Team Member"}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          <Button 
            variant="outline" 
            onClick={() => queryClient.invalidateQueries({ queryKey: ["/api/team-management"] })}
            data-testid="button-refresh-team-management"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Team Switcher Section - only show if user has multiple teams */}
      {memberships.length > 1 && (
        <Card className="mb-6" data-testid="card-team-switcher">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center space-x-2">
              <Users className="h-5 w-5" />
              <span>Your Teams</span>
            </CardTitle>
            <CardDescription>
              You're a member of {memberships.length} teams. Click on a team to switch to it.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
              {memberships.map((membership) => (
                <button
                  key={membership.id}
                  onClick={() => !membership.isActive && switchTeamMutation.mutate(membership.teamId)}
                  disabled={membership.isActive || switchTeamMutation.isPending}
                  className={`p-4 rounded-lg border text-left transition-all ${
                    membership.isActive 
                      ? 'border-primary bg-primary/5 cursor-default' 
                      : 'border-border hover:border-primary hover:bg-accent cursor-pointer'
                  }`}
                  data-testid={`team-card-${membership.teamId}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium truncate">{membership.team.name}</span>
                    {membership.isActive && (
                      <Badge variant="default" className="ml-2 flex-shrink-0">
                        <Check className="h-3 w-3 mr-1" />
                        Active
                      </Badge>
                    )}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    <span className="font-mono text-xs bg-muted px-1.5 py-0.5 rounded">
                      {membership.team.teamCode}
                    </span>
                    <span className="ml-2">
                      {membership.role === "duty_manager" ? "Duty Manager" : "Member"}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Current Team Display - show when only in one team */}
      {memberships.length === 1 && activeTeam && (
        <Card className="mb-6" data-testid="card-current-team">
          <CardContent className="py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Users className="h-5 w-5 text-primary" />
                <div>
                  <span className="font-medium">{activeTeam.team.name}</span>
                  <span className="ml-2 font-mono text-xs bg-muted px-1.5 py-0.5 rounded">
                    {activeTeam.team.teamCode}
                  </span>
                </div>
              </div>
              <Badge variant="secondary">Only Team</Badge>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Add Team Members Info */}
      <Card className="mb-6 bg-blue-50 border-blue-200" data-testid="card-add-members-info">
        <CardHeader>
          <CardTitle className="text-blue-900">Adding Team Members</CardTitle>
        </CardHeader>
        <CardContent>
          <CardDescription className="text-blue-800">
            You can add team members in two ways:
          </CardDescription>
          <div className="mt-3 space-y-2">
            <div className="flex items-center space-x-2">
              <UserPlus className="h-4 w-4 text-blue-700" />
              <span className="text-blue-800 font-medium">Manual Addition:</span>
              <span className="text-blue-700">Use the "Add Team Member" button above to manually create accounts</span>
            </div>
            <div className="flex items-center space-x-2">
              <Shield className="h-4 w-4 text-blue-700" />
              <span className="text-blue-800 font-medium">Self Registration:</span>
              <span className="text-blue-700">Share the app URL and they'll be added automatically when they sign in</span>
            </div>
          </div>
          <div className="mt-3 p-2 bg-blue-100 rounded-md">
            <code className="text-sm text-blue-900" data-testid="text-app-url">
              {window.location.origin}
            </code>
          </div>
        </CardContent>
      </Card>

      {/* Team Members */}
      <Card data-testid="card-team-members">
        <CardHeader>
          <CardTitle>Team Members</CardTitle>
          <CardDescription>Manage user roles and remove team members</CardDescription>
        </CardHeader>
        <CardContent>
          {teamLoading ? (
            <div className="flex items-center justify-center py-8">
              <RefreshCw className="h-6 w-6 animate-spin" />
            </div>
          ) : teamMembers.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No team members found</p>
          ) : (
            <div className="space-y-4">
              {teamMembers.map((member) => (
                <div 
                  key={member.id} 
                  className="flex items-center justify-between p-4 border rounded-lg"
                  data-testid={`card-member-${member.id}`}
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-primary font-semibold">
                        {member.firstName?.[0] || "T"}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium" data-testid={`text-member-name-${member.id}`}>
                        {member.firstName && member.lastName 
                          ? `${member.firstName} ${member.lastName}`
                          : "Team Member"
                        }
                      </p>
                      <p className="text-sm text-muted-foreground" data-testid={`text-member-role-${member.id}`}>
                        {member.role === "duty_manager" ? "Duty Manager" : "Team Member"}
                      </p>
                      
                      {/* Contact Information */}
                      <div className="mt-2 space-y-1">
                        {member.workPhone && (
                          <p className="text-xs text-muted-foreground flex items-center space-x-1" data-testid={`text-work-phone-${member.id}`}>
                            <Phone className="h-3 w-3" />
                            <span>Work: {member.workPhone}</span>
                          </p>
                        )}
                        {!member.workPhone && (
                          <p className="text-xs text-muted-foreground/70">No phone number on file</p>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    {member.role === "duty_manager" && (
                      <Badge 
                        variant={getRoleBadgeVariant(member.role!)} 
                        className="flex items-center space-x-1"
                        data-testid={`badge-role-${member.id}`}
                      >
                        {getRoleIcon(member.role!)}
                        <span>Duty Manager</span>
                      </Badge>
                    )}
                    
                    {/* Role management for current user */}
                    {member.id === user?.id && (
                      <>
                        <Select
                          value={member.role}
                          onValueChange={(value) => handleRoleChange(member.id, value)}
                          disabled={updateRoleMutation.isPending}
                        >
                          <SelectTrigger className="w-40" data-testid={`select-role-${member.id}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="teamsafe_member">Team Member</SelectItem>
                            <SelectItem value="duty_manager">Duty Manager</SelectItem>
                          </SelectContent>
                        </Select>
                        <Badge variant="outline" data-testid="badge-current-user">
                          You
                        </Badge>
                      </>
                    )}
                    
                    {/* Role management for other users */}
                    {member.id !== user?.id && (
                      <>
                        <Select
                          value={member.role}
                          onValueChange={(value) => handleRoleChange(member.id, value)}
                          disabled={updateRoleMutation.isPending}
                        >
                          <SelectTrigger className="w-40" data-testid={`select-role-${member.id}`}>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="teamsafe_member">Team Member</SelectItem>
                            <SelectItem value="duty_manager">Duty Manager</SelectItem>
                          </SelectContent>
                        </Select>
                        
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button 
                              variant="outline" 
                              size="sm"
                              disabled={deleteUserMutation.isPending}
                              data-testid={`button-delete-${member.id}`}
                            >
                              <UserMinus className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Remove Team Member</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to remove {member.firstName && member.lastName 
                                  ? `${member.firstName} ${member.lastName}`
                                  : member.email
                                } from the team? This action cannot be undone and will delete all their data including visits, alerts, and safety status.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction 
                                onClick={() => handleDeleteUser(member.id)}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                Remove
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}