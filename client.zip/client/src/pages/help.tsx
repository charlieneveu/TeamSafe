import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { 
  HelpCircle, 
  Shield, 
  MapPin, 
  Users, 
  Bell, 
  Clock, 
  AlertTriangle,
  CheckCircle,
  Building,
  UserPlus,
  Settings,
  LogOut
} from "lucide-react";

export default function Help() {
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="flex items-center space-x-3 mb-6">
        <HelpCircle className="h-8 w-8 text-primary" />
        <div>
          <h1 className="text-3xl font-bold" data-testid="title-help">Help & Guide</h1>
          <p className="text-muted-foreground">Learn how to use TeamSafe</p>
        </div>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Welcome to TeamSafe</CardTitle>
          <CardDescription>
            TeamSafe helps teams stay connected and safe while working. Here's everything you need to know to get started.
          </CardDescription>
        </CardHeader>
      </Card>

      <Accordion type="single" collapsible className="space-y-4">
        <AccordionItem value="getting-started" className="border rounded-lg px-4">
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center space-x-3">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <span className="font-medium">Getting Started</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-2 pb-4">
            <div className="space-y-3 text-muted-foreground">
              <p><strong>1. Create an Account:</strong> Sign up with your email address and verify it through the link sent to your inbox.</p>
              <p><strong>2. Join or Create a Team:</strong> After signing in, you can join an existing team using a team code, search for teams, or create your own team.</p>
              <p><strong>3. Set Up Your Profile:</strong> Go to Profile Settings to add your name, work phone, and choose your role.</p>
              <p><strong>4. You're Ready!</strong> Start using the dashboard to check in, log visits, and stay connected with your team.</p>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="dashboard" className="border rounded-lg px-4">
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center space-x-3">
              <Shield className="h-5 w-5 text-blue-600" />
              <span className="font-medium">Using the Dashboard</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-2 pb-4">
            <div className="space-y-3 text-muted-foreground">
              <p><strong>Your Current Status:</strong> Shows your safety status and work location. Use the toggle to switch between "On-site" and "Remote".</p>
              <p><strong>Quick Actions:</strong></p>
              <ul className="list-disc list-inside ml-4 space-y-1">
                <li><strong>Safety Check-in:</strong> Tap to confirm you're safe. This also completes any active visits.</li>
                <li><strong>Start Visit:</strong> Log when you're going to meet someone or visit a location.</li>
                <li><strong>Emergency Alert:</strong> Use in emergencies to immediately notify your duty manager and team.</li>
              </ul>
              <p><strong>Duty Manager Contact:</strong> Quick access to call your current duty manager.</p>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="visits" className="border rounded-lg px-4">
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center space-x-3">
              <MapPin className="h-5 w-5 text-yellow-600" />
              <span className="font-medium">Logging Visits</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-2 pb-4">
            <div className="space-y-3 text-muted-foreground">
              <p><strong>Starting a Visit:</strong> Click "Start Visit" and enter details about where you're going and how long you expect to be.</p>
              <p><strong>During a Visit:</strong> Your status will show as "Visiting" so your team knows you're out.</p>
              <p><strong>Completing a Visit:</strong> Use "Safety Check-in" when you're done to mark the visit as complete and confirm you're safe.</p>
              <p><strong>Overdue Visits:</strong> If your visit runs longer than expected, your status will change to "Overdue" to alert your team.</p>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="team-status" className="border rounded-lg px-4">
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center space-x-3">
              <Users className="h-5 w-5 text-purple-600" />
              <span className="font-medium">Team Status & Members</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-2 pb-4">
            <div className="space-y-3 text-muted-foreground">
              <p><strong>Team Members Tab:</strong> View all members of your current team, their work locations, and contact information.</p>
              <p><strong>Active Team Status Tab:</strong> See team members who are currently on visits or need attention.</p>
              <p><strong>Status Colors:</strong></p>
              <ul className="list-disc list-inside ml-4 space-y-1">
                <li><span className="text-green-600 font-medium">Green (Safe):</span> Member is checked in and safe</li>
                <li><span className="text-yellow-600 font-medium">Yellow (Visiting):</span> Member is currently on a visit</li>
                <li><span className="text-red-600 font-medium">Red (Overdue/Emergency):</span> Member's visit is overdue or they've raised an emergency</li>
              </ul>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="emergency" className="border rounded-lg px-4">
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center space-x-3">
              <AlertTriangle className="h-5 w-5 text-red-600" />
              <span className="font-medium">Emergency Alerts</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-2 pb-4">
            <div className="space-y-3 text-muted-foreground">
              <p><strong>Raising an Emergency:</strong> If you're in danger or need immediate help, use the "Emergency Alert" button on the dashboard.</p>
              <p><strong>What Happens:</strong></p>
              <ul className="list-disc list-inside ml-4 space-y-1">
                <li>Your status immediately changes to "Emergency"</li>
                <li>Your duty manager is notified</li>
                <li>Your last known location is shared with your team</li>
                <li>An alert appears on everyone's dashboard</li>
              </ul>
              <p><strong>Clearing an Emergency:</strong> Once safe, use "Safety Check-in" to clear the emergency status.</p>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="teams" className="border rounded-lg px-4">
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center space-x-3">
              <Building className="h-5 w-5 text-indigo-600" />
              <span className="font-medium">Managing Teams</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-2 pb-4">
            <div className="space-y-3 text-muted-foreground">
              <p><strong>Joining a Team:</strong> Use a 6-character team code shared by your team leader, or search for teams by name.</p>
              <p><strong>Creating a Team:</strong> Create your own team and share the generated team code with others to join.</p>
              <p><strong>Switching Teams:</strong> If you're in multiple teams, use the team switcher in the sidebar or the Team Management page to switch between them.</p>
              <p><strong>Team Codes:</strong> Each team has a unique 6-character code (like "ABC123") that members use to join.</p>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="roles" className="border rounded-lg px-4">
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center space-x-3">
              <UserPlus className="h-5 w-5 text-orange-600" />
              <span className="font-medium">Roles & Permissions</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-2 pb-4">
            <div className="space-y-3 text-muted-foreground">
              <p><strong>Team Member:</strong> Can check in, log visits, raise emergencies, and view team status.</p>
              <p><strong>Duty Manager:</strong> All team member abilities plus:</p>
              <ul className="list-disc list-inside ml-4 space-y-1">
                <li>Receive emergency notifications</li>
                <li>Add and remove team members</li>
                <li>Change member roles</li>
                <li>Manage team settings</li>
              </ul>
              <p><strong>Changing Your Role:</strong> You can change your role in Profile Settings, but some teams may restrict this.</p>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="work-location" className="border rounded-lg px-4">
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center space-x-3">
              <Clock className="h-5 w-5 text-teal-600" />
              <span className="font-medium">Work Location</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-2 pb-4">
            <div className="space-y-3 text-muted-foreground">
              <p><strong>On-site:</strong> Select this when you're working at your usual work location.</p>
              <p><strong>Remote:</strong> Select this when you're working from home or another location.</p>
              <p><strong>Why It Matters:</strong> Your work location helps your team know where you're based, which is useful for coordination and in case of emergencies.</p>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="profile" className="border rounded-lg px-4">
          <AccordionTrigger className="hover:no-underline">
            <div className="flex items-center space-x-3">
              <Settings className="h-5 w-5 text-gray-600" />
              <span className="font-medium">Profile Settings</span>
            </div>
          </AccordionTrigger>
          <AccordionContent className="pt-2 pb-4">
            <div className="space-y-3 text-muted-foreground">
              <p><strong>Personal Information:</strong> Update your name and email address.</p>
              <p><strong>Work Phone:</strong> Add your work phone number so team members can contact you.</p>
              <p><strong>Role:</strong> Change your role between Team Member and Duty Manager.</p>
              <p><strong>Password:</strong> Change your password for security.</p>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <Card className="mt-6">
        <CardContent className="pt-6">
          <div className="flex items-center space-x-3">
            <Bell className="h-5 w-5 text-primary" />
            <div>
              <p className="font-medium">Need More Help?</p>
              <p className="text-sm text-muted-foreground">
                Contact your duty manager or team administrator if you have questions not covered here.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
