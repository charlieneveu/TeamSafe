import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import StatusIndicator from "@/components/status-indicator";
import VisitModal from "@/components/visit-modal";
import { Clock, Shield, RefreshCw, Plus, CheckCircle, AlertCircle } from "lucide-react";
import type { Visit } from "@shared/schema";

export default function Visits() {
  const { user, isLoading: authLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showVisitModal, setShowVisitModal] = useState(false);
  const [activeTab, setActiveTab] = useState("in-progress");

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  // Fetch visits
  const { data: visits = [], isLoading: visitsLoading } = useQuery<Visit[]>({
    queryKey: ["/api/visits"],
    enabled: isAuthenticated,
  });

  // Fetch active visit
  const { data: activeVisit } = useQuery<Visit | null>({
    queryKey: ["/api/visits/active"],
    enabled: isAuthenticated,
  });

  // Complete visit mutation
  const completeVisitMutation = useMutation({
    mutationFn: async (visitId: string) => {
      return await apiRequest("PATCH", `/api/visits/${visitId}/complete`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/visits"] });
      queryClient.invalidateQueries({ queryKey: ["/api/visits/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/safety-status"] });
      toast({
        title: "Visit Completed",
        description: "Visit has been marked as completed and you're now safe.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to complete visit. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p>Loading visits...</p>
        </div>
      </div>
    );
  }

  const formatTime = (dateString: string) => {
    if (!dateString) return "N/A";
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return "N/A";
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
    });
  };


  // Filter visits by status
  const inProgressVisits = visits.filter(visit => visit.status === "active" || visit.status === "overdue");
  const completedVisits = visits.filter(visit => visit.status === "completed");

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold" data-testid="title-visits">Visit Tracking</h1>
          <p className="text-muted-foreground">Monitor your visits and mark them complete when done</p>
        </div>
        <Button 
          onClick={() => setShowVisitModal(true)}
          data-testid="button-start-visit"
        >
          <Plus className="h-4 w-4 mr-2" />
          Start Visit
        </Button>
      </div>

      {/* Tabbed Interface */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger 
            value="in-progress" 
            className="flex items-center space-x-2 data-[state=active]:bg-red-100 data-[state=active]:text-red-800"
            data-testid="tab-in-progress"
          >
            <AlertCircle className="h-4 w-4" />
            <span>In Progress</span>
            {inProgressVisits.length > 0 && (
              <Badge variant="secondary" className="ml-2 bg-red-100 text-red-800">
                {inProgressVisits.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger 
            value="completed" 
            className="flex items-center space-x-2 data-[state=active]:bg-green-100 data-[state=active]:text-green-800"
            data-testid="tab-completed"
          >
            <CheckCircle className="h-4 w-4" />
            <span>Completed</span>
            {completedVisits.length > 0 && (
              <Badge variant="secondary" className="ml-2 bg-green-100 text-green-800">
                {completedVisits.length}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        {/* In Progress Visits Tab */}
        <TabsContent value="in-progress" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-red-700">
                <AlertCircle className="h-5 w-5" />
                <span>Visits in Progress</span>
              </CardTitle>
              <CardDescription>
                Complete your visits when finished to confirm your safety
              </CardDescription>
            </CardHeader>
            <CardContent>
              {visitsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <RefreshCw className="h-6 w-6 animate-spin" />
                </div>
              ) : inProgressVisits.length === 0 ? (
                <div className="text-center py-8">
                  <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                  <p className="text-muted-foreground">All visits completed!</p>
                  <p className="text-sm text-muted-foreground">Start a new visit to begin tracking</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {inProgressVisits.map((visit) => (
                    <div 
                      key={visit.id} 
                      className="flex items-center justify-between p-4 border border-red-200 rounded-lg bg-red-50"
                      data-testid={`card-visit-${visit.id}`}
                    >
                      <div className="flex items-center space-x-3">
                        <StatusIndicator status={visit.status} />
                        <div>
                          <p className="font-medium" data-testid={`text-visit-patient-${visit.id}`}>
                            Visit in progress
                          </p>
                          <p className="text-sm text-muted-foreground">
                            Started: {visit.startTime ? formatTime(visit.startTime.toString()) : "N/A"} on {visit.startTime ? formatDate(visit.startTime.toString()) : "N/A"}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="text-right">
                          <Badge variant={visit.status === "overdue" ? "destructive" : "secondary"}>
                            {visit.status === "overdue" ? "Overdue" : "Active"}
                          </Badge>
                        </div>
                        <Button 
                          onClick={() => completeVisitMutation.mutate(visit.id)}
                          disabled={completeVisitMutation.isPending}
                          variant="default"
                          size="sm"
                          className="bg-green-600 hover:bg-green-700 text-white"
                          data-testid={`button-complete-visit-${visit.id}`}
                        >
                          <Shield className="h-4 w-4 mr-2" />
                          Complete
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Completed Visits Tab */}
        <TabsContent value="completed" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 text-green-700">
                <CheckCircle className="h-5 w-5" />
                <span>Completed Visits</span>
              </CardTitle>
              <CardDescription>
                Your visit history - all safely completed
              </CardDescription>
            </CardHeader>
            <CardContent>
              {visitsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <RefreshCw className="h-6 w-6 animate-spin" />
                </div>
              ) : completedVisits.length === 0 ? (
                <div className="text-center py-8">
                  <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No completed visits yet</p>
                  <p className="text-sm text-muted-foreground">Complete your first visit to see it here</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {completedVisits.map((visit) => (
                    <div 
                      key={visit.id} 
                      className="flex items-center justify-between p-4 border border-green-200 rounded-lg bg-green-50"
                      data-testid={`card-visit-${visit.id}`}
                    >
                      <div className="flex items-center space-x-3">
                        <StatusIndicator status={visit.status} />
                        <div>
                          <p className="font-medium" data-testid={`text-visit-patient-${visit.id}`}>
                            Completed visit
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {visit.startTime ? formatTime(visit.startTime.toString()) : "N/A"} - {visit.endTime ? formatTime(visit.endTime.toString()) : "N/A"} on {visit.startTime ? formatDate(visit.startTime.toString()) : "N/A"}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          Completed
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Visit Modal */}
      <VisitModal 
        open={showVisitModal}
        onOpenChange={setShowVisitModal}
        onVisitCreated={() => {
          queryClient.invalidateQueries({ queryKey: ["/api/visits"] });
          queryClient.invalidateQueries({ queryKey: ["/api/visits/active"] });
        }}
      />
    </div>
  );
}