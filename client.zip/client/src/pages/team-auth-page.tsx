import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  loginSchema, 
  registerIndividualSchema,
  requestPasswordResetSchema,
  resetPasswordSchema,
  type Login, 
  type RegisterIndividual,
  type RequestPasswordReset,
  type ResetPassword
} from "@shared/schema";
import { Shield, Mail, KeyRound, UserPlus, LogIn, HelpCircle, CheckCircle, Loader2 } from "lucide-react";

export default function TeamAuthPage() {
  const [activeTab, setActiveTab] = useState("login");
  const [isPasswordReset, setIsPasswordReset] = useState(false);
  const [resetEmailSent, setResetEmailSent] = useState(false);
  const [verificationPending, setVerificationPending] = useState(false);
  const [verificationEmail, setVerificationEmail] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationSuccess, setVerificationSuccess] = useState(false);
  const { toast } = useToast();

  // Get token from URL if present
  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get('token');
  const isVerifyEmailPage = window.location.pathname === '/verify-email';
  const isResetPasswordPage = window.location.pathname === '/reset-password';
  // Only use token for its intended purpose based on the page
  const resetToken = isResetPasswordPage ? token : null;
  const verifyToken = isVerifyEmailPage ? token : null;

  // Handle email verification on page load
  useEffect(() => {
    if (isVerifyEmailPage && verifyToken) {
      setIsVerifying(true);
      fetch(`/api/auth/verify-email?token=${verifyToken}`)
        .then(res => res.json())
        .then(data => {
          if (data.verified) {
            setVerificationSuccess(true);
            toast({ 
              title: "Email Verified!", 
              description: "Your account is now active. You can log in." 
            });
          } else {
            toast({ 
              title: "Verification Failed", 
              description: data.message || "Invalid or expired token",
              variant: "destructive" 
            });
          }
        })
        .catch(() => {
          toast({ 
            title: "Verification Failed", 
            description: "Something went wrong. Please try again.",
            variant: "destructive" 
          });
        })
        .finally(() => setIsVerifying(false));
    }
  }, [isVerifyEmailPage, verifyToken]);

  const loginForm = useForm<Login>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "" },
  });

  const registerForm = useForm<RegisterIndividual>({
    resolver: zodResolver(registerIndividualSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      firstName: "",
      lastName: "",
      role: "teamsafe_member",
    },
  });

  const passwordResetForm = useForm<RequestPasswordReset>({
    resolver: zodResolver(requestPasswordResetSchema),
    defaultValues: { email: "" },
  });

  const resetPasswordForm = useForm<ResetPassword>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: { token: resetToken || "", newPassword: "" },
  });

  const loginMutation = useMutation({
    mutationFn: (data: Login) => apiRequest('POST', '/api/auth/login', data),
    onSuccess: () => {
      // Invalidate user query to refresh authentication state
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({ title: "Welcome back!", description: "Successfully logged in." });
      window.location.href = "/";
    },
    onError: (error: any) => {
      // Check if this is a verification required error
      if (error.requiresVerification) {
        setVerificationPending(true);
        setVerificationEmail(error.email || "");
        toast({ 
          title: "Email Verification Required", 
          description: "Please click the button below to send a verification link to your email.",
          variant: "destructive" 
        });
      } else {
        toast({ 
          title: "Login failed", 
          description: error.message || "Invalid email or password",
          variant: "destructive" 
        });
      }
    },
  });

  const registerMutation = useMutation({
    mutationFn: (data: RegisterIndividual) => apiRequest('POST', '/api/auth/register-individual', data),
    onSuccess: (response: any, submittedData: RegisterIndividual) => {
      if (response.requiresVerification) {
        const email = submittedData.email;
        setVerificationPending(true);
        setVerificationEmail(email);
        setActiveTab("login");
        
        if (response.emailSent) {
          toast({ 
            title: "Account Created!", 
            description: "We've sent a verification link to your email. Please check your inbox (and spam folder).",
            duration: 10000
          });
        } else {
          toast({ 
            title: "Account Created!", 
            description: "We had trouble sending the verification email. Click 'Resend Verification Email' below.",
            duration: 10000,
            variant: "destructive"
          });
          setTimeout(() => {
            resendVerificationMutation.mutate(email);
          }, 2000);
        }
      } else {
        queryClient.invalidateQueries({ queryKey: ["/api/user"] });
        toast({ title: "Welcome to TeamSafe!", description: "Account created successfully." });
        window.location.href = "/";
      }
    },
    onError: (error: any) => {
      toast({ 
        title: "Registration failed", 
        description: error.message || "Failed to create account",
        variant: "destructive" 
      });
    },
  });

  const resendVerificationMutation = useMutation({
    mutationFn: (email: string) => apiRequest('POST', '/api/auth/resend-verification', { email }),
    onSuccess: () => {
      toast({ 
        title: "Verification Email Sent!", 
        description: "Please check your inbox (and spam folder) for the verification link.",
        duration: 8000
      });
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to send", 
        description: error.message || "Please try again later.",
        variant: "destructive" 
      });
    },
  });

  const passwordResetMutation = useMutation({
    mutationFn: (data: RequestPasswordReset) => apiRequest('POST', '/api/auth/reset-password-request', data),
    onSuccess: () => {
      toast({ 
        title: "📧 Password Reset Email Sent!", 
        description: "Check your email inbox for reset instructions. The link will expire in 1 hour for security.",
        duration: 8000 // Show toast for 8 seconds - longer visibility
      });
      passwordResetForm.reset(); // Clear the form state
      setResetEmailSent(true); // Show success state
      
      // Wait 6 seconds before returning to login so user can read the success message
      setTimeout(() => {
        setIsPasswordReset(false);
        setResetEmailSent(false);
      }, 6000);
    },
    onError: (error: any) => {
      toast({ 
        title: "❌ Reset Request Failed", 
        description: error.message || "Failed to send reset email. Please try again.",
        variant: "destructive" 
      });
    },
  });

  const resetPasswordMutation = useMutation({
    mutationFn: (data: ResetPassword) => apiRequest('POST', '/api/auth/reset-password', data),
    onSuccess: async (response: any) => {
      // Show immediate success feedback
      toast({ 
        title: "🎉 Password Changed Successfully!", 
        description: "Logging you in and redirecting to dashboard..." 
      });

      // Auto-login the user with the reset token response
      if (response.autoLogin) {
        // Invalidate user query to refresh authentication state
        queryClient.invalidateQueries({ queryKey: ["/api/user"] });
        
        // Brief delay to show success message, then redirect
        setTimeout(() => {
          window.location.href = "/";
        }, 1500);
      } else {
        // Fallback to login tab if auto-login isn't available
        setTimeout(() => {
          setActiveTab("login");
        }, 1500);
      }
    },
    onError: (error: any) => {
      toast({ 
        title: "❌ Password Reset Failed", 
        description: error.message || "Invalid or expired reset token. Please request a new reset link.",
        variant: "destructive" 
      });
    },
  });

  if (resetToken && !isPasswordReset) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto h-12 w-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
              <KeyRound className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
            <CardTitle className="text-2xl">Reset Password</CardTitle>
            <CardDescription>Enter your new password</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...resetPasswordForm}>
              <form onSubmit={resetPasswordForm.handleSubmit((data) => resetPasswordMutation.mutate(data))} className="space-y-4">
                <FormField
                  control={resetPasswordForm.control}
                  name="newPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>New Password</FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="Enter new password"
                          data-testid="input-new-password"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={resetPasswordMutation.isPending}
                  data-testid="button-reset-password"
                >
                  {resetPasswordMutation.isPending ? "Resetting..." : "Reset Password"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isPasswordReset) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto h-12 w-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
              <Mail className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
            <CardTitle className="text-2xl">
              {resetEmailSent ? "📧 Email Sent!" : "Forgot Password?"}
            </CardTitle>
            <CardDescription>
              {resetEmailSent 
                ? "Check your email inbox for reset instructions" 
                : "Enter your email to receive reset instructions"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {resetEmailSent ? (
              <div className="space-y-4 text-center">
                <div className="p-4 bg-green-50 dark:bg-green-950 rounded-lg border border-green-200 dark:border-green-800">
                  <div className="text-green-800 dark:text-green-200">
                    <p className="font-medium">Password reset email sent successfully!</p>
                    <p className="text-sm mt-2">
                      Check your email inbox for reset instructions. The link will expire in 1 hour for security.
                    </p>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">
                  You'll be returned to the login page in a few seconds...
                </p>
                <Button 
                  type="button" 
                  variant="outline" 
                  className="w-full" 
                  onClick={() => {
                    setIsPasswordReset(false);
                    setResetEmailSent(false);
                  }}
                  data-testid="button-back-to-login-after-success"
                >
                  Back to Login Now
                </Button>
              </div>
            ) : (
              <Form {...passwordResetForm}>
                <form onSubmit={passwordResetForm.handleSubmit((data) => passwordResetMutation.mutate(data))} className="space-y-4">
                  <FormField
                    control={passwordResetForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input
                            type="email"
                            placeholder="Enter your email"
                            data-testid="input-reset-email"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={passwordResetMutation.isPending}
                    data-testid="button-send-reset"
                  >
                    {passwordResetMutation.isPending ? "Sending..." : "Send Reset Email"}
                  </Button>
                  <Button 
                    type="button" 
                    variant="ghost" 
                    className="w-full" 
                    onClick={() => setIsPasswordReset(false)}
                    data-testid="button-back-to-login"
                  >
                    Back to Login
                  </Button>
                </form>
              </Form>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  // Show email verification page
  if (isVerifyEmailPage) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto h-12 w-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
              <Shield className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
            <CardTitle className="text-2xl">Email Verification</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            {isVerifying ? (
              <div className="py-8">
                <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
                <p>Verifying your email...</p>
              </div>
            ) : verificationSuccess ? (
              <div className="py-8">
                <CheckCircle className="h-12 w-12 mx-auto mb-4 text-green-600" />
                <h3 className="text-lg font-semibold mb-2">Email Verified!</h3>
                <p className="text-muted-foreground mb-6">Your account is now active.</p>
                <Button onClick={() => window.location.href = '/auth'} className="w-full">
                  Go to Login
                </Button>
              </div>
            ) : (
              <div className="py-8">
                <Mail className="h-12 w-12 mx-auto mb-4 text-red-500" />
                <h3 className="text-lg font-semibold mb-2">Verification Failed</h3>
                <p className="text-muted-foreground mb-6">The verification link may be invalid or expired.</p>
                <Button onClick={() => window.location.href = '/auth'} variant="outline" className="w-full">
                  Back to Login
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto h-12 w-12 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
            <Shield className="h-6 w-6 text-blue-600 dark:text-blue-400" />
          </div>
          <CardTitle className="text-2xl">TeamSafe</CardTitle>
          <CardDescription>Secure team safety management platform</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Verification pending notice */}
          {verificationPending && (
            <div className="mb-6 p-4 bg-yellow-50 dark:bg-yellow-950 rounded-lg border border-yellow-200 dark:border-yellow-800">
              <div className="flex items-center gap-2 mb-2">
                <Mail className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
                <span className="text-sm font-medium text-yellow-900 dark:text-yellow-100">Email Verification Required</span>
              </div>
              <p className="text-xs text-yellow-700 dark:text-yellow-300 mb-3">
                We've sent a verification link to <strong>{verificationEmail}</strong>. 
                Please check your inbox (and spam folder). Didn't receive it? Click below to resend.
              </p>
              <Button 
                variant="default" 
                size="sm" 
                onClick={() => resendVerificationMutation.mutate(verificationEmail)}
                disabled={resendVerificationMutation.isPending}
                className="w-full bg-yellow-600 hover:bg-yellow-700 text-white"
              >
                {resendVerificationMutation.isPending ? (
                  <>
                    <Loader2 className="h-3 w-3 mr-2 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Mail className="h-3 w-3 mr-2" />
                    Resend Verification Email
                  </>
                )}
              </Button>
            </div>
          )}

          {/* Quick guidance section */}
          {!verificationPending && (
            <div className="mb-6 p-4 bg-blue-50 dark:bg-blue-950 rounded-lg border border-blue-200 dark:border-blue-800">
              <div className="flex items-center gap-2 mb-2">
                <HelpCircle className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                <span className="text-sm font-medium text-blue-900 dark:text-blue-100">Quick Guide</span>
              </div>
              <div className="text-xs text-blue-700 dark:text-blue-300 space-y-1">
                <div><strong>Existing user?</strong> Use Login</div>
                <div><strong>New user?</strong> Create an account to get started</div>
              </div>
            </div>
          )}

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login" data-testid="tab-login" className="flex items-center gap-1">
                <LogIn className="h-3 w-3" />
                Login
              </TabsTrigger>
              <TabsTrigger value="register" data-testid="tab-register" className="flex items-center gap-1">
                <UserPlus className="h-3 w-3" />
                Register
              </TabsTrigger>
            </TabsList>

            <TabsContent value="login" className="space-y-4">
              <div className="text-center text-sm text-muted-foreground mb-4">
                <LogIn className="h-8 w-8 mx-auto mb-2" />
                Sign in with your existing account
              </div>
              <Form {...loginForm}>
                <form onSubmit={loginForm.handleSubmit((data) => loginMutation.mutate(data))} className="space-y-4">
                  <FormField
                    control={loginForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input
                            type="email"
                            placeholder="Enter your email"
                            data-testid="input-login-email"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={loginForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input
                            type="password"
                            placeholder="Enter your password"
                            data-testid="input-login-password"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={loginMutation.isPending}
                    data-testid="button-login"
                  >
                    {loginMutation.isPending ? "Signing in..." : "Sign In"}
                  </Button>
                  <Button 
                    type="button" 
                    variant="link" 
                    className="w-full text-sm" 
                    onClick={() => setIsPasswordReset(true)}
                    data-testid="link-forgot-password"
                  >
                    Forgot your password?
                  </Button>
                </form>
              </Form>
            </TabsContent>

            <TabsContent value="register" className="space-y-4">
              <div className="text-center text-sm text-muted-foreground mb-4">
                <UserPlus className="h-8 w-8 mx-auto mb-2" />
                Create your personal account to get started
              </div>
              <Form {...registerForm}>
                <form onSubmit={registerForm.handleSubmit((data) => registerMutation.mutate(data))} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={registerForm.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>First Name</FormLabel>
                          <FormControl>
                            <Input placeholder="First name" data-testid="input-first-name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={registerForm.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Last Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Last name" data-testid="input-last-name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={registerForm.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Username</FormLabel>
                        <FormControl>
                          <Input placeholder="Choose a username" data-testid="input-username" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={registerForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="Enter your email" data-testid="input-email" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={registerForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="Create a password" data-testid="input-password" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={registerMutation.isPending}
                    data-testid="button-register"
                  >
                    {registerMutation.isPending ? "Creating account..." : "Create Account"}
                  </Button>
                </form>
              </Form>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}