import { useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { shouldShowUnauthorizedToast } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { createTeamSchema, joinTeamSchema, searchTeamsSchema } from "@shared/schema";
import type { CreateTeam, JoinTeam, SearchTeams, Team } from "@shared/schema";
import StatusIndicator from "@/components/status-indicator";
import VisitModal from "@/components/visit-modal";
import EmergencyModal from "@/components/emergency-modal";
import { useState } from "react";
import { Shield, MapPin, RefreshCw, Phone, Eye, Clock, TriangleAlert, CheckCircle, Users, Search, UserPlus, Building, LogOut, Settings } from "lucide-react";
import type { User, Visit, SafetyStatus, Alert } from "@shared/schema";

export default function Dashboard() {
  const { user, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showVisitModal, setShowVisitModal] = useState(false);
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const [showTeamManagement, setShowTeamManagement] = useState(false);

  // If user is authenticated but has no team, show team joining interface
  if (user && !user.teamId) {
    return <TeamJoiningDashboard user={user} onTeamJoined={() => window.location.reload()} />;
  }

  // No need for manual auth redirect - handled by App.tsx

  // Fetch current safety status
  const { data: safetyStatus, isLoading: statusLoading } = useQuery<SafetyStatus>({
    queryKey: ["/api/safety-status"],
    enabled: !!user,
  });

  // Fetch active visit
  const { data: activeVisit } = useQuery<Visit | null>({
    queryKey: ["/api/visits/active"],
    enabled: !!user,
  });

  // Fetch team status with auto-refresh every 30 seconds
  const { data: teamStatus = [], isLoading: teamLoading, isFetching: teamFetching } = useQuery<(User & { safetyStatus?: SafetyStatus })[]>({
    queryKey: ["/api/team-status"],
    enabled: !!user,
    refetchInterval: 30000, // Refresh every 30 seconds for real-time updates
    refetchIntervalInBackground: false, // Only refresh when tab is active
  });

  // Fetch alerts with auto-refresh
  const { data: alerts = [], isLoading: alertsLoading } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
    enabled: !!user,
    refetchInterval: 30000, // Refresh every 30 seconds
    refetchIntervalInBackground: false,
  });

  // Quick safety check-in mutation - now also completes active visits
  const safetyCheckMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("PATCH", "/api/safety-status/safe", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/safety-status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/team-status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/visits"] });
      queryClient.invalidateQueries({ queryKey: ["/api/visits/active"] });
      toast({
        title: "Safety Check Complete",
        description: activeVisit 
          ? "You've been marked as safe and your visit has been completed!"
          : "You've been marked as safe. Thank you for checking in!",
      });
    },
    onError: (error) => {
      if (shouldShowUnauthorizedToast(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to update safety status. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update work location mutation
  const updateLocationMutation = useMutation({
    mutationFn: async (workLocation: "on-site" | "remote") => {
      return await apiRequest("PATCH", "/api/profile", { workLocation });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      queryClient.refetchQueries({ queryKey: ["/api/team-status"] });
      toast({
        title: "Location Updated",
        description: "Your work location has been updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update work location. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Mark alert as read mutation
  const markAlertReadMutation = useMutation({
    mutationFn: async (alertId: string) => {
      return await apiRequest("PATCH", `/api/alerts/${alertId}/read`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
    },
    onError: (error) => {
      if (shouldShowUnauthorizedToast(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  // Mark alert as resolved mutation
  const markAlertResolvedMutation = useMutation({
    mutationFn: async (alertId: string) => {
      return await apiRequest("PATCH", `/api/alerts/${alertId}/resolve`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/team-status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/safety-status"] });
      toast({
        title: "Alert Resolved",
        description: "The alert has been marked as resolved.",
      });
    },
    onError: (error) => {
      if (shouldShowUnauthorizedToast(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to resolve alert. Please try again.",
        variant: "destructive",
      });
    },
  });


  // Refresh team status
  const refreshTeamStatus = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/team-status"] });
    queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
  };

  if (authLoading || statusLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p>Loading dashboard...</p>
        </div>
      </div>
    );
  }

  const unreadAlerts = alerts.filter((alert) => !alert.isRead);
  const unresolvedAlerts = alerts.filter((alert) => !alert.isResolved);

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${Math.floor(diffHours / 24)}d ago`;
  };

  return (
    <div className="p-6">
      {/* Quick Status Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold mb-2" data-testid="text-dashboard-title">Dashboard</h2>
            <p className="text-muted-foreground">Monitor team safety and manage your visits</p>
          </div>
          <Button
            variant="outline"
            onClick={() => setShowTeamManagement(true)}
            data-testid="button-team-management"
          >
            <Users className="h-4 w-4 mr-2" />
            Teams
          </Button>
        </div>
      </div>

      {/* Current Status Card */}
      <Card className="mb-6" data-testid="card-current-status">
        <CardHeader>
          <CardTitle>Your Current Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div>
            <p className="text-sm text-muted-foreground">Active Visit</p>
            <p className="font-medium" data-testid="text-active-visit">
              {activeVisit ? activeVisit.location || "In Progress" : "None"}
            </p>
          </div>
          
          {/* Work Location Selector */}
          <div className="mt-4 border-t pt-4">
            <p className="text-sm text-muted-foreground mb-2">Work Location</p>
            <Tabs 
              value={user?.workLocation || "on-site"} 
              onValueChange={(value) => updateLocationMutation.mutate(value as "on-site" | "remote")}
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger 
                  value="on-site" 
                  data-testid="tab-location-onsite"
                  disabled={updateLocationMutation.isPending}
                >
                  <Building className="h-4 w-4 mr-2" />
                  On-site
                </TabsTrigger>
                <TabsTrigger 
                  value="remote" 
                  data-testid="tab-location-remote"
                  disabled={updateLocationMutation.isPending}
                >
                  <MapPin className="h-4 w-4 mr-2" />
                  Remote
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <div className="flex space-x-3 mt-4">
            <Button 
              onClick={() => safetyCheckMutation.mutate()}
              disabled={safetyCheckMutation.isPending}
              className="bg-success hover:bg-success/90 text-white"
              data-testid="button-quick-safe-checkin"
            >
              <Shield className="h-4 w-4 mr-2" />
              I'm Safe
            </Button>
            <Button 
              variant="outline"
              onClick={() => setShowVisitModal(true)}
              disabled={!!activeVisit}
              data-testid="button-start-visit"
            >
              <MapPin className="h-4 w-4 mr-2" />
              {activeVisit ? "Visit Active" : "Start Visit"}
            </Button>
            <Button 
              variant="destructive"
              onClick={() => setShowEmergencyModal(true)}
              data-testid="button-emergency"
            >
              <TriangleAlert className="h-4 w-4 mr-2" />
              Emergency
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Duty Manager Card */}
      {(() => {
        const dutyManager = teamStatus.find((member: any) => member.role === "duty_manager");
        return dutyManager ? (
          <Card className="mb-6" data-testid="card-duty-manager">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="h-5 w-5 text-blue-600" />
                <span>Duty Manager</span>
              </CardTitle>
              <CardDescription>
                Contact information for the current duty manager
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                    <span className="text-blue-600 font-semibold text-lg">
                      {dutyManager.firstName?.[0] || "DM"}
                    </span>
                  </div>
                  <div>
                    <p className="font-medium text-lg" data-testid="text-duty-manager-name">
                      {dutyManager.firstName && dutyManager.lastName 
                        ? `${dutyManager.firstName} ${dutyManager.lastName}`
                        : "Duty Manager"
                      }
                    </p>
                    {dutyManager.workPhone && (
                      <div className="flex items-center space-x-2 mt-1">
                        <Phone className="h-4 w-4 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground" data-testid="text-duty-manager-phone">
                          {dutyManager.workPhone}
                        </p>
                      </div>
                    )}
                    <p className="text-sm text-muted-foreground mt-1" data-testid="text-duty-manager-role">
                      Duty Manager
                    </p>
                  </div>
                </div>
                {dutyManager.workPhone && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => window.open(`tel:${dutyManager.workPhone}`)}
                    data-testid="button-call-duty-manager"
                  >
                    <Phone className="h-4 w-4 mr-2" />
                    Call
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ) : null;
      })()}

      {/* Active Team Status - Members who have logged in today */}
      <Card className="mb-6" data-testid="card-team-status">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Active Team Status</CardTitle>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={refreshTeamStatus}
              disabled={teamFetching}
              data-testid="button-refresh-team"
            >
              <RefreshCw className={`h-4 w-4 mr-1 ${teamFetching ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            Team members who have logged in today
          </p>
        </CardHeader>
        <CardContent>
          {teamLoading ? (
            <div className="flex items-center justify-center py-8">
              <RefreshCw className="h-6 w-6 animate-spin" />
            </div>
          ) : teamStatus.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No team members have logged in today</p>
          ) : (
            <div className="space-y-4">
              {/* Active Alerts Section */}
              {unresolvedAlerts.length > 0 && (
                <div className="border-l-4 border-red-500 bg-red-50 p-4 rounded-r-lg mb-4">
                  <div className="flex items-center mb-2">
                    <TriangleAlert className="h-5 w-5 text-red-600 mr-2" />
                    <h4 className="font-semibold text-red-900">Active Alerts ({unresolvedAlerts.length})</h4>
                  </div>
                  <div className="space-y-2">
                    {unresolvedAlerts.map((alert) => (
                      <div 
                        key={alert.id}
                        className="flex items-start justify-between p-2 bg-white rounded border border-red-200"
                        data-testid={`alert-in-team-status-${alert.id}`}
                      >
                        <div className="flex-1">
                          <p className="font-medium text-red-900 text-sm" data-testid={`text-team-alert-title-${alert.id}`}>
                            {alert.title}
                          </p>
                          <p className="text-xs text-red-700" data-testid={`text-team-alert-description-${alert.id}`}>
                            {alert.description}
                          </p>
                          {(alert as any).user && (
                            <p className="text-xs text-red-600 mt-1" data-testid={`text-team-alert-user-${alert.id}`}>
                              For: {(alert as any).user.firstName} {(alert as any).user.lastName}
                            </p>
                          )}
                        </div>
                        <div className="flex space-x-1">
                          <Button 
                            size="sm" 
                            variant="ghost"
                            className="h-7 w-7 p-0"
                            onClick={() => markAlertReadMutation.mutate(alert.id)}
                            data-testid={`button-team-alert-read-${alert.id}`}
                          >
                            <Eye className="h-3 w-3" />
                          </Button>
                          <Button 
                            size="sm" 
                            className="h-7 px-2 text-xs"
                            onClick={() => markAlertResolvedMutation.mutate(alert.id)}
                            disabled={markAlertResolvedMutation.isPending}
                            data-testid={`button-team-alert-resolve-${alert.id}`}
                          >
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Resolve
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Team Members - All members active today */}
              {teamStatus.map((member: any) => (
                <div 
                  key={member.id} 
                  className={`p-3 rounded-lg border ${
                    member.safetyStatus?.status === "overdue" || member.safetyStatus?.status === "emergency"
                      ? "bg-red-50 border-red-200" 
                      : member.safetyStatus?.status === "visiting"
                      ? "bg-yellow-50 border-yellow-200"
                      : "bg-accent border-border"
                  }`}
                  data-testid={`card-team-member-${member.id}`}
                >
                  {member.isJointVisit ? (
                    // Joint visit display
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center">
                            <Users className="h-5 w-5 text-yellow-600" />
                          </div>
                          <div>
                            <p className="font-medium" data-testid={`text-joint-visit-${member.id}`}>
                              Joint Visit ({member.members.length} members)
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <StatusIndicator status="visiting" />
                          <span className="text-sm font-medium text-yellow-700">Visiting</span>
                        </div>
                      </div>
                      
                      {/* Member details */}
                      <div className="ml-13 pl-3 border-l-2 border-yellow-200 space-y-2">
                        {member.members.map((visitMember: any) => (
                          <div 
                            key={visitMember.id}
                            className="flex items-center justify-between text-sm"
                            data-testid={`joint-member-${visitMember.id}`}
                          >
                            <div className="flex items-center space-x-2">
                              <div className="w-6 h-6 rounded-full bg-yellow-50 flex items-center justify-center">
                                <span className="text-xs text-yellow-600 font-medium">
                                  {visitMember.firstName?.[0] || "?"}
                                </span>
                              </div>
                              <span className="text-muted-foreground">
                                {visitMember.firstName && visitMember.lastName 
                                  ? `${visitMember.firstName} ${visitMember.lastName}`
                                  : "Team Member"
                                }
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    // Individual member display
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-semibold ${
                          member.safetyStatus?.status === "safe" ? "bg-green-100" :
                          member.safetyStatus?.status === "visiting" ? "bg-yellow-100" :
                          member.safetyStatus?.status === "overdue" ? "bg-red-100" : "bg-gray-100"
                        }`}>
                          <span className={`${
                            member.safetyStatus?.status === "safe" ? "text-green-600" :
                            member.safetyStatus?.status === "visiting" ? "text-yellow-600" :
                            member.safetyStatus?.status === "overdue" ? "text-red-600" : "text-gray-600"
                          }`}>
                            {member.firstName?.[0] || "?"}
                          </span>
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-medium" data-testid={`text-member-name-${member.id}`}>
                              {member.firstName && member.lastName 
                                ? `${member.firstName} ${member.lastName}`
                                : "Team Member"
                              }
                            </p>
                            <span 
                              className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${
                                member.workLocation === "on-site" 
                                  ? "bg-blue-100 text-blue-800 border border-blue-200" 
                                  : member.workLocation === "remote"
                                  ? "bg-purple-100 text-purple-800 border border-purple-200"
                                  : "bg-gray-100 text-gray-600 border border-gray-200"
                              }`}
                              data-testid={`badge-member-location-${member.id}`}
                            >
                              {member.workLocation === "on-site" ? (
                                <>
                                  <Building className="h-3.5 w-3.5 mr-1" />
                                  On-site
                                </>
                              ) : member.workLocation === "remote" ? (
                                <>
                                  <MapPin className="h-3.5 w-3.5 mr-1" />
                                  Remote
                                </>
                              ) : (
                                "Not set"
                              )}
                            </span>
                          </div>
                          {member.safetyStatus?.status === "emergency" && (
                            <p className="text-sm text-red-600 font-medium" data-testid={`text-member-emergency-location-${member.id}`}>
                              📍 {member.safetyStatus?.location || "Emergency location unknown"}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <StatusIndicator status={member.safetyStatus?.status || "safe"} />
                        <span className={`text-sm font-medium capitalize ${
                          member.safetyStatus?.status === "overdue" ? "text-red-700" :
                          member.safetyStatus?.status === "visiting" ? "text-yellow-700" :
                          "text-green-700"
                        }`}>
                          {member.safetyStatus?.status || "Safe"}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>


      {/* Modals */}
      <VisitModal 
        open={showVisitModal} 
        onOpenChange={setShowVisitModal}
      />
      <EmergencyModal 
        open={showEmergencyModal} 
        onOpenChange={setShowEmergencyModal}
      />
      <TeamManagementDialog 
        open={showTeamManagement}
        onOpenChange={setShowTeamManagement}
        user={user}
      />
    </div>
  );
}

// Team Management Dialog for switching and joining teams
function TeamManagementDialog({ open, onOpenChange, user }: { open: boolean; onOpenChange: (open: boolean) => void; user: User | null }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<"memberships" | "search" | "join" | "create">("memberships");
  const [searchResults, setSearchResults] = useState<Team[]>([]);
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);

  // Fetch user's team memberships
  const { data: memberships = [], isLoading: membershipsLoading, error: membershipsError } = useQuery<Array<{ id: string; teamId: string; role: string; team: Team; isActive: boolean }>>({
    queryKey: ["/api/teams/memberships"],
    enabled: open && !!user,
  });

  // Log membership fetch errors
  useEffect(() => {
    if (membershipsError) {
      console.error("Memberships fetch error:", membershipsError);
      toast({
        title: "Error loading teams",
        description: "Please try refreshing the page",
        variant: "destructive"
      });
    }
  }, [membershipsError, toast]);

  // Team search form
  const searchForm = useForm<SearchTeams>({
    resolver: zodResolver(searchTeamsSchema),
    defaultValues: { query: "" },
  });

  // Team joining form
  const joinForm = useForm<JoinTeam>({
    resolver: zodResolver(joinTeamSchema),
    defaultValues: { teamCode: "", teamPassword: "" },
  });

  // Team creation form
  const createForm = useForm<CreateTeam>({
    resolver: zodResolver(createTeamSchema),
    defaultValues: { name: "", teamPassword: "", description: "" },
  });

  // Search teams mutation
  const searchTeamsMutation = useMutation({
    mutationFn: (data: SearchTeams) => apiRequest('GET', `/api/teams/search?query=${encodeURIComponent(data.query)}`),
    onSuccess: (results: Team[]) => {
      setSearchResults(results);
      if (results.length === 0) {
        toast({ 
          title: "No teams found", 
          description: "Try a different search term or create a new team." 
        });
      }
    },
    onError: (error: any) => {
      toast({ 
        title: "Search failed", 
        description: error.message || "Failed to search teams",
        variant: "destructive" 
      });
    },
  });

  // Join team mutation
  const joinTeamMutation = useMutation({
    mutationFn: (data: JoinTeam) => apiRequest('POST', '/api/teams/join', data),
    onSuccess: async () => {
      toast({ 
        title: "Welcome to your new team!", 
        description: "You've successfully joined the team." 
      });
      await queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/teams/memberships"] });
      window.location.reload();
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to join team", 
        description: error.message || "Invalid team code or password",
        variant: "destructive" 
      });
    },
  });

  // Create team mutation
  const createTeamMutation = useMutation({
    mutationFn: (data: CreateTeam) => apiRequest('POST', '/api/teams/create', data),
    onSuccess: async () => {
      toast({ 
        title: "Team created!", 
        description: "Your team has been created successfully." 
      });
      await queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/teams/memberships"] });
      window.location.reload();
    },
    onError: (error: any) => {
      toast({ 
        title: "Team creation failed", 
        description: error.message || "Failed to create team",
        variant: "destructive" 
      });
    },
  });

  // Switch team mutation
  const switchTeamMutation = useMutation({
    mutationFn: (teamId: string) => apiRequest('POST', '/api/teams/switch', { teamId }),
    onSuccess: async () => {
      toast({ 
        title: "Team switched!", 
        description: "You've switched to a different team." 
      });
      await queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      window.location.reload();
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to switch team", 
        description: error.message || "Could not switch teams",
        variant: "destructive" 
      });
    },
  });

  const handleTeamSelect = (team: Team) => {
    setSelectedTeam(team);
    // Team code will need to be provided by user when joining from search results
    setActiveTab("join");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="dialog-team-management">
        <DialogHeader>
          <DialogTitle>Team Management</DialogTitle>
          <DialogDescription>
            Manage your team memberships, switch between teams, or join new ones
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="memberships" data-testid="tab-memberships">
              <Users className="h-4 w-4 mr-2" />
              My Teams
            </TabsTrigger>
            <TabsTrigger value="search" data-testid="tab-search-teams">
              <Search className="h-4 w-4 mr-2" />
              Search
            </TabsTrigger>
            <TabsTrigger value="join" data-testid="tab-join-team">
              <UserPlus className="h-4 w-4 mr-2" />
              Join
            </TabsTrigger>
            <TabsTrigger value="create" data-testid="tab-create-team">
              <Building className="h-4 w-4 mr-2" />
              Create
            </TabsTrigger>
          </TabsList>

          <TabsContent value="memberships" className="space-y-4">
            <h3 className="font-medium">Your Team Memberships</h3>
            {membershipsLoading ? (
              <p className="text-muted-foreground">Loading your teams...</p>
            ) : memberships.length === 0 ? (
              <p className="text-muted-foreground">You haven't joined any teams yet. Search for a team or create one!</p>
            ) : (
              <div className="space-y-2">
                {memberships.map((membership) => (
                  <Card 
                    key={membership.id}
                    className={membership.isActive ? "border-blue-500" : ""}
                    data-testid={`membership-${membership.teamId}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">{membership.team.name}</h4>
                          {membership.team.teamCode && (
                            <p className="text-sm font-mono text-blue-600 dark:text-blue-400">
                              Code: {membership.team.teamCode}
                            </p>
                          )}
                          {membership.team.description && (
                            <p className="text-sm text-muted-foreground">{membership.team.description}</p>
                          )}
                          <p className="text-xs text-muted-foreground mt-1">
                            Role: {membership.role === "duty_manager" ? "Duty Manager" : "Team Member"}
                            {membership.isActive && " • Active Team"}
                          </p>
                        </div>
                        {!membership.isActive && (
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => switchTeamMutation.mutate(membership.teamId)}
                            disabled={switchTeamMutation.isPending}
                            data-testid={`button-switch-to-${membership.teamId}`}
                          >
                            Switch to This Team
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="search" className="space-y-4">
            <Form {...searchForm}>
              <form 
                onSubmit={searchForm.handleSubmit((data) => searchTeamsMutation.mutate(data))} 
                className="space-y-4"
              >
                <FormField
                  control={searchForm.control}
                  name="query"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Search Teams</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter team name or description" 
                          data-testid="input-search-teams-dialog"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button 
                  type="submit" 
                  disabled={searchTeamsMutation.isPending}
                  data-testid="button-search-teams-dialog"
                >
                  {searchTeamsMutation.isPending ? "Searching..." : "Search Teams"}
                </Button>
              </form>
            </Form>

            {searchResults.length > 0 && (
              <div className="space-y-2">
                <h3 className="font-medium">Found Teams:</h3>
                {searchResults.map((team) => (
                  <Card 
                    key={team.id} 
                    className="cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800" 
                    onClick={() => handleTeamSelect(team)}
                    data-testid={`team-search-result-${team.id}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-medium">{team.name}</h4>
                          {team.description && (
                            <p className="text-sm text-muted-foreground">{team.description}</p>
                          )}
                        </div>
                        <Button variant="outline" size="sm">
                          Select
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="join" className="space-y-4">
            {selectedTeam && (
              <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg mb-4">
                <h3 className="font-medium text-blue-900 dark:text-blue-100">Selected Team: {selectedTeam.name}</h3>
                {selectedTeam.description && (
                  <p className="text-sm text-blue-700 dark:text-blue-300">{selectedTeam.description}</p>
                )}
              </div>
            )}
            
            <Form {...joinForm}>
              <form 
                onSubmit={joinForm.handleSubmit((data) => joinTeamMutation.mutate(data))} 
                className="space-y-4"
              >
                <FormField
                  control={joinForm.control}
                  name="teamCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team Code</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter your team code (e.g. BRIS3123)" 
                          data-testid="input-team-code-dialog"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={joinForm.control}
                  name="teamPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team Password</FormLabel>
                      <FormControl>
                        <Input 
                          type="password" 
                          placeholder="Enter team password" 
                          data-testid="input-team-password-dialog"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button 
                  type="submit" 
                  disabled={joinTeamMutation.isPending}
                  data-testid="button-join-team-dialog"
                >
                  {joinTeamMutation.isPending ? "Joining..." : "Join Team"}
                </Button>
              </form>
            </Form>
          </TabsContent>

          <TabsContent value="create" className="space-y-4">
            <Form {...createForm}>
              <form 
                onSubmit={createForm.handleSubmit((data) => createTeamMutation.mutate(data))} 
                className="space-y-4"
              >
                <FormField
                  control={createForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team Name</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Enter team name" 
                          data-testid="input-create-team-name-dialog"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={createForm.control}
                  name="teamPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team Password</FormLabel>
                      <FormControl>
                        <Input 
                          type="password" 
                          placeholder="Create team password" 
                          data-testid="input-create-team-password-dialog"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={createForm.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description (Optional)</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Brief team description" 
                          data-testid="input-create-team-description-dialog"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button 
                  type="submit" 
                  disabled={createTeamMutation.isPending}
                  data-testid="button-create-team-dialog"
                >
                  {createTeamMutation.isPending ? "Creating..." : "Create Team"}
                </Button>
              </form>
            </Form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

// Team joining interface for authenticated users without teams
function TeamJoiningDashboard({ user, onTeamJoined }: { user: User; onTeamJoined?: () => void }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<"search" | "join" | "create">("search");
  const [searchResults, setSearchResults] = useState<Team[]>([]);
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);

  // Team search form
  const searchForm = useForm<SearchTeams>({
    resolver: zodResolver(searchTeamsSchema),
    defaultValues: { query: "" },
  });

  // Team joining form
  const joinForm = useForm<JoinTeam>({
    resolver: zodResolver(joinTeamSchema),
    defaultValues: { teamCode: "", teamPassword: "" },
  });

  // Team creation form
  const createForm = useForm<CreateTeam>({
    resolver: zodResolver(createTeamSchema),
    defaultValues: { name: "", teamPassword: "", description: "" },
  });

  // Search teams mutation
  const searchTeamsMutation = useMutation({
    mutationFn: (data: SearchTeams) => apiRequest('GET', `/api/teams/search?query=${encodeURIComponent(data.query)}`),
    onSuccess: (results: Team[]) => {
      setSearchResults(results);
      if (results.length === 0) {
        toast({ 
          title: "No teams found", 
          description: "Try a different search term or create a new team." 
        });
      }
    },
    onError: (error: any) => {
      toast({ 
        title: "Search failed", 
        description: error.message || "Failed to search teams",
        variant: "destructive" 
      });
    },
  });

  // Join team mutation
  const joinTeamMutation = useMutation({
    mutationFn: (data: JoinTeam) => apiRequest('POST', '/api/teams/join', data),
    onSuccess: async () => {
      console.log("Team join successful, refreshing user data...");
      toast({ 
        title: "Welcome to your team!", 
        description: "You've successfully joined the team." 
      });
      try {
        // Invalidate and wait for user data to refresh
        await queryClient.invalidateQueries({ queryKey: ["/api/user"] });
        await queryClient.invalidateQueries({ queryKey: ["/api/teams/current"] });
        console.log("Queries invalidated, reloading page...");
        // Force a page reload to ensure fresh state
        window.location.reload();
      } catch (error) {
        console.error("Error during team join refresh:", error);
        // Fallback to direct navigation
        window.location.href = "/";
      }
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to join team", 
        description: error.message || "Invalid team code or password",
        variant: "destructive" 
      });
    },
  });

  // Create team mutation
  const createTeamMutation = useMutation({
    mutationFn: (data: CreateTeam) => apiRequest('POST', '/api/teams/create', data),
    onSuccess: () => {
      toast({ 
        title: "Team created!", 
        description: "Your team has been created successfully." 
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      window.location.href = "/"; // Navigate to main dashboard
    },
    onError: (error: any) => {
      toast({ 
        title: "Team creation failed", 
        description: error.message || "Failed to create team",
        variant: "destructive" 
      });
    },
  });

  // Logout function
  const logout = async () => {
    try {
      await fetch("/api/logout", { method: "POST" });
      window.location.href = "/";
    } catch (error) {
      console.error("Logout failed:", error);
      window.location.href = "/";
    }
  };

  const handleTeamSelect = (team: Team) => {
    setSelectedTeam(team);
    // Team code will need to be provided by user when joining from search results
    setActiveTab("join");
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
                <Shield className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
              <h1 className="text-2xl font-bold">TeamSafe</h1>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={logout}
              data-testid="button-logout"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
          <h2 className="text-xl font-semibold mb-2">Welcome, {user.firstName || user.username}!</h2>
          <p className="text-muted-foreground">
            Your account is ready. Now join an existing team or create a new one to get started.
          </p>
        </div>

        {/* Team Management Interface */}
        <Card>
          <CardHeader>
            <CardTitle>Team Management</CardTitle>
            <CardDescription>
              Search for your team, join with a team code, or create a new team
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "search" | "join" | "create")}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="search" data-testid="tab-search">
                  <Search className="h-4 w-4 mr-2" />
                  Search Teams
                </TabsTrigger>
                <TabsTrigger value="join" data-testid="tab-join">
                  <UserPlus className="h-4 w-4 mr-2" />
                  Join Team
                </TabsTrigger>
                <TabsTrigger value="create" data-testid="tab-create">
                  <Building className="h-4 w-4 mr-2" />
                  Create Team
                </TabsTrigger>
              </TabsList>

              <TabsContent value="search" className="space-y-4">
                <Form {...searchForm}>
                  <form 
                    onSubmit={searchForm.handleSubmit((data) => searchTeamsMutation.mutate(data))} 
                    className="space-y-4"
                  >
                    <FormField
                      control={searchForm.control}
                      name="query"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Search Teams</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Enter team name or description" 
                              data-testid="input-search-teams"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button 
                      type="submit" 
                      disabled={searchTeamsMutation.isPending}
                      data-testid="button-search-teams"
                    >
                      {searchTeamsMutation.isPending ? "Searching..." : "Search Teams"}
                    </Button>
                  </form>
                </Form>

                {/* Search Results */}
                {searchResults.length > 0 && (
                  <div className="space-y-2">
                    <h3 className="font-medium">Found Teams:</h3>
                    {searchResults.map((team) => (
                      <Card 
                        key={team.id} 
                        className="cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800" 
                        onClick={() => handleTeamSelect(team)}
                        data-testid={`team-result-${team.id}`}
                      >
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-medium">{team.name}</h4>
                              {team.description && (
                                <p className="text-sm text-muted-foreground">{team.description}</p>
                              )}
                            </div>
                            <Button variant="outline" size="sm">
                              Select
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="join" className="space-y-4">
                {selectedTeam && (
                  <div className="p-4 bg-blue-50 dark:bg-blue-950 rounded-lg mb-4">
                    <h3 className="font-medium text-blue-900 dark:text-blue-100">Selected Team: {selectedTeam.name}</h3>
                    {selectedTeam.description && (
                      <p className="text-sm text-blue-700 dark:text-blue-300">{selectedTeam.description}</p>
                    )}
                  </div>
                )}
                
                <Form {...joinForm}>
                  <form 
                    onSubmit={joinForm.handleSubmit((data) => joinTeamMutation.mutate(data))} 
                    className="space-y-4"
                  >
                    <FormField
                      control={joinForm.control}
                      name="teamCode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Team Code</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Enter your team code (e.g. BRIS3123)" 
                              data-testid="input-team-code"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={joinForm.control}
                      name="teamPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Team Password</FormLabel>
                          <FormControl>
                            <Input 
                              type="password" 
                              placeholder="Enter team password" 
                              data-testid="input-team-password"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button 
                      type="submit" 
                      disabled={joinTeamMutation.isPending}
                      data-testid="button-join-team"
                    >
                      {joinTeamMutation.isPending ? "Joining..." : "Join Team"}
                    </Button>
                  </form>
                </Form>
              </TabsContent>

              <TabsContent value="create" className="space-y-4">
                <Form {...createForm}>
                  <form 
                    onSubmit={createForm.handleSubmit((data) => createTeamMutation.mutate(data))} 
                    className="space-y-4"
                  >
                    <FormField
                      control={createForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Team Name</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Enter team name" 
                              data-testid="input-create-team-name"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createForm.control}
                      name="teamPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Team Password</FormLabel>
                          <FormControl>
                            <Input 
                              type="password" 
                              placeholder="Create team password" 
                              data-testid="input-create-team-password"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={createForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description (Optional)</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Brief team description" 
                              data-testid="input-create-team-description"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button 
                      type="submit" 
                      disabled={createTeamMutation.isPending}
                      data-testid="button-create-team"
                    >
                      {createTeamMutation.isPending ? "Creating..." : "Create Team"}
                    </Button>
                  </form>
                </Form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
