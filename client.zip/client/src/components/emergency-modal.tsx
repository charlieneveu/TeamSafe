import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { TriangleAlert, AlertCircle, CheckCircle, MapPin } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

interface EmergencyModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface AlertResponse {
  alert: any;
  message: string;
  smsLinks: string[];
  phoneNumbers: { name: string; phone: string }[];
  hasContacts: boolean;
  dutyManagerCount: number;
  contactableManagers: number;
}

export default function EmergencyModal({ open, onOpenChange }: EmergencyModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [alertResponse, setAlertResponse] = useState<AlertResponse | null>(null);
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);
  
  const handleEmergencyCall = (number: string, description: string) => {
    // In a real app, this would trigger the phone app or emergency protocols
    window.open(`tel:${number}`, '_self');
  };


  const handleCallFromResponse = (phone: string, name: string) => {
    window.open(`tel:${phone}`, '_self');
  };

  const resetModal = () => {
    setAlertResponse(null);
    setIsDetectingLocation(false);
  };

  // Function to get current GPS location with fallback to IP-based location
  const getCurrentLocation = (): Promise<{ latitude: number; longitude: number; type?: string } | null> => {
    return new Promise(async (resolve) => {
      console.log("🔍 Checking geolocation support...");
      
      // Check if we're in a secure context and not in an iframe
      const isSecure = window.isSecureContext;
      const isTopLevel = window.top === window;
      console.log("🔒 Security context:", { isSecure, isTopLevel });
      
      if (!navigator.geolocation || !isSecure || !isTopLevel) {
        console.warn("❌ GPS blocked - not in secure top-level context");
        
        // Show toast suggestion to open in new tab
        if (!isTopLevel) {
          toast({
            title: "Location Blocked",
            description: "GPS is blocked in embedded view. Click here to open in a new tab for better functionality.",
            variant: "default",
            action: (
              <Button
                size="sm"
                onClick={() => window.open(window.location.href, '_blank')}
              >
                Open in New Tab
              </Button>
            ),
          });
        }
        
        // Fall back to IP-based geolocation
        try {
          console.log("🌐 Trying IP-based location fallback...");
          const ipResponse = await fetch('https://ipapi.co/json/');
          const ipData = await ipResponse.json();
          
          if (ipData.latitude && ipData.longitude) {
            if (import.meta.env.DEV) {
              console.log("✅ Got IP-based location:", ipData);
            }
            resolve({
              latitude: ipData.latitude,
              longitude: ipData.longitude,
              type: "approximate"
            });
            return;
          }
        } catch (error) {
          console.warn("❌ IP geolocation failed:", error);
        }
        
        resolve(null);
        return;
      }

      console.log("✅ Geolocation supported, requesting GPS position...");
      const timeoutId = setTimeout(() => {
        console.warn("⏰ GPS timed out, trying IP fallback...");
        
        // Try IP fallback on timeout
        fetch('https://ipapi.co/json/')
          .then(response => response.json())
          .then(ipData => {
            if (ipData.latitude && ipData.longitude) {
              if (import.meta.env.DEV) {
                console.log("✅ Got IP-based location after GPS timeout:", ipData);
              }
              resolve({
                latitude: ipData.latitude,
                longitude: ipData.longitude,
                type: "approximate"
              });
            } else {
              resolve(null);
            }
          })
          .catch(() => resolve(null));
      }, 8000); // 8 second timeout for GPS

      navigator.geolocation.getCurrentPosition(
        (position) => {
          clearTimeout(timeoutId);
          if (import.meta.env.DEV) {
            console.log("✅ Got GPS position:", {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              accuracy: position.coords.accuracy
            });
          }
          resolve({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            type: "gps"
          });
        },
        (error) => {
          clearTimeout(timeoutId);
          console.warn("❌ GPS error:", error.message, "Code:", error.code);
          
          // Try IP fallback on error
          fetch('https://ipapi.co/json/')
            .then(response => response.json())
            .then(ipData => {
              if (ipData.latitude && ipData.longitude) {
              if (import.meta.env.DEV) {
                console.log("✅ Got IP-based location after GPS error:", ipData);
              }
                resolve({
                  latitude: ipData.latitude,
                  longitude: ipData.longitude,
                  type: "approximate"
                });
              } else {
                resolve(null);
              }
            })
            .catch(() => resolve(null));
        },
        {
          enableHighAccuracy: true,
          timeout: 6000,
          maximumAge: 30000 // Accept cached position up to 30 seconds old
        }
      );
    });
  };
  
  // Manual alert mutation
  const manualAlertMutation = useMutation({
    mutationFn: async (alertData: { message: string; location?: { latitude: number; longitude: number } }): Promise<AlertResponse> => {
      const response = await apiRequest("POST", "/api/alerts/manual", alertData);
      return response;
    },
    onSuccess: (data: AlertResponse) => {
      queryClient.invalidateQueries({ queryKey: ["/api/alerts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/team-status"] });
      
      // Store the response to show SMS options
      setAlertResponse(data);
      
      // Show success toast for SMS options
      if (data.smsLinks.length > 0) {
        toast({
          title: "SMS Links Generated",
          description: `Emergency alert created! SMS links generated for ${data.dutyManagerCount} duty manager(s). You can send messages using your phone's messaging app.`,
          variant: "default",
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to raise alert. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const handleManualAlert = async () => {
    console.log("🚨 Emergency alert triggered - starting location detection");
    setIsDetectingLocation(true);
    
    try {
      // First try to get current location
      console.log("📍 Attempting to get current location...");
      const location = await getCurrentLocation();
      if (import.meta.env.DEV) {
        console.log("📍 Location result:", location);
      }
      
      // Prepare alert data
      const alertData: { message: string; location?: { latitude: number; longitude: number } } = {
        message: "Clinician needs assistance - manual alert raised",
      };
      
      // Add location if available
      if (location) {
        alertData.location = {
          latitude: location.latitude,
          longitude: location.longitude
        };
        const locationType = location.type === "gps" ? "GPS" : location.type === "approximate" ? "IP-based" : "unknown";
        if (import.meta.env.DEV) {
          console.log(`📍 Including ${locationType} location in alert:`, alertData.location);
        }
        
        // Show user what type of location was detected
        if (location.type === "approximate") {
          toast({
            title: "Location Detected",
            description: "Using approximate location based on IP address",
            variant: "default",
          });
        } else if (location.type === "gps") {
          toast({
            title: "Location Detected", 
            description: "Using precise GPS coordinates",
            variant: "default",
          });
        }
      } else {
        console.log("⚠️ No location available - sending alert without coordinates");
      }
      
      console.log("📤 Sending alert data:", alertData);
      // Send the alert with location information
      manualAlertMutation.mutate(alertData);
      
    } catch (error) {
      console.error("💥 Error in handleManualAlert:", error);
      // Fallback: send alert without location
      console.log("📤 Fallback: sending alert without location");
      manualAlertMutation.mutate({ message: "Clinician needs assistance - manual alert raised" });
    } finally {
      setIsDetectingLocation(false);
    }
  };

  const handleModalClose = (open: boolean) => {
    if (!open) {
      resetModal();
    }
    onOpenChange(open);
  };

  return (
    <Dialog open={open} onOpenChange={handleModalClose}>
      <DialogContent className="sm:max-w-[425px]" data-testid="dialog-emergency-modal">
        <DialogHeader>
          <div className="flex items-center space-x-2 mb-2">
            {alertResponse ? (
              <CheckCircle className="h-6 w-6 text-green-600" />
            ) : (
              <TriangleAlert className="h-6 w-6 text-destructive" />
            )}
            <DialogTitle className={alertResponse ? "text-green-600" : "text-destructive"} data-testid="text-emergency-modal-title">
              {alertResponse ? "Emergency Alert Ready" : "Emergency Contacts"}
            </DialogTitle>
          </div>
          <DialogDescription>
            {alertResponse 
              ? "Emergency alert sent automatically to duty managers via Microsoft Teams." 
              : "Press the button below to request immediate assistance."}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-3">
          {!alertResponse ? (
            // Simple emergency button
            <Button 
              className="w-full bg-destructive hover:bg-destructive/90 text-white p-6 h-auto"
              onClick={handleManualAlert}
              disabled={manualAlertMutation.isPending || isDetectingLocation}
              data-testid="button-manual-alert"
            >
              <div className="flex items-center space-x-3">
                {isDetectingLocation ? (
                  <MapPin className="h-6 w-6 animate-pulse" />
                ) : (
                  <AlertCircle className="h-6 w-6" />
                )}
                <div className="text-left">
                  <div className="font-bold text-lg">
                    {isDetectingLocation ? "Detecting Location..." : "Request Immediate Assistance"}
                  </div>
                  <div className="text-sm opacity-90">
                    {isDetectingLocation 
                      ? "Getting GPS coordinates for emergency alert" 
                      : "Generate SMS messages for duty managers"}
                  </div>
                </div>
              </div>
            </Button>
          ) : (
            // Success confirmation with SMS links
            <div className="bg-green-50 dark:bg-green-950 p-4 rounded-lg border border-green-200 dark:border-green-800">
              <div className="text-center mb-4">
                <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-3" />
                <p className="text-green-800 dark:text-green-200 font-semibold">
                  Emergency alert created!
                </p>
                <p className="text-sm text-green-700 dark:text-green-300 mt-2">
                  {alertResponse.message}
                </p>
              </div>
              
              {alertResponse.smsLinks && alertResponse.smsLinks.length > 0 ? (
                <div className="text-center space-y-3">
                  <p className="text-sm text-green-700 dark:text-green-300 mb-3">
                    📱 SMS links ready for {alertResponse.dutyManagerCount} duty manager(s):
                  </p>
                  <div className="space-y-2">
                    {alertResponse.smsLinks.map((smsLink, index) => (
                      <a
                        key={index}
                        href={smsLink}
                        className="block w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-3 rounded-lg text-sm font-medium transition-colors"
                        data-testid={`sms-link-${index}`}
                      >
                        📱 Send SMS to {alertResponse.phoneNumbers[index]?.name || `Duty Manager ${index + 1}`}
                      </a>
                    ))}
                  </div>
                  <p className="text-xs text-green-600 dark:text-green-400">
                    Click any button above to open your phone's messaging app
                  </p>
                </div>
              ) : (
                <div className="text-center space-y-3">
                  <div className="p-3 bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg">
                    <p className="text-red-700 dark:text-red-300 text-sm font-medium">
                      ⚠️ No duty managers configured
                    </p>
                    <p className="text-red-600 dark:text-red-400 text-xs mt-1">
                      Please contact your administrator to set up emergency contacts.
                    </p>
                  </div>
                </div>
              )}
              
              {alertResponse.phoneNumbers && alertResponse.phoneNumbers.length > 0 && (
                <div className="mt-3 pt-3 border-t border-green-200 dark:border-green-800">
                  <p className="text-sm text-green-700 dark:text-green-300 mb-2 text-center">
                    Or call directly:
                  </p>
                  <div className="space-y-2">
                    {alertResponse.phoneNumbers.map((contact, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        onClick={() => handleCallFromResponse(contact.phone, contact.name)}
                        className="w-full border-green-300 text-green-700 hover:bg-green-100 dark:border-green-600 dark:text-green-300 dark:hover:bg-green-900"
                        data-testid={`button-call-${index}`}
                      >
                        📞 Call {contact.name}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        
        <Button 
          variant="outline" 
          className="w-full mt-4"
          onClick={() => handleModalClose(false)}
          data-testid="button-cancel-emergency"
        >
          {alertResponse ? "Close" : "Cancel"}
        </Button>
      </DialogContent>
    </Dialog>
  );
}
