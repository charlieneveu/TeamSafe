import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { shouldShowUnauthorizedToast } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Clock, User } from "lucide-react";

interface VisitModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onVisitCreated?: () => void;
}

export default function VisitModal({ open, onOpenChange, onVisitCreated }: VisitModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createVisitMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/visits", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/visits"] });
      queryClient.invalidateQueries({ queryKey: ["/api/visits/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/safety-status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/team-status"] });
      toast({
        title: "Visit Started",
        description: "You're now marked as visiting. Remember to check in when you're safe!",
      });
      onOpenChange(false);
      onVisitCreated?.();
    },
    onError: (error: any) => {
      if (shouldShowUnauthorizedToast(error)) {
        toast({
          title: "Unauthorized", 
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      // Handle active visit conflict
      if (error.message?.includes("already have an active visit")) {
        toast({
          title: "Active Visit Exists",
          description: "Please complete your current visit before starting a new one.",
          variant: "destructive",
        });
        return;
      }
      
      toast({
        title: "Error",
        description: "Failed to start visit. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleStartVisit = () => {
    createVisitMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Clock className="h-5 w-5" />
            <span>Start New Visit</span>
          </DialogTitle>
          <DialogDescription>
            This will mark you as currently visiting. Make sure to complete your visit when you're done and safe.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 space-y-6">
          <div className="text-center text-muted-foreground">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <User className="h-8 w-8 text-blue-500" />
              <Clock className="h-8 w-8 text-blue-500" />
            </div>
            <p className="text-sm">
              You'll be marked as visiting until you check in as safe.
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button 
            type="button" 
            variant="outline" 
            onClick={() => onOpenChange(false)}
            data-testid="button-cancel"
          >
            Cancel
          </Button>
          <Button 
            onClick={handleStartVisit}
            disabled={createVisitMutation.isPending}
            data-testid="button-start-visit"
          >
            {createVisitMutation.isPending 
              ? "Starting..." 
              : "Start Visit"
            }
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}