import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDown, Check, Users } from "lucide-react";
import type { Team } from "@shared/schema";

type TeamMembership = {
  id: string;
  teamId: string;
  role: string;
  team: Team;
  isActive: boolean;
};

export default function TeamSwitcher({ compact = false }: { compact?: boolean }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: memberships = [], isLoading } = useQuery<TeamMembership[]>({
    queryKey: ["/api/teams/memberships"],
    enabled: !!user,
  });

  const switchTeamMutation = useMutation({
    mutationFn: (teamId: string) => apiRequest('POST', '/api/teams/switch', { teamId }),
    onSuccess: async () => {
      toast({ 
        title: "Team switched!", 
        description: "You've switched to a different team." 
      });
      await queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/teams/memberships"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/teams/current"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/team-status"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/team-management"] });
      window.location.reload();
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to switch team", 
        description: error.message || "Could not switch teams",
        variant: "destructive" 
      });
    },
  });

  const activeTeam = memberships.find(m => m.isActive);
  const otherTeams = memberships.filter(m => !m.isActive);

  if (isLoading) {
    return (
      <div className={`${compact ? 'px-2' : 'px-4'} py-2`}>
        <div className="h-9 bg-muted animate-pulse rounded-md" />
      </div>
    );
  }

  if (memberships.length === 0) {
    return null;
  }

  return (
    <div className={`${compact ? 'px-2' : 'px-4'} py-2`}>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="outline" 
            className="w-full justify-between"
            data-testid="team-switcher-trigger"
          >
            <div className="flex items-center space-x-2 min-w-0">
              <Users className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">{activeTeam?.team.name || "Select Team"}</span>
            </div>
            <ChevronDown className="h-4 w-4 flex-shrink-0 opacity-50" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-56" align="start">
          <DropdownMenuLabel>Switch Team</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {activeTeam && (
            <DropdownMenuItem 
              className="flex items-center justify-between"
              data-testid={`team-option-${activeTeam.teamId}`}
            >
              <span className="truncate">{activeTeam.team.name}</span>
              <Check className="h-4 w-4 text-primary" />
            </DropdownMenuItem>
          )}
          {otherTeams.map((membership) => (
            <DropdownMenuItem 
              key={membership.id}
              onClick={() => switchTeamMutation.mutate(membership.teamId)}
              disabled={switchTeamMutation.isPending}
              className="cursor-pointer"
              data-testid={`team-option-${membership.teamId}`}
            >
              <span className="truncate">{membership.team.name}</span>
            </DropdownMenuItem>
          ))}
          {memberships.length === 1 && (
            <DropdownMenuItem disabled className="text-muted-foreground text-sm">
              You're only in one team
            </DropdownMenuItem>
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
