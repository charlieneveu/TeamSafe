import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Home, User as UserIcon, LogOut, Users, Settings, HelpCircle } from "lucide-react";
import { useLocation } from "wouter";
import type { User, Alert, Team } from "@shared/schema";

export default function MobileNav() {
  const { user, logoutMutation } = useAuth();
  const [location, setLocation] = useLocation();

  // Fetch alerts for badge count
  const { data: alerts = [] } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
  });

  const unreadAlerts = alerts.filter((alert) => !alert.isRead);

  const navigation = [
    { name: "Dashboard", href: "/", icon: Home, current: location === "/" },
    { name: "Team", href: "/team-management", icon: Users, current: location === "/team-management" },
    { name: "Profile", href: "/profile-settings", icon: Settings, current: location === "/profile-settings" },
    { name: "Help", href: "/help", icon: HelpCircle, current: location === "/help" },
  ];

  return (
    <>
      {/* Mobile Top Navigation Bar */}
      <nav className="fixed top-0 left-0 right-0 bg-background border-b border-border md:hidden z-40 safe-area-pt mobile-nav">
        <div className="flex items-center justify-around py-2 px-1">
          {navigation.map((item) => (
            <Button
              key={item.href}
              variant="ghost"
              size="sm"
              className={`flex flex-col items-center justify-center p-2 h-auto min-w-0 flex-1 ${
                item.current 
                  ? "text-primary bg-primary/10" 
                  : "text-muted-foreground hover:text-foreground hover:bg-accent/50"
              }`}
              onClick={() => setLocation(item.href)}
              data-testid={`button-mobile-nav-${item.href.substring(1) || "dashboard"}`}
            >
              <div className="relative">
                <item.icon className="h-5 w-5 mb-1" />
                {item.href === "/team-management" && unreadAlerts.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                    {unreadAlerts.length > 9 ? "9+" : unreadAlerts.length}
                  </span>
                )}
              </div>
              <span className="text-xs font-medium">{item.name}</span>
            </Button>
          ))}
          
          {/* Logout Button */}
          <Button
            variant="ghost"
            size="sm"
            className="flex flex-col items-center justify-center p-2 h-auto min-w-0 flex-1 text-muted-foreground hover:text-foreground hover:bg-accent/50"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
            data-testid="button-mobile-logout"
          >
            <LogOut className="h-5 w-5 mb-1" />
            <span className="text-xs font-medium">Logout</span>
          </Button>
        </div>
      </nav>
      
      {/* Spacer to prevent content from being hidden behind top nav */}
      <div className="md:hidden mobile-nav-spacer" />
    </>
  );
}