import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Home, MapPin, Calendar as CalendarIcon, Users, TriangleAlert, User as UserIcon, LogOut, HelpCircle } from "lucide-react";
import teamSafeLogo from "@assets/teamsafe-logo.png";
import { useLocation } from "wouter";
import type { User, Alert, Team } from "@shared/schema";
import TeamSwitcher from "@/components/team-switcher";

export default function Sidebar() {
  const { user, logoutMutation } = useAuth();
  const [location, setLocation] = useLocation();

  // Fetch alerts for badge count
  const { data: alerts = [] } = useQuery<Alert[]>({
    queryKey: ["/api/alerts"],
  });

  const unreadAlerts = alerts.filter((alert) => !alert.isRead);
  const unresolvedAlerts = alerts.filter((alert) => !alert.isResolved);

  const navigation = [
    { name: "Dashboard", href: "/", icon: Home, current: location === "/" },
    { name: "Team Management", href: "/team-management", icon: Users, current: location === "/team-management" },
    { name: "Profile Settings", href: "/profile-settings", icon: UserIcon, current: location === "/profile-settings" },
    { name: "Help", href: "/help", icon: HelpCircle, current: location === "/help" },
  ];

  const getUserInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`;
    }
    return "U";
  };

  const getUserDisplayName = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    return "User";
  };

  return (
    <aside className="w-64 bg-card border-r border-border flex flex-col h-screen">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <img src={teamSafeLogo} alt="TeamSafe" className="h-8 w-8" />
          <div>
            <h1 className="text-xl font-bold" data-testid="text-app-title">TeamSafe</h1>
            <p className="text-sm text-muted-foreground">Team Wellness & Safety</p>
          </div>
        </div>
      </div>
      
      {/* Team Switcher */}
      <div className="border-b border-border">
        <TeamSwitcher />
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navigation.map((item) => (
            <li key={item.href}>
              <Button
                variant={item.current ? "default" : "ghost"}
                className={`w-full justify-start ${item.current ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"}`}
                onClick={() => setLocation(item.href)}
                data-testid={`button-nav-${item.href.substring(1) || "dashboard"}`}
              >
                <item.icon className="h-5 w-5 mr-3" />
                <span className="flex-1 text-left">{item.name}</span>
              </Button>
            </li>
          ))}
        </ul>
      </nav>
      
      {/* User Section */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-primary-foreground font-semibold">
            <span data-testid="text-user-initials">{getUserInitials()}</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-medium truncate" data-testid="text-user-name">
              {getUserDisplayName()}
            </p>
          </div>
        </div>
        <Button 
          variant="ghost" 
          className="w-full justify-start text-muted-foreground hover:text-foreground"
          onClick={() => logoutMutation.mutate()}
          data-testid="button-logout"
        >
          <LogOut className="h-4 w-4 mr-2" />
          Sign Out
        </Button>
      </div>
    </aside>
  );
}
