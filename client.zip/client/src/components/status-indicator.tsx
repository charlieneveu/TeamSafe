interface StatusIndicatorProps {
  status: string;
  className?: string;
}

export default function StatusIndicator({ status, className = "" }: StatusIndicatorProps) {
  const getStatusColor = () => {
    switch (status) {
      case "safe":
        return "bg-green-500";
      case "visiting":
        return "bg-yellow-500 animate-pulse";
      case "overdue":
        return "bg-red-500 animate-pulse";
      case "offline":
        return "bg-gray-400";
      case "completed":
        return "bg-green-500";
      case "active":
        return "bg-yellow-500 animate-pulse";
      default:
        return "bg-gray-400";
    }
  };

  return (
    <div 
      className={`w-3 h-3 rounded-full ${getStatusColor()} ${className}`}
      data-testid={`status-indicator-${status}`}
    />
  );
}
