export function isUnauthorizedError(error: Error): boolean {
  return /^401: .*Unauthorized/.test(error.message);
}

// Helper to check if we're currently in a login process
let isLoggingIn = false;

export function setLoggingInState(state: boolean) {
  isLoggingIn = state;
}

export function shouldShowUnauthorizedToast(error: Error): boolean {
  // Don't show unauthorized toasts during login process
  if (isLoggingIn) {
    return false;
  }
  return isUnauthorizedError(error);
}