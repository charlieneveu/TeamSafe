import { createContext, useContext, useEffect, useRef } from 'react';
import { queryClient } from './queryClient';

interface AlertUpdateContextType {
  isActive: boolean;
}

const AlertUpdateContext = createContext<AlertUpdateContextType | null>(null);

export function AlertUpdateProvider({ children, userId }: { children: React.ReactNode; userId?: string }) {
  const pollingRef = useRef<NodeJS.Timeout | null>(null);
  const lastAlertCheckRef = useRef<number>(Date.now());

  const checkForAlertUpdates = async () => {
    if (!userId) return;

    try {
      // Check if we have any recent alert resolutions that affect this user
      const response = await fetch('/api/alerts/check-updates', {
        credentials: 'include',
        headers: {
          'If-Modified-Since': new Date(lastAlertCheckRef.current).toISOString()
        }
      });

      if (response.ok) {
        const data = await response.json();
        
        if (data.hasUpdates) {
          console.log('Detected alert resolution updates, refreshing queries...');
          
          // Invalidate relevant queries to update the UI
          queryClient.invalidateQueries({ queryKey: ['/api/safety-status'] });
          queryClient.invalidateQueries({ queryKey: ['/api/visits'] });
          queryClient.invalidateQueries({ queryKey: ['/api/visits/active'] });
          queryClient.invalidateQueries({ queryKey: ['/api/alerts'] });
          queryClient.invalidateQueries({ queryKey: ['/api/team-status'] });
          
          console.log('✅ Invalidated queries due to alert resolution');
        }
        
        lastAlertCheckRef.current = Date.now();
      }
    } catch (error) {
      console.error('Error checking for alert updates:', error);
    }
  };

  useEffect(() => {
    if (userId) {
      // Check for updates every 2 seconds when user is authenticated
      pollingRef.current = setInterval(checkForAlertUpdates, 2000);
      
      // Initial check
      checkForAlertUpdates();
    }

    return () => {
      if (pollingRef.current) {
        clearInterval(pollingRef.current);
      }
    };
  }, [userId]);

  return (
    <AlertUpdateContext.Provider value={{ isActive: !!pollingRef.current }}>
      {children}
    </AlertUpdateContext.Provider>
  );
}

export function useAlertUpdates() {
  const context = useContext(AlertUpdateContext);
  if (!context) {
    throw new Error('useAlertUpdates must be used within an AlertUpdateProvider');
  }
  return context;
}