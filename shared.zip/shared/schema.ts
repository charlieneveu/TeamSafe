import { sql } from 'drizzle-orm';
import {
  index,
  uniqueIndex,
  json,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  boolean,
  integer,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for Replit Auth  
export const sessions = pgTable(
  "session",
  {
    sid: varchar("sid").primaryKey(),
    sess: json("sess").notNull(),
    expire: timestamp("expire", { precision: 6 }).notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Teams table for multi-tenant support
export const teams = pgTable("teams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(),
  teamCode: varchar("team_code").unique(), // Short, shareable code (e.g., "BRISTOL25") - nullable for migration
  teamPassword: varchar("team_password").notNull(), // Will be hashed
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User teams junction table for many-to-many relationships
export const userTeams = pgTable("user_teams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  teamId: varchar("team_id").notNull(),
  role: varchar("role").notNull().default("teamsafe_member"), // teamsafe_member, duty_manager
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  // Ensure a user can only have one membership per team
  uniqueUserPerTeam: uniqueIndex("unique_user_per_team").on(table.userId, table.teamId),
}));

// Password reset tokens for email-based password reset
export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  token: varchar("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// User storage table for username/password authentication
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id"), // Made nullable for individual registration
  username: varchar("username").notNull(),
  password: varchar("password").notNull(),
  email: varchar("email").notNull().unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  workPhone: varchar("work_phone"),
  personalPhone: varchar("personal_phone"),
  role: varchar("role").notNull().default("teamsafe_member"), // teamsafe_member, duty_manager
  workLocation: varchar("work_location").notNull().default("on-site"), // on-site, remote
  lastActiveAt: timestamp("last_active_at"), // Track when user last used the app
  emailVerified: boolean("email_verified").notNull().default(false), // Email verification status
  verificationToken: varchar("verification_token"), // Token for email verification
  verificationTokenExpiry: timestamp("verification_token_expiry"), // When the token expires
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  // Ensure username is unique within each team (proper unique constraint)
  uniqueUsernamePerTeam: uniqueIndex("unique_username_per_team").on(table.teamId, table.username),
}));

// Visit tracking table
export const visits = pgTable("visits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull(),
  clinicianId: varchar("clinician_id").notNull(),
  patientName: varchar("patient_name"),
  location: text("location"),
  expectedDuration: integer("expected_duration"), // in minutes
  status: varchar("status").notNull().default("active"), // active, completed, overdue
  startTime: timestamp("start_time").defaultNow(),
  endTime: timestamp("end_time"),
  lastCheckIn: timestamp("last_check_in").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Safety status table
export const safetyStatus = pgTable("safety_status", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull(),
  clinicianId: varchar("clinician_id").notNull(),
  status: varchar("status").notNull().default("offline"), // safe, visiting, overdue, offline
  location: text("location"),
  lastUpdate: timestamp("last_update").defaultNow(),
  currentVisitId: varchar("current_visit_id"),
});

// Scheduled visits table
export const scheduledVisits = pgTable("scheduled_visits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull(),
  clinicianId: varchar("clinician_id").notNull(),
  patientName: varchar("patient_name"),
  location: text("location"),
  dayOfWeek: integer("day_of_week").notNull(), // 1=Monday, 2=Tuesday, etc.
  startTime: varchar("start_time").notNull(), // HH:MM format in 24-hour
  endTime: varchar("end_time").notNull(), // HH:MM format in 24-hour
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Alerts table
export const alerts = pgTable("alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull(),
  clinicianId: varchar("clinician_id").notNull(),
  type: varchar("type").notNull(), // safety_overdue, extended_visit, emergency, scheduled_overdue
  title: text("title").notNull(),
  description: text("description").notNull(),
  priority: varchar("priority").notNull().default("medium"), // low, medium, high
  severity: varchar("severity").notNull().default("yellow"), // yellow, red
  location: text("location"), // User's location when alert was created
  isRead: boolean("is_read").default(false),
  isResolved: boolean("is_resolved").default(false),
  scheduledVisitId: varchar("scheduled_visit_id"), // Reference to scheduled visit if applicable
  createdAt: timestamp("created_at").defaultNow(),
  resolvedAt: timestamp("resolved_at"),
});

// User links table for joint visits
export const userLinks = pgTable("user_links", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  teamId: varchar("team_id").notNull(),
  userId: varchar("user_id").notNull(),
  linkedUserId: varchar("linked_user_id").notNull(),
  linkType: varchar("link_type").notNull().default("joint_visit"), // joint_visit, team_partner
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  createdBy: varchar("created_by").notNull(), // user who created the link
});

// Schema exports
export const insertVisitSchema = createInsertSchema(visits).pick({
  patientName: true,
  location: true,
  expectedDuration: true,
});

export const updateSafetyStatusSchema = createInsertSchema(safetyStatus).pick({
  status: true,
  location: true,
});

// Safety status schema without location requirement for "I'm safe" check
export const safeSafetyStatusSchema = z.object({
  status: z.literal("safe"),
});

export const insertScheduledVisitSchema = createInsertSchema(scheduledVisits).pick({
  patientName: true,
  location: true,
  dayOfWeek: true,
  startTime: true,
  endTime: true,
});

export const insertAlertSchema = createInsertSchema(alerts).pick({
  clinicianId: true,
  type: true,
  title: true,
  description: true,
  priority: true,
  severity: true,
  location: true,
  scheduledVisitId: true,
});

// User registration schema for authentication
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  firstName: true,
  lastName: true,
  role: true,
}).extend({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  email: z.string().email("Please enter a valid email address"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  role: z.enum(["teamsafe_member", "duty_manager"]).default("teamsafe_member"),
});

export const createManualUserSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  email: z.string().email("Please enter a valid email address"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  role: z.enum(["teamsafe_member", "duty_manager"]).default("teamsafe_member"),
});

// Helper function to convert phone numbers to +44 format
const normalizePhoneToUK = (phone: string | undefined): string => {
  if (!phone) return '';
  
  // Remove all non-digit characters
  const digits = phone.replace(/[^\d]/g, '');
  
  // If empty after cleaning, return empty
  if (!digits) return '';
  
  // If already starts with 44, add + prefix
  if (digits.startsWith('44')) {
    return '+' + digits;
  }
  
  // If starts with 0 (UK domestic format), replace with +44
  if (digits.startsWith('0')) {
    return '+44' + digits.substring(1);
  }
  
  // If starts with 7, 8, or 9 (mobile without 0), add +44
  if (digits.match(/^[789]/)) {
    return '+44' + digits;
  }
  
  // For other patterns, assume it needs +44 prefix
  return '+44' + digits;
};

export const updateUserProfileSchema = z.object({
  firstName: z.string().min(1, "First name is required").optional(),
  lastName: z.string().min(1, "Last name is required").optional(),
  email: z.string().email("Please enter a valid email address").optional(),
  workPhone: z.string().optional().transform(normalizePhoneToUK),
  personalPhone: z.string().optional().transform(normalizePhoneToUK),
  workLocation: z.enum(["on-site", "remote"]).optional(),
});

export const createUserLinkSchema = createInsertSchema(userLinks).pick({
  linkedUserId: true,
  linkType: true,
});

export const updateUserLinkSchema = z.object({
  isActive: z.boolean(),
});

// Team management schemas
export const createTeamSchema = createInsertSchema(teams).pick({
  name: true,
  teamPassword: true,
  description: true,
}).extend({
  name: z.string().min(1, "Team name is required"),
  teamCode: z.string().min(4, "Team code must be at least 4 characters").max(20, "Team code must be at most 20 characters").regex(/^[A-Za-z0-9]+$/, "Team code can only contain letters and numbers").optional(),
  teamPassword: z.string().min(6, "Team password must be at least 6 characters"),
  description: z.string().optional(),
});

export const joinTeamSchema = z.object({
  teamCode: z.string().min(1, "Team code is required"),
  teamPassword: z.string().min(6, "Team password must be at least 6 characters"),
});

export const searchTeamsSchema = z.object({
  query: z.string().min(1, "Search query is required").max(100, "Search query must be at most 100 characters"),
});

// Password reset schemas
export const requestPasswordResetSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

export const resetPasswordSchema = z.object({
  token: z.string().min(1, "Reset token is required"),
  newPassword: z.string().min(6, "Password must be at least 6 characters"),
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, "Current password is required"),
  newPassword: z.string().min(6, "New password must be at least 6 characters"),
});

// Authentication schemas
export const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(1, "Password is required"),
});

// Individual registration schema without team requirements
export const registerIndividualSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  role: z.enum(["teamsafe_member", "duty_manager"]).default("teamsafe_member"),
});

// Legacy registration schema (kept for backward compatibility)
export const registerSchema = z.object({
  teamId: z.string().min(1, "Team selection is required"),
  teamPassword: z.string().min(6, "Team password must be at least 6 characters"),
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  role: z.enum(["teamsafe_member", "duty_manager"]).default("teamsafe_member"),
});

// User team membership schemas
export const insertUserTeamSchema = createInsertSchema(userTeams).pick({
  userId: true,
  teamId: true,
  role: true,
});

export const updateUserTeamRoleSchema = z.object({
  role: z.enum(["teamsafe_member", "duty_manager"]),
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Visit = typeof visits.$inferSelect;
export type InsertVisit = z.infer<typeof insertVisitSchema>;
export type ScheduledVisit = typeof scheduledVisits.$inferSelect;
export type InsertScheduledVisit = z.infer<typeof insertScheduledVisitSchema>;
export type SafetyStatus = typeof safetyStatus.$inferSelect;
export type UpdateSafetyStatus = z.infer<typeof updateSafetyStatusSchema>;
export type SafeSafetyStatus = z.infer<typeof safeSafetyStatusSchema>;
export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type CreateManualUser = z.infer<typeof createManualUserSchema>;
export type UpdateUserProfile = z.infer<typeof updateUserProfileSchema>;
export type UserLink = typeof userLinks.$inferSelect;
export type CreateUserLink = z.infer<typeof createUserLinkSchema>;
export type UpdateUserLink = z.infer<typeof updateUserLinkSchema>;

// Team types
export type Team = typeof teams.$inferSelect;
export type CreateTeam = z.infer<typeof createTeamSchema>;
export type JoinTeam = z.infer<typeof joinTeamSchema>;
export type SearchTeams = z.infer<typeof searchTeamsSchema>;

// User team membership types
export type UserTeam = typeof userTeams.$inferSelect;
export type InsertUserTeam = z.infer<typeof insertUserTeamSchema>;
export type UpdateUserTeamRole = z.infer<typeof updateUserTeamRoleSchema>;

// Password reset types
export type PasswordResetToken = typeof passwordResetTokens.$inferSelect;
export type RequestPasswordReset = z.infer<typeof requestPasswordResetSchema>;
export type ResetPassword = z.infer<typeof resetPasswordSchema>;

// Authentication types
export type Login = z.infer<typeof loginSchema>;
export type Register = z.infer<typeof registerSchema>;
export type RegisterIndividual = z.infer<typeof registerIndividualSchema>;
export type ChangePassword = z.infer<typeof changePasswordSchema>;
