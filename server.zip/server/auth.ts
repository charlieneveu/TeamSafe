// Email/password authentication using passport-local for multi-tenant teams
// Based on blueprint:javascript_auth_all_persistance
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import bcrypt from "bcryptjs";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

export async function hashPassword(password: string): Promise<string> {
  const saltRounds = 12;
  return await bcrypt.hash(password, saltRounds);
}

export async function comparePasswords(supplied: string, stored: string): Promise<boolean> {
  return await bcrypt.compare(supplied, stored);
}

export function setupAuth(app: Express) {
  // Require SESSION_SECRET in production for security
  const sessionSecret = process.env.SESSION_SECRET;
  if (!sessionSecret) {
    if (process.env.NODE_ENV === "production") {
      throw new Error("SESSION_SECRET environment variable is required in production");
    }
    console.warn("Warning: Using default session secret. Set SESSION_SECRET in production.");
  }
  
  const sessionSettings: session.SessionOptions = {
    secret: sessionSecret || "teamsafe-dev-secret-change-in-production",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
      sameSite: "lax", // CSRF protection
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days - persistent login
    },
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(
      { usernameField: 'email', passwordField: 'password' },
      async (email, password, done) => {
        try {
          // Find user by email (case insensitive)
          const user = await storage.getUserByEmail(email.toLowerCase());
          
          if (!user || !(await comparePasswords(password, user.password))) {
            return done(null, false, { message: "Invalid email or password" });
          } else {
            return done(null, user);
          }
        } catch (error) {
          return done(error);
        }
      }
    ),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: string, done) => {
    try {
      const user = await storage.getUser(id);
      if (!user) {
        // User not found - handle gracefully by clearing invalid session
        return done(null, false);
      }
      done(null, user);
    } catch (error) {
      // Database error - also clear invalid session  
      console.error("Session deserialization error:", error);
      done(null, false);
    }
  });

  // Note: Registration and login endpoints are now in routes.ts
  // This auth setup only configures the passport strategy for email/password authentication
}