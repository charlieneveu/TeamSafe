import {
  users,
  teams,
  userTeams,
  passwordResetTokens,
  visits,
  safetyStatus,
  alerts,
  scheduledVisits,
  userLinks,
  type User,
  type UpsertUser,
  type InsertUser,
  type Team,
  type CreateTeam,
  type JoinTeam,
  type UserTeam,
  type InsertUserTeam,
  type PasswordResetToken,
  type Visit,
  type InsertVisit,
  type ScheduledVisit,
  type InsertScheduledVisit,
  type SafetyStatus,
  type UpdateSafetyStatus,
  type SafeSafetyStatus,
  type Alert,
  type InsertAlert,
  type UpdateUserProfile,
  type UserLink,
  type CreateUserLink,
  type UpdateUserLink,
} from "@shared/schema";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { db, pool } from "./db";
import { eq, and, isNull, inArray, ilike, or } from "drizzle-orm";
import { randomUUID } from "crypto";
import bcrypt from "bcryptjs";

export interface IStorage {
  // Session store for authentication
  sessionStore: session.Store;
  
  // Team operations
  createTeam(teamData: CreateTeam): Promise<Team>;
  getTeam(teamId: string): Promise<Team | undefined>;
  getTeamByCode(teamCode: string): Promise<Team | undefined>;
  verifyTeamPassword(teamId: string, password: string): Promise<Team | undefined>;
  searchTeamsByDescription(searchQuery: string): Promise<Team[]>;
  
  // User operations (for username/password auth)
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(teamId: string, username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser & { teamId: string }): Promise<User>;
  createIndividualUser(user: InsertUser): Promise<User>; // New method for individual registration
  updateUserTeam(userId: string, teamId: string): Promise<User | undefined>; // New method to join team
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserPassword(userId: string, hashedPassword: string): Promise<User | undefined>;
  
  // Password reset operations
  createPasswordResetToken(userId: string, token: string, expiresAt: Date): Promise<PasswordResetToken>;
  getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined>;
  markPasswordResetTokenAsUsed(tokenId: string): Promise<void>;
  
  // Visit operations (team-scoped)
  createVisit(teamId: string, clinicianId: string, visit: InsertVisit): Promise<Visit>;
  getVisitsByClinicianId(teamId: string, clinicianId: string): Promise<Visit[]>;
  getActiveVisitByClinicianId(teamId: string, clinicianId: string): Promise<Visit | undefined>;
  updateVisitStatus(teamId: string, visitId: string, status: string, endTime?: Date): Promise<Visit | undefined>;
  getAllActiveVisits(teamId: string): Promise<Visit[]>;
  
  // Scheduled visit operations (team-scoped)
  createScheduledVisit(teamId: string, clinicianId: string, visit: InsertScheduledVisit): Promise<ScheduledVisit>;
  getScheduledVisitsByClinicianId(teamId: string, clinicianId: string): Promise<ScheduledVisit[]>;
  getAllScheduledVisits(teamId: string): Promise<ScheduledVisit[]>;
  updateScheduledVisit(teamId: string, visitId: string, visitData: Partial<InsertScheduledVisit>): Promise<ScheduledVisit | undefined>;
  deleteScheduledVisit(teamId: string, visitId: string): Promise<boolean>;
  getScheduledVisitsByDay(teamId: string, dayOfWeek: number): Promise<ScheduledVisit[]>;
  
  // Safety status operations (team-scoped)
  getSafetyStatus(teamId: string, clinicianId: string): Promise<SafetyStatus | undefined>;
  updateSafetyStatus(teamId: string, clinicianId: string, status: UpdateSafetyStatus): Promise<SafetyStatus>;
  updateSafeSafetyStatus(teamId: string, clinicianId: string): Promise<SafetyStatus>;
  getAllSafetyStatuses(teamId: string): Promise<SafetyStatus[]>;
  
  // Alert operations (team-scoped)
  createAlert(teamId: string, alert: InsertAlert): Promise<Alert>;
  getAlertsByClinicianId(teamId: string, clinicianId: string): Promise<Alert[]>;
  getUnresolvedAlerts(teamId: string): Promise<Alert[]>;
  markAlertAsRead(teamId: string, alertId: string): Promise<Alert | undefined>;
  markAlertAsResolved(teamId: string, alertId: string): Promise<Alert | undefined>;
  
  // Duty manager operations (team-scoped)
  getAllClinicians(teamId: string): Promise<User[]>;
  
  // Team management operations (team-scoped)
  getAllUsers(teamId: string): Promise<User[]>;
  updateUserRole(teamId: string, userId: string, role: string): Promise<User | undefined>;
  deleteUser(teamId: string, userId: string): Promise<boolean>;
  createManualUser(teamId: string, userData: { username: string; password: string; email: string; firstName: string; lastName: string; role?: string }): Promise<User>;
  
  // Profile management operations
  updateUserProfile(userId: string, profileData: UpdateUserProfile): Promise<User | undefined>;
  updateUserLastActive(userId: string): Promise<void>;
  
  // User linking operations (team-scoped)
  createUserLink(teamId: string, userId: string, linkData: CreateUserLink): Promise<UserLink>;
  getUserLinks(teamId: string, userId: string): Promise<UserLink[]>;
  getLinkedUsers(teamId: string, userId: string): Promise<User[]>;
  updateUserLink(teamId: string, linkId: string, linkData: UpdateUserLink): Promise<UserLink | undefined>;
  deleteUserLink(teamId: string, linkId: string): Promise<boolean>;
  
  // Multi-team membership operations
  addUserToTeam(userId: string, teamId: string, role?: string): Promise<UserTeam>;
  getUserTeamMemberships(userId: string): Promise<Array<UserTeam & { team: Team }>>;
  getUserTeamRole(userId: string, teamId: string): Promise<UserTeam | undefined>;
  removeUserFromTeam(userId: string, teamId: string): Promise<boolean>;
  isUserInTeam(userId: string, teamId: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    const PostgresSessionStore = connectPg(session);
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true, // Allow table creation
      // Use default table name 'sessions' (plural)
      ttl: 30 * 24 * 60 * 60, // 30 days TTL to match cookie duration
      pruneSessionInterval: 60, // Prune sessions every 60 seconds
      errorLog: (error: any) => {
        // Suppress "already exists" errors to prevent spam
        if (!error.message?.includes('already exists') && 
            error.code !== '42P07' && 
            !error.message?.includes('IDX_session_expire')) {
          console.error('Session store error:', error);
        }
      }
    });
  }

  // Helper to generate a readable team code
  private generateTeamCode(): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // Removed I, O, 0, 1 to avoid confusion
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  // Team operations
  async createTeam(teamData: CreateTeam & { teamCode?: string }): Promise<Team> {
    // Generate a unique team code if not provided
    let teamCode = teamData.teamCode?.toUpperCase();
    if (!teamCode) {
      // Try to generate a unique code (retry up to 5 times if collision)
      for (let attempt = 0; attempt < 5; attempt++) {
        teamCode = this.generateTeamCode();
        const existing = await this.getTeamByCode(teamCode);
        if (!existing) break;
      }
    }
    
    const [team] = await db
      .insert(teams)
      .values({
        name: teamData.name,
        teamCode: teamCode!,
        teamPassword: teamData.teamPassword, // Must be pre-hashed
        description: teamData.description,
      })
      .returning();
    return team;
  }


  async getTeam(teamId: string): Promise<Team | undefined> {
    const [team] = await db.select().from(teams).where(eq(teams.id, teamId));
    return team || undefined;
  }

  async getTeamByCode(teamCode: string): Promise<Team | undefined> {
    const [team] = await db.select().from(teams).where(eq(teams.teamCode, teamCode.toUpperCase()));
    return team || undefined;
  }

  async verifyTeamPassword(teamId: string, password: string): Promise<Team | undefined> {
    const team = await this.getTeam(teamId);
    if (!team) return undefined;
    
    // Team password verification will be done by caller using bcrypt
    return team;
  }

  async searchTeamsByDescription(searchQuery: string): Promise<Team[]> {
    if (!searchQuery.trim()) {
      return [];
    }
    
    const searchPattern = `%${searchQuery.trim()}%`;
    const results = await db
      .select()
      .from(teams)
      .where(
        or(
          ilike(teams.name, searchPattern),
          ilike(teams.description, searchPattern),
          ilike(teams.teamCode, searchPattern)
        )
      )
      .limit(20); // Limit results to prevent overwhelming the UI
    
    return results;
  }

  // Password reset operations
  async createPasswordResetToken(userId: string, token: string, expiresAt: Date): Promise<PasswordResetToken> {
    const [resetToken] = await db
      .insert(passwordResetTokens)
      .values({
        userId,
        token,
        expiresAt,
      })
      .returning();
    return resetToken;
  }

  async getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined> {
    const [resetToken] = await db
      .select()
      .from(passwordResetTokens)
      .where(and(eq(passwordResetTokens.token, token), eq(passwordResetTokens.used, false)))
      .limit(1);
    return resetToken || undefined;
  }

  async markPasswordResetTokenAsUsed(tokenId: string): Promise<void> {
    await db
      .update(passwordResetTokens)
      .set({ used: true })
      .where(eq(passwordResetTokens.id, tokenId));
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(teamId: string, username: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(and(eq(users.teamId, teamId), eq(users.username, username)));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(userData: InsertUser & { teamId: string; profileImageUrl?: string; workPhone?: string; personalPhone?: string }): Promise<User> {
    const [newUser] = await db
      .insert(users)
      .values({
        teamId: userData.teamId,
        username: userData.username,
        password: userData.password,
        email: userData.email ? userData.email.toLowerCase() : userData.email,
        firstName: userData.firstName,
        lastName: userData.lastName,
        profileImageUrl: userData.profileImageUrl || null,
        workPhone: userData.workPhone || null,
        personalPhone: userData.personalPhone || null,
        role: userData.role || "teamsafe_member",
      })
      .returning();
    
    // Initialize safety status for new user
    await this.updateSafetyStatus(userData.teamId, newUser.id, { status: "safe", location: null });
    
    return newUser;
  }

  async createIndividualUser(userData: InsertUser): Promise<User> {
    const [newUser] = await db
      .insert(users)
      .values({
        teamId: null, // No team association initially
        username: userData.username,
        password: userData.password,
        email: userData.email ? userData.email.toLowerCase() : userData.email,
        firstName: userData.firstName,
        lastName: userData.lastName,
        role: userData.role || "teamsafe_member",
      })
      .returning();
    
    // Don't initialize safety status since user has no team yet
    return newUser;
  }

  async updateUserTeam(userId: string, teamId: string): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({ teamId })
      .where(eq(users.id, userId))
      .returning();
    
    if (updatedUser) {
      // Initialize safety status for user joining team
      await this.updateSafetyStatus(teamId, userId, { status: "safe", location: null });
    }
    
    return updatedUser || undefined;
  }

  async updateUserPassword(userId: string, hashedPassword: string): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({
        password: hashedPassword,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  async setVerificationToken(userId: string, token: string, expiry: Date): Promise<void> {
    await db
      .update(users)
      .set({
        verificationToken: token,
        verificationTokenExpiry: expiry,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  }

  async getUserByVerificationToken(token: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.verificationToken, token));
    return user;
  }

  async verifyUserEmail(userId: string): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({
        emailVerified: true,
        verificationToken: null,
        verificationTokenExpiry: null,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return updatedUser;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const existingUser = userData.id ? await this.getUser(userData.id) : undefined;
    
    if (existingUser) {
      // Build update object with only defined fields to prevent overwriting existing data
      const updateFields: any = {
        updatedAt: new Date(),
      };
      if (userData.email !== undefined) updateFields.email = userData.email.toLowerCase();
      if (userData.firstName !== undefined) updateFields.firstName = userData.firstName;
      if (userData.lastName !== undefined) updateFields.lastName = userData.lastName;
      if (userData.profileImageUrl !== undefined) updateFields.profileImageUrl = userData.profileImageUrl;
      if (userData.workPhone !== undefined) updateFields.workPhone = userData.workPhone;
      if (userData.personalPhone !== undefined) updateFields.personalPhone = userData.personalPhone;
      
      const [updatedUser] = await db
        .update(users)
        .set(updateFields)
        .where(eq(users.id, userData.id!))
        .returning();
      return updatedUser;
    } else {
      // Create new user
      const [newUser] = await db
        .insert(users)
        .values({
          ...userData,
          role: userData.role || "teamsafe_member",
        })
        .returning();
      
      // Initialize safety status for new user - need to ensure teamId is available
      if (userData.teamId) {
        await this.updateSafetyStatus(userData.teamId, newUser.id, { status: "safe", location: null });
      }
      
      return newUser;
    }
  }

  // Visit operations
  async createVisit(teamId: string, clinicianId: string, visitData: InsertVisit): Promise<Visit> {
    const [visit] = await db
      .insert(visits)
      .values({
        teamId,
        clinicianId,
        patientName: visitData.patientName,
        location: visitData.location,
        expectedDuration: visitData.expectedDuration,
      })
      .returning();
    
    // Update safety status to visiting
    await this.updateSafetyStatus(teamId, clinicianId, {
      status: "visiting",
      location: visitData.location,
    });
    
    return visit;
  }

  async getVisitsByClinicianId(teamId: string, clinicianId: string): Promise<Visit[]> {
    return await db.select().from(visits).where(and(eq(visits.teamId, teamId), eq(visits.clinicianId, clinicianId)));
  }

  async getActiveVisitByClinicianId(teamId: string, clinicianId: string): Promise<Visit | undefined> {
    const [visit] = await db
      .select()
      .from(visits)
      .where(and(eq(visits.teamId, teamId), eq(visits.clinicianId, clinicianId), eq(visits.status, "active")))
      .limit(1);
    return visit;
  }

  async updateVisitStatus(teamId: string, visitId: string, status: string, endTime?: Date): Promise<Visit | undefined> {
    const [updatedVisit] = await db
      .update(visits)
      .set({
        status,
        endTime: endTime || undefined,
        lastCheckIn: new Date(),
      })
      .where(and(eq(visits.teamId, teamId), eq(visits.id, visitId)))
      .returning();
    
    if (!updatedVisit) return undefined;
    
    // If visit is completed, update safety status to safe
    if (status === "completed") {
      await this.updateSafetyStatus(teamId, updatedVisit.clinicianId, {
        status: "safe",
        location: updatedVisit.location,
      });
      
      // Only complete visits for linked users if they are on a joint visit at the same location
      const linkedUsers = await this.getLinkedUsers(teamId, updatedVisit.clinicianId);
      for (const linkedUser of linkedUsers) {
        const linkedActiveVisit = await this.getActiveVisitByClinicianId(teamId, linkedUser.id);
        // Only propagate completion if linked user has an active visit at the same location
        if (linkedActiveVisit && linkedActiveVisit.location === updatedVisit.location) {
          await this.updateVisitStatus(teamId, linkedActiveVisit.id, "completed", endTime);
        }
      }
    }
    
    return updatedVisit;
  }

  async getAllActiveVisits(teamId: string): Promise<Visit[]> {
    return await db.select().from(visits).where(and(eq(visits.teamId, teamId), eq(visits.status, "active")));
  }

  // Scheduled visit operations
  async createScheduledVisit(teamId: string, clinicianId: string, visitData: InsertScheduledVisit): Promise<ScheduledVisit> {
    const [scheduledVisit] = await db
      .insert(scheduledVisits)
      .values({
        teamId,
        clinicianId,
        patientName: visitData.patientName,
        location: visitData.location,
        dayOfWeek: visitData.dayOfWeek,
        startTime: visitData.startTime,
        endTime: visitData.endTime,
      })
      .returning();
    
    return scheduledVisit;
  }

  async getScheduledVisitsByClinicianId(teamId: string, clinicianId: string): Promise<ScheduledVisit[]> {
    return await db
      .select()
      .from(scheduledVisits)
      .where(and(eq(scheduledVisits.teamId, teamId), eq(scheduledVisits.clinicianId, clinicianId), eq(scheduledVisits.isActive, true)));
  }

  async getAllScheduledVisits(teamId: string): Promise<ScheduledVisit[]> {
    return await db.select().from(scheduledVisits).where(and(eq(scheduledVisits.teamId, teamId), eq(scheduledVisits.isActive, true)));
  }

  async updateScheduledVisit(teamId: string, visitId: string, visitData: Partial<InsertScheduledVisit>): Promise<ScheduledVisit | undefined> {
    const [updatedVisit] = await db
      .update(scheduledVisits)
      .set({
        ...visitData,
        updatedAt: new Date(),
      })
      .where(and(eq(scheduledVisits.teamId, teamId), eq(scheduledVisits.id, visitId)))
      .returning();
    
    return updatedVisit;
  }

  async deleteScheduledVisit(teamId: string, visitId: string): Promise<boolean> {
    const [updatedVisit] = await db
      .update(scheduledVisits)
      .set({
        isActive: false,
        updatedAt: new Date(),
      })
      .where(and(eq(scheduledVisits.teamId, teamId), eq(scheduledVisits.id, visitId)))
      .returning();
    
    return !!updatedVisit;
  }

  async getScheduledVisitsByDay(teamId: string, dayOfWeek: number): Promise<ScheduledVisit[]> {
    return await db
      .select()
      .from(scheduledVisits)
      .where(and(eq(scheduledVisits.teamId, teamId), eq(scheduledVisits.dayOfWeek, dayOfWeek), eq(scheduledVisits.isActive, true)));
  }

  // Safety status operations
  async getSafetyStatus(teamId: string, clinicianId: string): Promise<SafetyStatus | undefined> {
    const [status] = await db
      .select()
      .from(safetyStatus)
      .where(and(eq(safetyStatus.teamId, teamId), eq(safetyStatus.clinicianId, clinicianId)))
      .limit(1);
    return status;
  }

  async updateSafetyStatus(teamId: string, clinicianId: string, statusData: UpdateSafetyStatus): Promise<SafetyStatus> {
    const existing = await this.getSafetyStatus(teamId, clinicianId);
    const activeVisit = await this.getActiveVisitByClinicianId(teamId, clinicianId);
    
    if (existing) {
      const [updated] = await db
        .update(safetyStatus)
        .set({
          status: statusData.status || "safe",
          location: statusData.location || null,
          lastUpdate: new Date(),
          currentVisitId: activeVisit?.id || null,
        })
        .where(and(eq(safetyStatus.teamId, teamId), eq(safetyStatus.clinicianId, clinicianId)))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(safetyStatus)
        .values({
          teamId,
          clinicianId,
          status: statusData.status || "safe",
          location: statusData.location || null,
          currentVisitId: activeVisit?.id || null,
        })
        .returning();
      return created;
    }
  }

  async updateSafeSafetyStatus(teamId: string, clinicianId: string): Promise<SafetyStatus> {
    const existing = await this.getSafetyStatus(teamId, clinicianId);
    
    let safetyStatusRecord: SafetyStatus;
    
    if (existing) {
      const [updated] = await db
        .update(safetyStatus)
        .set({
          status: "safe",
          lastUpdate: new Date(),
          currentVisitId: null, // Clear current visit when marking safe
        })
        .where(and(eq(safetyStatus.teamId, teamId), eq(safetyStatus.clinicianId, clinicianId)))
        .returning();
      safetyStatusRecord = updated;
    } else {
      const [created] = await db
        .insert(safetyStatus)
        .values({
          teamId,
          clinicianId,
          status: "safe",
          location: null,
          currentVisitId: null,
        })
        .returning();
      safetyStatusRecord = created;
    }
    
    // Only update linked users' safety status if they are on a joint visit at the same location
    const currentActiveVisit = await this.getActiveVisitByClinicianId(teamId, clinicianId);
    if (currentActiveVisit && existing?.location) {
      const linkedUsers = await this.getLinkedUsers(teamId, clinicianId);
      for (const linkedUser of linkedUsers) {
        const linkedActiveVisit = await this.getActiveVisitByClinicianId(teamId, linkedUser.id);
        // Only propagate if linked user has an active visit at the same location
        if (linkedActiveVisit && linkedActiveVisit.location === currentActiveVisit.location) {
          const linkedExisting = await this.getSafetyStatus(teamId, linkedUser.id);
          
          if (linkedExisting) {
            await db
              .update(safetyStatus)
              .set({
                status: "safe",
                lastUpdate: new Date(),
                currentVisitId: null,
              })
              .where(and(eq(safetyStatus.teamId, teamId), eq(safetyStatus.clinicianId, linkedUser.id)));
          } else {
            await db
              .insert(safetyStatus)
              .values({
                teamId,
                clinicianId: linkedUser.id,
                status: "safe",
                location: existing?.location || null,
                currentVisitId: null,
              });
          }
        }
      }
    }
    
    return safetyStatusRecord;
  }

  async getAllSafetyStatuses(teamId: string): Promise<SafetyStatus[]> {
    return await db.select().from(safetyStatus).where(eq(safetyStatus.teamId, teamId));
  }

  // Alert operations
  async createAlert(teamId: string, alertData: InsertAlert): Promise<Alert> {
    const [alert] = await db
      .insert(alerts)
      .values({
        teamId,
        clinicianId: alertData.clinicianId,
        type: alertData.type,
        title: alertData.title,
        description: alertData.description,
        priority: alertData.priority || "medium",
        severity: alertData.severity || "yellow",
        location: alertData.location || null,
        scheduledVisitId: alertData.scheduledVisitId || null,
      })
      .returning();
    
    return alert;
  }

  async getAlertsByClinicianId(teamId: string, clinicianId: string): Promise<Alert[]> {
    return await db.select().from(alerts).where(and(eq(alerts.teamId, teamId), eq(alerts.clinicianId, clinicianId)));
  }

  async getUnresolvedAlerts(teamId: string): Promise<Alert[]> {
    return await db.select().from(alerts).where(and(eq(alerts.teamId, teamId), eq(alerts.isResolved, false)));
  }

  async markAlertAsRead(teamId: string, alertId: string): Promise<Alert | undefined> {
    const [updatedAlert] = await db
      .update(alerts)
      .set({ isRead: true })
      .where(and(eq(alerts.teamId, teamId), eq(alerts.id, alertId)))
      .returning();
    
    return updatedAlert;
  }

  async markAlertAsResolved(teamId: string, alertId: string): Promise<Alert | undefined> {
    const [updatedAlert] = await db
      .update(alerts)
      .set({
        isResolved: true,
        resolvedAt: new Date(),
      })
      .where(and(eq(alerts.teamId, teamId), eq(alerts.id, alertId)))
      .returning();
    
    return updatedAlert;
  }

  async getAllClinicians(teamId: string): Promise<User[]> {
    return await db.select().from(users).where(and(eq(users.teamId, teamId), eq(users.role, "teamsafe_member")));
  }

  // Team management operations
  async getAllUsers(teamId: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.teamId, teamId));
  }

  async updateUserRole(teamId: string, userId: string, role: string): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({
        role,
        updatedAt: new Date(),
      })
      .where(and(eq(users.teamId, teamId), eq(users.id, userId)))
      .returning();
    
    return updatedUser;
  }

  async deleteUser(teamId: string, userId: string): Promise<boolean> {
    try {
      // Delete related data first
      await db.delete(safetyStatus).where(and(eq(safetyStatus.teamId, teamId), eq(safetyStatus.clinicianId, userId)));
      await db.delete(visits).where(and(eq(visits.teamId, teamId), eq(visits.clinicianId, userId)));
      await db.delete(alerts).where(and(eq(alerts.teamId, teamId), eq(alerts.clinicianId, userId)));
      await db.delete(userLinks).where(and(eq(userLinks.teamId, teamId), eq(userLinks.userId, userId)));
      await db.delete(userLinks).where(and(eq(userLinks.teamId, teamId), eq(userLinks.linkedUserId, userId)));
      
      // Delete the user
      const [deletedUser] = await db.delete(users).where(and(eq(users.teamId, teamId), eq(users.id, userId))).returning();
      return !!deletedUser;
    } catch (error) {
      console.error("Error deleting user:", error);
      return false;
    }
  }

  // Manual user creation (for duty managers)
  async createManualUser(teamId: string, userData: { username: string; password: string; email: string; firstName: string; lastName: string; role?: string }): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        teamId,
        username: userData.username,
        password: userData.password, // Must be pre-hashed by caller
        email: userData.email.toLowerCase(), // Store emails in lowercase for consistency
        firstName: userData.firstName,
        lastName: userData.lastName,
        role: userData.role || "teamsafe_member",
      })
      .returning();
    
    // Initialize safety status for new user
    await this.updateSafetyStatus(teamId, user.id, { status: "safe", location: null });
    
    return user;
  }

  // Profile management operations
  async updateUserProfile(userId: string, profileData: UpdateUserProfile): Promise<User | undefined> {
    // Build update object with only defined fields to prevent overwriting existing data with undefined
    const updateFields: any = {
      updatedAt: new Date(),
    };
    
    // Only add fields that are explicitly provided
    if (profileData.firstName !== undefined) updateFields.firstName = profileData.firstName;
    if (profileData.lastName !== undefined) updateFields.lastName = profileData.lastName;
    if (profileData.email !== undefined) updateFields.email = profileData.email;
    if (profileData.workPhone !== undefined) updateFields.workPhone = profileData.workPhone;
    if (profileData.personalPhone !== undefined) updateFields.personalPhone = profileData.personalPhone;
    if (profileData.workLocation !== undefined) updateFields.workLocation = profileData.workLocation;
    
    const [updatedUser] = await db
      .update(users)
      .set(updateFields)
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  async updateUserLastActive(userId: string): Promise<void> {
    await db
      .update(users)
      .set({ lastActiveAt: new Date() })
      .where(eq(users.id, userId));
  }

  // User linking operations
  async createUserLink(teamId: string, userId: string, linkData: CreateUserLink): Promise<UserLink> {
    const [userLink] = await db
      .insert(userLinks)
      .values({
        teamId,
        userId,
        linkedUserId: linkData.linkedUserId,
        linkType: linkData.linkType || "joint_visit",
        createdBy: userId,
      })
      .returning();
    
    // Create reciprocal link
    await db
      .insert(userLinks)
      .values({
        teamId,
        userId: linkData.linkedUserId,
        linkedUserId: userId,
        linkType: linkData.linkType || "joint_visit",
        createdBy: userId,
      });
    
    return userLink;
  }

  async getUserLinks(teamId: string, userId: string): Promise<UserLink[]> {
    return await db
      .select()
      .from(userLinks)
      .where(and(eq(userLinks.teamId, teamId), eq(userLinks.userId, userId), eq(userLinks.isActive, true)));
  }

  async getLinkedUsers(teamId: string, userId: string): Promise<User[]> {
    const links = await this.getUserLinks(teamId, userId);
    const linkedUserIds = links.map(link => link.linkedUserId);
    
    if (linkedUserIds.length === 0) return [];
    
    return await db
      .select()
      .from(users)
      .where(and(eq(users.teamId, teamId), inArray(users.id, linkedUserIds)));
  }

  async updateUserLink(teamId: string, linkId: string, linkData: UpdateUserLink): Promise<UserLink | undefined> {
    const [updatedLink] = await db
      .update(userLinks)
      .set(linkData)
      .where(and(eq(userLinks.teamId, teamId), eq(userLinks.id, linkId)))
      .returning();
    
    return updatedLink;
  }

  async deleteUserLink(teamId: string, linkId: string): Promise<boolean> {
    const [deletedLink] = await db
      .delete(userLinks)
      .where(and(eq(userLinks.teamId, teamId), eq(userLinks.id, linkId)))
      .returning();
    
    if (!deletedLink) return false;
    
    // Also delete the reciprocal link
    await db
      .delete(userLinks)
      .where(
        and(
          eq(userLinks.teamId, teamId),
          eq(userLinks.userId, deletedLink.linkedUserId),
          eq(userLinks.linkedUserId, deletedLink.userId),
          eq(userLinks.linkType, deletedLink.linkType)
        )
      );
    
    return true;
  }

  // Multi-team membership operations
  async addUserToTeam(userId: string, teamId: string, role: string = "teamsafe_member"): Promise<UserTeam> {
    const [userTeam] = await db
      .insert(userTeams)
      .values({
        userId,
        teamId,
        role,
      })
      .returning();
    
    return userTeam;
  }

  async getUserTeamMemberships(userId: string): Promise<Array<UserTeam & { team: Team }>> {
    const memberships = await db
      .select({
        id: userTeams.id,
        userId: userTeams.userId,
        teamId: userTeams.teamId,
        role: userTeams.role,
        createdAt: userTeams.createdAt,
        team: teams,
      })
      .from(userTeams)
      .innerJoin(teams, eq(userTeams.teamId, teams.id))
      .where(eq(userTeams.userId, userId));
    
    return memberships;
  }

  async getUserTeamRole(userId: string, teamId: string): Promise<UserTeam | undefined> {
    const [membership] = await db
      .select()
      .from(userTeams)
      .where(and(eq(userTeams.userId, userId), eq(userTeams.teamId, teamId)));
    
    return membership;
  }

  async removeUserFromTeam(userId: string, teamId: string): Promise<boolean> {
    const [deleted] = await db
      .delete(userTeams)
      .where(and(eq(userTeams.userId, userId), eq(userTeams.teamId, teamId)))
      .returning();
    
    return !!deleted;
  }

  async isUserInTeam(userId: string, teamId: string): Promise<boolean> {
    const membership = await this.getUserTeamRole(userId, teamId);
    return !!membership;
  }
}

export const storage = new DatabaseStorage();
