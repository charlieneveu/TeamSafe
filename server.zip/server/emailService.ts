// Email service using Brevo (free alternative to SendGrid)
import fetch from 'node-fetch';

interface EmailParams {
  to: string;
  from: string;
  subject: string;
  text?: string;
  html?: string;
}

export async function initializeEmailService() {
  if (!process.env.BREVO_API_KEY) {
    console.warn("⚠️ BREVO_API_KEY not found - email functionality will be disabled");
    return false;
  }
  
  try {
    // Test API connection with a simple request
    const response = await fetch('https://api.brevo.com/v3/account', {
      headers: {
        'api-key': process.env.BREVO_API_KEY,
        'Content-Type': 'application/json'
      }
    });
    
    if (response.ok) {
      console.log("✅ Brevo email service initialized successfully");
      return true;
    } else {
      const errorText = await response.text();
      console.warn(`⚠️ Brevo API test returned ${response.status}: ${errorText}`);
      console.log("📧 Brevo email service will attempt to send emails despite connection test failure");
      return true; // Still return true to allow email attempts
    }
  } catch (error) {
    console.warn("⚠️ Brevo connection test failed:", error);
    console.log("📧 Brevo email service configured - will attempt to send emails");
    return true; // Still return true to allow email attempts
  }
}

export async function sendEmail(params: EmailParams): Promise<boolean> {
  if (!process.env.BREVO_API_KEY) {
    console.error("Cannot send email: BREVO_API_KEY not configured");
    return false;
  }
  
  try {
    const emailData = {
      sender: {
        name: "TeamSafe",
        email: params.from
      },
      to: [
        {
          email: params.to
        }
      ],
      subject: params.subject,
      textContent: params.text || params.subject,
      htmlContent: params.html,
      headers: {
        "Reply-To": params.from
      }
    };

    const response = await fetch('https://api.brevo.com/v3/smtp/email', {
      method: 'POST',
      headers: {
        'api-key': process.env.BREVO_API_KEY,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(emailData)
    });

    if (response.ok) {
      const responseData = await response.json() as { messageId?: string };
      const messageId = responseData.messageId || 'unknown';
      console.log(`✅ Email sent successfully to ${params.to} via Brevo (Message ID: ${messageId})`);
      
      // Log for NHS domain monitoring
      if (params.to.includes('@nbt.nhs.uk') || params.to.includes('@nhs.net')) {
        console.log(`📧 NHS domain email sent - Domain: ${params.to.split('@')[1]} | Message ID: ${messageId}`);
      }
      
      return true;
    } else {
      const errorData = await response.text();
      console.error(`❌ Brevo email error [${response.status}] to ${params.to}:`, errorData);
      
      // Log specific NHS domain failures for monitoring
      if (params.to.includes('@nbt.nhs.uk') || params.to.includes('@nhs.net')) {
        console.error(`🚨 NHS domain delivery failed - Domain: ${params.to.split('@')[1]} | Status: ${response.status}`);
      }
      
      return false;
    }
  } catch (error) {
    console.error(`❌ Brevo email network error to ${params.to}:`, error);
    return false;
  }
}

export async function sendVerificationEmail(email: string, firstName: string, verificationToken: string, baseUrl?: string): Promise<boolean> {
  console.log(`📧 Attempting to send verification email to: ${email}`);
  const finalBaseUrl = baseUrl || 'http://localhost:5000';
  const verifyUrl = `${finalBaseUrl}/verify-email?token=${verificationToken}`;
  console.log(`📧 Verification URL: ${verifyUrl}`);
  
  const emailParams: EmailParams = {
    to: email,
    from: 'cfneveu@gmail.com',
    subject: 'TeamSafe - Verify Your Email Address',
    text: `Welcome to TeamSafe, ${firstName}!

Please verify your email address to activate your account.

Verification Link: ${verifyUrl}

This link will expire in 24 hours.

If you did not create a TeamSafe account, please ignore this email.

TeamSafe`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 20px;">
        <div style="border-bottom: 3px solid #2563eb; margin-bottom: 20px; padding-bottom: 10px;">
          <h1 style="color: #2563eb; margin: 0; font-size: 24px;">TeamSafe</h1>
          <p style="color: #666; margin: 5px 0 0 0; font-size: 14px;">Email Verification Required</p>
        </div>
        
        <div style="margin-bottom: 20px;">
          <h2 style="color: #333; font-size: 20px; margin-bottom: 10px;">Welcome, ${firstName}!</h2>
          <p style="color: #333; font-size: 16px; line-height: 1.5;">
            Please verify your email address to activate your TeamSafe account.
          </p>
        </div>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${verifyUrl}" 
             style="background-color: #2563eb; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; display: inline-block; font-weight: bold; font-size: 16px;">
            Verify Email Address
          </a>
        </div>
        
        <div style="background-color: #f8f9fa; padding: 15px; border-radius: 6px; margin: 20px 0;">
          <p style="color: #666; font-size: 14px; margin: 0;">
            This verification link will expire in 24 hours.
          </p>
        </div>
        
        <div style="border-top: 1px solid #e9ecef; padding-top: 20px; margin-top: 30px;">
          <p style="color: #666; font-size: 13px; line-height: 1.4;">
            If you did not create a TeamSafe account, please ignore this email.
          </p>
          <p style="color: #666; font-size: 12px; margin-top: 15px;">
            TeamSafe
          </p>
        </div>
      </div>
    `
  };
  
  return await sendEmail(emailParams);
}

export async function sendWelcomeEmail(email: string, firstName: string, baseUrl?: string): Promise<boolean> {
  const finalBaseUrl = baseUrl || 'http://localhost:5000';
  const loginUrl = `${finalBaseUrl}/auth`;
  
  const emailParams: EmailParams = {
    to: email,
    from: 'cfneveu@gmail.com',
    subject: 'Welcome to TeamSafe - Registration Confirmed',
    text: `Welcome to TeamSafe, ${firstName}!

Your registration has been successfully completed.

Your account email: ${email}

You can now log in to TeamSafe and start using the team safety management features:
${loginUrl}

Getting Started:
1. Log in to your account
2. Join an existing team using a team code, or create your own team
3. Set your work location and start tracking visits

TeamSafe`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 20px;">
        <div style="border-bottom: 3px solid #2563eb; margin-bottom: 20px; padding-bottom: 10px;">
          <h1 style="color: #2563eb; margin: 0; font-size: 24px;">TeamSafe</h1>
          <p style="color: #666; margin: 5px 0 0 0; font-size: 14px;">Registration Confirmed</p>
        </div>
        
        <div style="margin-bottom: 20px;">
          <h2 style="color: #333; font-size: 20px; margin-bottom: 10px;">Welcome, ${firstName}!</h2>
          <p style="color: #333; font-size: 16px; line-height: 1.5;">
            Your registration has been successfully completed.
          </p>
        </div>
        
        <div style="background-color: #f8f9fa; padding: 15px; border-radius: 6px; margin: 20px 0;">
          <p style="color: #333; font-size: 14px; margin: 0;">
            <strong>Account Email:</strong> ${email}
          </p>
        </div>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${loginUrl}" 
             style="background-color: #2563eb; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; display: inline-block; font-weight: bold; font-size: 16px;">
            Log In to TeamSafe
          </a>
        </div>
        
        <div style="margin: 25px 0;">
          <h3 style="color: #333; font-size: 16px; margin-bottom: 15px;">Getting Started:</h3>
          <ol style="color: #555; font-size: 14px; line-height: 1.8; padding-left: 20px;">
            <li>Log in to your account</li>
            <li>Join an existing team using a team code, or create your own team</li>
            <li>Set your work location and start tracking visits</li>
          </ol>
        </div>
        
        <div style="border-top: 1px solid #e9ecef; padding-top: 20px; margin-top: 30px;">
          <p style="color: #666; font-size: 12px; margin-top: 15px;">
            TeamSafe
          </p>
        </div>
      </div>
    `
  };
  
  return await sendEmail(emailParams);
}

export async function sendPasswordResetEmail(email: string, resetToken: string, baseUrl?: string): Promise<boolean> {
  // Use provided baseUrl or localhost for development
  const finalBaseUrl = baseUrl || 'http://localhost:5000';
  const resetUrl = `${finalBaseUrl}/reset-password?token=${resetToken}`;
  
  // Use the verified sender address for this Brevo account
  const emailParams: EmailParams = {
    to: email,
    from: 'cfneveu@gmail.com',
    subject: 'TeamSafe - Password Reset Request',
    text: `TeamSafe - Password Reset Request

You have requested to reset your password for your TeamSafe account.

Reset Link: ${resetUrl}

This link will expire in 1 hour for your protection.

If you did not request this password reset, please disregard this message.

TeamSafe`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 20px;">
        <div style="border-bottom: 3px solid #2563eb; margin-bottom: 20px; padding-bottom: 10px;">
          <h1 style="color: #2563eb; margin: 0; font-size: 24px;">TeamSafe</h1>
          <p style="color: #666; margin: 5px 0 0 0; font-size: 14px;">Password Reset Request</p>
        </div>
        
        <div style="margin-bottom: 30px;">
          <p style="color: #333; font-size: 16px; line-height: 1.5;">
            You have requested to reset your password for your TeamSafe account.
          </p>
        </div>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="${resetUrl}" 
             style="background-color: #2563eb; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; display: inline-block; font-weight: bold; font-size: 16px;">
            Reset Your Password
          </a>
        </div>
        
        <div style="background-color: #f8f9fa; padding: 15px; border-radius: 6px; margin: 20px 0;">
          <p style="color: #666; font-size: 14px; margin: 0; line-height: 1.4;">
            This link will expire in 1 hour for your protection.
          </p>
        </div>
        
        <div style="border-top: 1px solid #e9ecef; padding-top: 20px; margin-top: 30px;">
          <p style="color: #666; font-size: 13px; line-height: 1.4;">
            If you did not request this password reset, please disregard this message.
          </p>
          <p style="color: #666; font-size: 12px; margin-top: 15px;">
            TeamSafe
          </p>
        </div>
      </div>
    `
  };
  
  return await sendEmail(emailParams);
}