import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { storage } from "./storage";
import { setupAuth, hashPassword } from "./auth";
import { sendPasswordResetEmail, sendWelcomeEmail, sendVerificationEmail } from "./emailService";
import crypto from "crypto";
import {
  insertVisitSchema,
  updateSafetyStatusSchema,
  insertAlertSchema,
  createManualUserSchema,
  updateUserProfileSchema,
  createTeamSchema,
  joinTeamSchema,
  searchTeamsSchema,
  requestPasswordResetSchema,
  resetPasswordSchema,
  changePasswordSchema,
  insertUserSchema,
  registerIndividualSchema,
  type User,
  type Team,
  type CreateTeam,
  type JoinTeam,
  type RegisterIndividual
} from "@shared/schema";

// Export storage for use in other modules
export { storage };

// Manual alert schema for validation
const manualAlertSchema = z.object({
  message: z.string().min(1).max(500).optional(),
  location: z.object({
    latitude: z.number(),
    longitude: z.number()
  }).optional()
});

// Helper functions for session-based team management
function setActiveTeam(req: any, teamId: string): void {
  req.session.activeTeamId = teamId;
}

function getActiveTeam(req: any): string | undefined {
  return req.session.activeTeamId;
}

function requireActiveTeam(req: any): string {
  // This function should only be called after requireTeam middleware
  // which guarantees activeTeamId exists
  const teamId = req.session.activeTeamId;
  if (!teamId) {
    throw new Error("Active team required but not found in session");
  }
  return teamId;
}

function clearActiveTeam(req: any): void {
  delete req.session.activeTeamId;
}

// Helper function to validate team membership (backward compatibility)
async function validateTeamMembership(userId: string, teamId: string): Promise<boolean> {
  // In the current single-team model, check if user.teamId matches
  const user = await storage.getUser(userId);
  return user ? user.teamId === teamId : false;
}

// Middleware to require team membership for team-scoped routes
async function requireTeam(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ message: "Authentication required" });
  }
  
  // Use session-based active team instead of user.teamId
  if (!req.session.activeTeamId) {
    return res.status(403).json({ 
      message: "Select an active team first", 
      requiresTeam: true 
    });
  }
  
  // Verify membership using storage (works with current single-team model)
  const isMember = await validateTeamMembership(req.user.id, req.session.activeTeamId);
  if (!isMember) {
    // Clear invalid active team and require reselection
    clearActiveTeam(req);
    return res.status(403).json({ 
      message: "You are not a member of the selected team", 
      requiresTeam: true 
    });
  }
  
  next();
}

// Helper function to safely serialize user data (NEVER include password hash)
function safeUserData(user: User, requestingUser?: User) {
  const baseData = {
    id: user.id,
    username: user.username,
    email: user.email,
    firstName: user.firstName,
    lastName: user.lastName,
    role: user.role,
    teamId: user.teamId,
    workPhone: user.workPhone,
    workLocation: user.workLocation,
    profileImageUrl: user.profileImageUrl,
    createdAt: user.createdAt,
    updatedAt: user.updatedAt,
  };

  // Only include personal phone numbers if requesting user is a duty manager
  // OR if user is viewing their own data
  if (requestingUser?.role === "duty_manager" || requestingUser?.id === user.id) {
    return {
      ...baseData,
      personalPhone: user.personalPhone,
    };
  }

  // Return without personal phone for regular team members viewing others
  return baseData;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware - username/password authentication
  setupAuth(app);
  
  // Authentication middleware
  function isAuthenticated(req: any, res: any, next: any) {
    if (req.isAuthenticated()) {
      return next();
    } else {
      return res.status(401).json({ message: "Unauthorized" });
    }
  }

  // Legacy auth route for compatibility (returns safe user data)
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      // Update last active timestamp
      await storage.updateUserLastActive(userId);
      // Return safe user data without password hash - user viewing their own profile
      res.json(safeUserData(user, user));
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Alias for compatibility - some components use /api/user
  app.get('/api/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      // Update last active timestamp
      await storage.updateUserLastActive(userId);
      // Return safe user data without password hash - user viewing their own profile
      res.json(safeUserData(user, user));
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Profile update route
  app.patch('/api/profile', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.id;
      
      const validatedData = updateUserProfileSchema.parse(req.body);
      
      const updatedUser = await storage.updateUserProfile(userId, validatedData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Return safe user data without password hash - user viewing their own profile
      const responseData = safeUserData(updatedUser, updatedUser);
      
      res.json(responseData);
    } catch (error) {
      console.error("Error updating profile:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  // SECURITY FIX: Removed insecure self-promotion endpoint
  // Role changes are now handled through proper team management by duty managers only



  // Visit routes
  app.post('/api/visits', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const clinicianId = req.user.id;
      const teamId = requireActiveTeam(req);
      
      // Check if clinician already has an active visit
      const activeVisit = await storage.getActiveVisitByClinicianId(teamId, clinicianId);
      if (activeVisit) {
        return res.status(400).json({ message: "You already have an active visit. Please complete it first." });
      }
      
      const parsedVisitData = insertVisitSchema.parse(req.body);
      const visit = await storage.createVisit(teamId, clinicianId, parsedVisitData);
      
      res.json(visit);
    } catch (error) {
      console.error("Error creating visit:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid visit data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create visit" });
    }
  });

  app.get('/api/visits', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const clinicianId = req.user.id;
      const teamId = requireActiveTeam(req);
      const visits = await storage.getVisitsByClinicianId(teamId, clinicianId);
      res.json(visits);
    } catch (error) {
      console.error("Error fetching visits:", error);
      res.status(500).json({ message: "Failed to fetch visits" });
    }
  });

  app.get('/api/visits/active', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const clinicianId = req.user.id;
      const teamId = requireActiveTeam(req);
      const activeVisit = await storage.getActiveVisitByClinicianId(teamId, clinicianId);
      res.json(activeVisit || null);
    } catch (error) {
      console.error("Error fetching active visit:", error);
      res.status(500).json({ message: "Failed to fetch active visit" });
    }
  });

  app.patch('/api/visits/:visitId/complete', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const teamId = requireActiveTeam(req);
      const user = await storage.getUser(userId);
      const { visitId } = req.params;
      
      // Get the visit to check ownership
      const userVisits = await storage.getVisitsByClinicianId(teamId, userId);
      const visit = userVisits.find(v => v.id === visitId);
      
      // CRITICAL: Check authorization - user owns visit OR is duty manager
      if (!visit && user?.role !== "duty_manager") {
        return res.status(404).json({ message: "Visit not found" });
      }
      
      if (!visit && user?.role === "duty_manager") {
        // For duty managers, verify visit exists in system
        const allUsers = await storage.getAllUsers(teamId);
        let systemVisit = null;
        for (const otherUser of allUsers) {
          const otherVisits = await storage.getVisitsByClinicianId(teamId, otherUser.id);
          systemVisit = otherVisits.find(v => v.id === visitId);
          if (systemVisit) break;
        }
        if (!systemVisit) {
          return res.status(404).json({ message: "Visit not found" });
        }
      }
      
      const completedVisit = await storage.updateVisitStatus(teamId, visitId, "completed", new Date());
      if (!completedVisit) {
        return res.status(404).json({ message: "Visit not found" });
      }
      res.json(completedVisit);
    } catch (error) {
      console.error("Error completing visit:", error);
      res.status(500).json({ message: "Failed to complete visit" });
    }
  });

  // Safety status routes
  app.get('/api/safety-status', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const clinicianId = req.user.id;
      const teamId = requireActiveTeam(req);
      const status = await storage.getSafetyStatus(teamId, clinicianId);
      res.json(status);
    } catch (error) {
      console.error("Error fetching safety status:", error);
      res.status(500).json({ message: "Failed to fetch safety status" });
    }
  });

  app.post('/api/safety-status', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const clinicianId = req.user.id;
      const teamId = requireActiveTeam(req);
      const statusData = updateSafetyStatusSchema.parse(req.body);
      
      // Normalize any location input to what3words or neutral placeholder only
      if (statusData.location) {
        statusData.location = await normalizeLocation(statusData.location);
      }
      
      const status = await storage.updateSafetyStatus(teamId, clinicianId, statusData);
      res.json(status);
    } catch (error) {
      console.error("Error updating safety status:", error);
      res.status(500).json({ message: "Failed to update safety status" });
    }
  });

  // Team status routes (for dashboard)
  app.get('/api/team-status', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const teamId = requireActiveTeam(req);
      const user = await storage.getUser(req.user.id);
      if (user?.role !== "duty_manager" && user?.role !== "teamsafe_member") {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const allUsers = await storage.getAllUsers(teamId);
      const safetyStatuses = await storage.getAllSafetyStatuses(teamId);
      
      // Filter users who were active today (same calendar day)
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const activeToday = allUsers.filter(user => {
        if (!user.lastActiveAt) return false;
        const userActiveDate = new Date(user.lastActiveAt);
        userActiveDate.setHours(0, 0, 0, 0);
        return userActiveDate.getTime() === today.getTime();
      });
      
      // Get all active visits
      const activeVisits: { [userId: string]: any } = {};
      for (const user of activeToday) {
        try {
          const visit = await storage.getActiveVisitByClinicianId(teamId, user.id);
          if (visit) {
            activeVisits[user.id] = visit;
          }
        } catch (error) {
          // Continue if user has no active visits
        }
      }
      
      // Return individual user status (no joint visit grouping) and filter out resolved emergencies
      const teamStatus = [];
      
      for (const user of activeToday) {
        const status = safetyStatuses.find(s => s.clinicianId === user.id);
        const activeVisit = activeVisits[user.id];
        
        // If user has emergency status, check if they have unresolved emergency alerts
        if (status?.status === "emergency") {
          const userAlerts = await storage.getAlertsByClinicianId(teamId, user.id);
          const hasActiveEmergencyAlert = userAlerts.some(alert => 
            alert.type === "manual_alert" && !alert.isResolved
          );
          // Only include emergency users if they have active emergency alerts
          if (hasActiveEmergencyAlert) {
            teamStatus.push({
              ...safeUserData(user, await storage.getUser(req.user.id)), // Safe user data with privacy controls
              safetyStatus: status,
              activeVisit: activeVisit,
            });
          }
        } else {
          // Include all non-emergency users
          teamStatus.push({
            ...safeUserData(user, await storage.getUser(req.user.id)), // Safe user data with privacy controls
            safetyStatus: status,
            activeVisit: activeVisit,
          });
        }
      }
      
      res.json(teamStatus);
    } catch (error) {
      console.error("Error fetching team status:", error);
      res.status(500).json({ message: "Failed to fetch team status" });
    }
  });

  // Alert routes
  app.get('/api/alerts', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const teamId = requireActiveTeam(req);
      const user = await storage.getUser(userId);
      
      // All users can see all alerts for better team coordination
      const alerts = await storage.getUnresolvedAlerts(teamId);
      
      // Add user information to each alert (excluding PII like email)
      const alertsWithUserInfo = await Promise.all(
        alerts.map(async (alert) => {
          const alertUser = await storage.getUser(alert.clinicianId);
          return {
            ...alert,
            user: alertUser ? {
              firstName: alertUser.firstName,
              lastName: alertUser.lastName
            } : null
          };
        })
      );
      
      res.json(alertsWithUserInfo);
    } catch (error) {
      console.error("Error fetching alerts:", error);
      res.status(500).json({ message: "Failed to fetch alerts" });
    }
  });

  app.post('/api/alerts', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const teamId = requireActiveTeam(req);
      const user = await storage.getUser(userId);
      const alertData = insertAlertSchema.parse(req.body);
      
      // CRITICAL: Enforce authorization for alert creation
      if (user?.role !== "duty_manager") {
        // Clinicians can only create alerts for themselves
        if (alertData.clinicianId !== userId) {
          return res.status(403).json({ message: "Access denied - you can only create alerts for yourself" });
        }
      }
      // Duty managers can create alerts for any clinician (no additional check needed)
      
      const alert = await storage.createAlert(teamId, alertData);
      res.json(alert);
    } catch (error) {
      console.error("Error creating alert:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data provided", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create alert" });
    }
  });

  app.patch('/api/alerts/:alertId/read', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const teamId = requireActiveTeam(req);
      const user = await storage.getUser(userId);
      const { alertId } = req.params;
      
      // Check authorization - user owns the alert OR is duty manager
      const userAlerts = await storage.getAlertsByClinicianId(teamId, userId);
      const alert = userAlerts.find(a => a.id === alertId);
      
      if (!alert && user?.role !== "duty_manager") {
        return res.status(404).json({ message: "Alert not found" });
      }
      
      if (!alert && user?.role === "duty_manager") {
        // For duty managers, check if alert exists in system
        const allAlerts = await storage.getUnresolvedAlerts(teamId);
        const systemAlert = allAlerts.find(a => a.id === alertId);
        if (!systemAlert) {
          return res.status(404).json({ message: "Alert not found" });
        }
      }
      
      const readAlert = await storage.markAlertAsRead(teamId, alertId);
      if (!readAlert) {
        return res.status(404).json({ message: "Alert not found" });
      }
      res.json(readAlert);
    } catch (error) {
      console.error("Error marking alert as read:", error);
      res.status(500).json({ message: "Failed to mark alert as read" });
    }
  });

  // Check for alert updates endpoint (for polling)
  app.get('/api/alerts/check-updates', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const teamId = requireActiveTeam(req);
      const ifModifiedSince = req.headers['if-modified-since'];
      
      // Check if there have been any alert resolutions affecting this user recently
      const cutoffTime = ifModifiedSince ? new Date(ifModifiedSince) : new Date(Date.now() - 10000); // Default to last 10 seconds
      
      // For simplicity, we'll check the user's current safety status update time
      const safetyStatus = await storage.getSafetyStatus(teamId, userId);
      const hasUpdates = safetyStatus?.lastUpdate && new Date(safetyStatus.lastUpdate) > cutoffTime;
      
      res.json({ hasUpdates: !!hasUpdates });
    } catch (error) {
      console.error("Error checking for alert updates:", error);
      res.status(500).json({ message: "Failed to check for updates" });
    }
  });

  app.patch('/api/alerts/:alertId/resolve', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      // Allow any authenticated user to resolve alerts
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const { alertId } = req.params;
      
      const teamId = requireActiveTeam(req);
      
      // Verify the alert exists in the system before resolving
      const allAlerts = await storage.getUnresolvedAlerts(teamId);
      const existingAlert = allAlerts.find(a => a.id === alertId);
      if (!existingAlert) {
        return res.status(404).json({ message: "Alert not found" });
      }
      
      // AUDIT LOG: Alert resolution
      console.log(`🔍 AUDIT: Alert resolved - AlertID: ${alertId}, ResolvedBy: ${user.firstName || 'Unknown'} ${user.lastName || ''} (${user.email || userId}), Time: ${new Date().toISOString()}`);
      
      const alert = await storage.markAlertAsResolved(teamId, alertId);
      if (!alert) {
        return res.status(404).json({ message: "Alert not found" });
      }

      // Automatically update safety status to "safe" when resolving manual alerts
      if (existingAlert.type === "manual_alert") {
        let statusUpdated = false;
        let visitCompleted = false;
        
        try {
          // Step 1: Update safety status to "safe"
          await storage.updateSafetyStatus(teamId, existingAlert.clinicianId, { status: "safe" });
          statusUpdated = true;
          console.log(`🟢 Auto-updated safety status to 'safe' for clinician ${existingAlert.clinicianId} after resolving manual alert`);
          
          // Step 2: Complete any active visit automatically when resolving emergency alert
          const activeVisit = await storage.getActiveVisitByClinicianId(teamId, existingAlert.clinicianId);
          if (activeVisit) {
            await storage.updateVisitStatus(teamId, activeVisit.id, "completed", new Date());
            visitCompleted = true;
            console.log(`✅ Auto-completed active visit ${activeVisit.id} for clinician ${existingAlert.clinicianId} after resolving emergency alert`);
          }
          
          // Operations completed successfully - polling will detect the changes
          console.log(`✅ Alert resolution completed for user ${existingAlert.clinicianId} (status: ${statusUpdated}, visit: ${visitCompleted})`);
        } catch (error) {
          console.error("Failed to auto-update safety status and complete visit after resolving manual alert:", error);
        }
      }

      res.json(alert);
    } catch (error) {
      console.error("Error resolving alert:", error);
      res.status(500).json({ message: "Failed to resolve alert" });
    }
  });



  // Safe safety status update route (no location required)
  app.patch('/api/safety-status/safe', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const clinicianId = req.user.id;
      const teamId = requireActiveTeam(req);
      
      // Update safety status to safe
      const safetyStatus = await storage.updateSafeSafetyStatus(teamId, clinicianId);
      
      // Also complete any active visit automatically
      const activeVisit = await storage.getActiveVisitByClinicianId(teamId, clinicianId);
      if (activeVisit) {
        await storage.updateVisitStatus(teamId, activeVisit.id, "completed", new Date());
      }
      
      res.json(safetyStatus);
    } catch (error) {
      console.error("Error updating safe safety status:", error);
      res.status(500).json({ message: "Failed to update safety status" });
    }
  });

  // Interface definitions for alert notification types
  interface WhatsAppAlert {
    manager: string;
    url: string;
  }

  interface PhoneContact {
    name: string;
    phone: string;
  }

  // Helper function to normalize any location input to what3words or neutral placeholder
  async function normalizeLocation(input: string | null | undefined): Promise<string> {
    if (!input) return "Location unavailable";
    
    const location = input.trim();
    if (!location) return "Location unavailable";
    
    // Check if already a valid what3words address
    const what3wordsPattern = /^(?:📍\s*)?([a-z]+(?:-[a-z]+)?\.){2}[a-z]+(?:-[a-z]+)?$/;
    if (what3wordsPattern.test(location)) {
      // Ensure it has the emoji prefix
      return location.startsWith('📍') ? location : `📍 ${location}`;
    }
    
    // Try to extract coordinates from any format for conversion
    const coordinatePatterns = [
      // Decimal degrees: 51.5074, -0.1278 or lat=51.5 lon=-0.1
      /(-?\d+\.?\d*)[,\s]*(-?\d+\.?\d*)/,
      // DMS or cardinal: N51°30'26" W0°7'39" or 51 30 26 N 0 7 39 W
      /(?:([NS])\s*)?(\d+)(?:[°\s]\s*(\d+))?(?:[′'\s]\s*(\d+))?(?:[″"\s])?\s*([NS])?\s*[,\s]*\s*(?:([EW])\s*)?(\d+)(?:[°\s]\s*(\d+))?(?:[′'\s]\s*(\d+))?(?:[″"\s])?\s*([EW])?/i
    ];
    
    for (const pattern of coordinatePatterns) {
      const match = location.match(pattern);
      if (match) {
        let latitude: number, longitude: number;
        
        if (pattern === coordinatePatterns[0]) {
          // Simple decimal format
          latitude = parseFloat(match[1]);
          longitude = parseFloat(match[2]);
        } else {
          // Complex DMS format - simplified extraction
          const nums = location.match(/\d+\.?\d*/g);
          if (nums && nums.length >= 2) {
            latitude = parseFloat(nums[0]);
            longitude = parseFloat(nums[1]);
            
            // Handle cardinal directions
            if (/[SW]/i.test(location)) {
              if (latitude > 0) latitude = -latitude;
              if (longitude > 0) longitude = -longitude;
            }
          } else {
            continue;
          }
        }
        
        // Validate coordinate ranges
        if (latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180) {
          const what3wordsAddress = await convertToWhat3Words(latitude, longitude);
          return what3wordsAddress ? `📍 ${what3wordsAddress}` : "Location unavailable";
        }
      }
    }
    
    // If no coordinates found, use neutral placeholder
    return "Location unavailable";
  }

  // Function to convert GPS coordinates to what3words address with better fallback
  async function convertToWhat3Words(latitude: number, longitude: number): Promise<string | null> {
    try {
      const apiKey = process.env.WHAT3WORDS_API_KEY;
      if (!apiKey) {
        console.warn("what3words API key not configured - using coordinate fallback");
        return null;
      }

      const response = await fetch(
        `https://api.what3words.com/v3/convert-to-3wa?coordinates=${latitude},${longitude}&key=${apiKey}&format=json`
      );

      if (!response.ok) {
        if (response.status === 402) {
          console.warn("what3words API quota exceeded or requires payment - using coordinate fallback");
        } else if (response.status === 401) {
          console.warn("what3words API authentication failed - check API key");
        } else {
          console.error("what3words API error:", response.status, response.statusText);
        }
        return null;
      }

      const data = await response.json();
      if (data.words) {
        console.log(`✅ Converted GPS coordinates to what3words: ${data.words}`);
        return data.words; // Returns something like "table.chair.lamp"
      }

      console.warn("what3words API returned no words for coordinates:", latitude, longitude);
      return null;
    } catch (error) {
      console.error("Error converting to what3words:", error);
      return null;
    }
  }

  // Helper to format coordinates in a user-friendly way as fallback
  function formatCoordinatesForHumans(latitude: number, longitude: number): string {
    const latDir = latitude >= 0 ? 'N' : 'S';
    const lonDir = longitude >= 0 ? 'E' : 'W';
    const latAbs = Math.abs(latitude).toFixed(4);
    const lonAbs = Math.abs(longitude).toFixed(4);
    return `${latAbs}°${latDir}, ${lonAbs}°${lonDir}`;
  }

  // Helper to validate and clean phone numbers for SMS
  function validatePhoneNumber(phone: string): string | null {
    if (!phone) return null;
    
    // Remove all non-digit characters
    const cleaned = phone.replace(/\D/g, '');
    
    // Must have at least 10 digits and no more than 15 (international format)
    if (cleaned.length < 10 || cleaned.length > 15) {
      return null;
    }
    
    // Add + prefix for international format if not present
    return cleaned.startsWith('1') ? `+${cleaned}` : `+${cleaned}`;
  }

  // Manual alert creation route
  app.post('/api/alerts/manual', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const userId = req.user.id;
      
      // Validate request body with Zod
      const body = manualAlertSchema.parse(req.body);
      const { message, location } = body;
      
      // Debug logging for location data (NODE_ENV check for safety)
      if (process.env.NODE_ENV === 'development') {
        console.log("🔍 Manual alert request body:", JSON.stringify(req.body, null, 2));
        console.log("📍 Extracted location:", location ? `${location.latitude}, ${location.longitude}` : "None");
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Get current user location
      let userLocation = "Location unknown";
      
      // Process location data first before creating alert
      if (location) {
        // Try to convert GPS coordinates to what3words address first
        const what3wordsAddress = await convertToWhat3Words(location.latitude, location.longitude);
        
        if (what3wordsAddress) {
          // Success! Use what3words address with clear formatting
          userLocation = `📍 ${what3wordsAddress}`;
          console.log(`✅ Using what3words address: ${what3wordsAddress}`);
        } else {
          // what3words failed, provide coordinates in a clear format
          const friendlyCoords = formatCoordinatesForHumans(location.latitude, location.longitude);
          userLocation = `📍 ${friendlyCoords}`;
          console.log(`⚠️ what3words failed, using coordinates: ${friendlyCoords}`);
        }
        
        // Update the user's safety status with the location
        try {
          const teamId = requireActiveTeam(req);
          await storage.updateSafetyStatus(teamId, userId, {
            status: "emergency",
            location: userLocation,
          });
        } catch (error) {
          console.warn("Failed to update safety status with location:", error);
        }
      } else {
        // No GPS coordinates provided, fallback to existing safety status location
        const teamId = requireActiveTeam(req);
        const userSafetyStatus = await storage.getSafetyStatus(teamId, userId);
        userLocation = userSafetyStatus?.location || "Location unknown";
      }
      
      // Create manual alert with location
      const teamId = requireActiveTeam(req);
      const alert = await storage.createAlert(teamId, {
        clinicianId: userId,
        type: "manual_alert",
        title: "Manual Alert Raised",
        description: message || `${user.firstName || 'Clinician'} has raised a manual alert and needs assistance.`,
        priority: "high",
        severity: "red",
        location: userLocation, // Include location in the alert
      });
      
      // Get duty managers for contact information
      const allUsers = await storage.getAllUsers(teamId);
      const dutyManagers = allUsers.filter(u => u.role === "duty_manager");
      
      const userName = `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.email || 'A team member';
      
      // Collect and validate phone numbers for SMS messaging
      // For privacy: only use work phones for emergency SMS, never personal phones
      const phoneNumbers: PhoneContact[] = [];
      dutyManagers.forEach(manager => {
        const rawPhone = manager.workPhone; // Only use work phone for emergency alerts
        if (rawPhone) {
          const validatedPhone = validatePhoneNumber(rawPhone);
          if (validatedPhone) {
            phoneNumbers.push({
              name: `${manager.firstName || ''} ${manager.lastName || ''}`.trim() || 'Duty Manager',
              phone: validatedPhone
            });
          }
        }
      });
      
      // Create SMS message content
      const smsMessage = `🚨 EMERGENCY ALERT - TeamSafe\n\n${userName} needs immediate assistance.\n\nLocation: ${userLocation}\n\nPlease contact them urgently to provide help.`;
      
      // Generate secure SMS links for each duty manager
      const smsLinks: string[] = [];
      phoneNumbers.forEach(contact => {
        const encodedMessage = encodeURIComponent(smsMessage);
        // Only use sms: scheme for security
        smsLinks.push(`sms:${contact.phone}?&body=${encodedMessage}`);
      });
      
      let responseMessage = "";
      if (dutyManagers.length > 0) {
        responseMessage = `Emergency alert created! You can send SMS messages to ${dutyManagers.length} duty manager(s) using your phone's messaging app.`;
      } else {
        responseMessage = "Emergency alert created, but no duty managers are configured. Please contact your administrator to set up emergency contacts.";
      }
      
      // Log the emergency alert generation
      console.log(`🚨 Emergency alert raised by ${user.firstName || 'Clinician'}`);
      console.log(`📱 SMS links generated for ${dutyManagers.length} duty manager(s), ${phoneNumbers.length} phone numbers available`);
      
      res.json({ 
        alert, 
        message: responseMessage,
        smsLinks: smsLinks,
        phoneNumbers: phoneNumbers,
        hasContacts: phoneNumbers.length > 0,
        dutyManagerCount: dutyManagers.length,
        contactableManagers: dutyManagers.length
      });
    } catch (error) {
      console.error("Error creating manual alert:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data provided", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create alert" });
    }
  });

  // Route to promote first user to duty manager (only if no duty manager exists)
  app.post('/api/promote-first-user', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const teamId = requireActiveTeam(req);
      // Check if any duty manager already exists
      const allUsers = await storage.getAllUsers(teamId);
      const existingDutyManager = allUsers.find(user => user.role === "duty_manager");
      
      if (existingDutyManager) {
        return res.status(403).json({ 
          message: "A duty manager already exists. Use team management to change roles." 
        });
      }
      
      // Allow promotion only if no duty manager exists
      const userId = req.user.id;
      const updatedUser = await storage.updateUserRole(teamId, userId, "duty_manager");
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      // Return safe user data
      res.json({ message: "You have been promoted to duty manager", user: safeUserData(updatedUser, updatedUser) });
    } catch (error) {
      console.error("Error promoting user:", error);
      res.status(500).json({ message: "Failed to promote user" });
    }
  });

  // Team management routes - anyone can access
  app.get('/api/team-management', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const teamId = requireActiveTeam(req);
      // Get requesting user for privacy controls
      const requestingUser = await storage.getUser(req.user.id);
      if (!requestingUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const allUsers = await storage.getAllUsers(teamId);
      // Apply privacy controls to all user data
      const safeUsers = allUsers.map(user => safeUserData(user, requestingUser));
      res.json(safeUsers);
    } catch (error) {
      console.error("Error fetching team management data:", error);
      res.status(500).json({ message: "Failed to fetch team management data" });
    }
  });

  app.patch('/api/team-management/:userId/role', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const currentUserId = req.user.id;
      const teamId = requireActiveTeam(req);
      const { userId } = req.params;
      const { role } = req.body;
      
      if (!["teamsafe_member", "duty_manager"].includes(role)) {
        return res.status(400).json({ message: "Invalid role. Must be 'teamsafe_member' or 'duty_manager'" });
      }
      
      // Any authenticated user can change any user's role
      // If promoting someone to duty manager, automatically demote existing duty managers
      if (role === "duty_manager") {
        const allUsers = await storage.getAllUsers(teamId);
        const currentDutyManagers = allUsers.filter(u => u.role === "duty_manager" && u.id !== userId);
        
        // Demote all existing duty managers to team members
        for (const dutyManager of currentDutyManagers) {
          await storage.updateUserRole(teamId, dutyManager.id, "teamsafe_member");
        }
      }
      
      const updatedUser = await storage.updateUserRole(teamId, userId, role);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Return safe user data with privacy controls
      const requestingUser = await storage.getUser(currentUserId);
      res.json(safeUserData(updatedUser, requestingUser));
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  // Create team member manually
  app.post('/api/team-management/users', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const teamId = requireActiveTeam(req);
      const userData = createManualUserSchema.parse(req.body);
      
      // Check if user with this email already exists (case-insensitive)
      const allUsers = await storage.getAllUsers(teamId);
      const existingUser = allUsers.find(u => u.email?.toLowerCase() === userData.email.toLowerCase());
      if (existingUser) {
        return res.status(400).json({ message: "A user with this email address already exists" });
      }
      
      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(teamId, userData.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Hash password before storage - CRITICAL SECURITY
      const hashedPassword = await hashPassword(userData.password);
      
      const newUser = await storage.createManualUser(teamId, {
        ...userData,
        password: hashedPassword,
      });
      
      // Return safe user data (no password hash)
      res.json({
        id: newUser.id,
        username: newUser.username,
        email: newUser.email,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        role: newUser.role,
        createdAt: newUser.createdAt,
        updatedAt: newUser.updatedAt,
      });
    } catch (error) {
      console.error("Error creating team member:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data provided", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create team member" });
    }
  });

  app.delete('/api/team-management/:userId', isAuthenticated, requireTeam, async (req: any, res) => {
    try {
      const teamId = requireActiveTeam(req);
      const { userId } = req.params;
      
      // Prevent deleting yourself
      if (userId === req.user.id) {
        return res.status(400).json({ message: "Cannot delete your own account" });
      }
      
      // Prevent deleting the last duty manager
      const allUsers = await storage.getAllUsers(teamId);
      const dutyManagers = allUsers.filter(u => u.role === "duty_manager");
      const userToDelete = allUsers.find(u => u.id === userId);
      if (userToDelete?.role === "duty_manager" && dutyManagers.length <= 1) {
        return res.status(400).json({ message: "Cannot delete the last duty manager" });
      }
      
      const deleted = await storage.deleteUser(teamId, userId);
      if (!deleted) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ message: "User deleted successfully" });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // Email/password authentication routes
  app.post('/api/auth/login', async (req: any, res) => {
    try {
      const { username, email, password } = req.body;
      const loginIdentifier = username || email; // Accept either username or email
      
      if (!loginIdentifier || !password) {
        return res.status(400).json({ message: "Email/username and password are required" });
      }
      
      // Find user by email (email is unique across system)
      const user = await storage.getUserByEmail(loginIdentifier.toLowerCase());
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Verify password
      const passwordValid = await bcrypt.compare(password, user.password);
      if (!passwordValid) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Check if email is verified
      if (!user.emailVerified) {
        console.log(`🔒 Unverified login attempt for ${user.email} - prompting to verify`);
        return res.status(403).json({ 
          message: "Please verify your email before logging in.",
          requiresVerification: true,
          email: user.email
        });
      }
      
      // Log in user using passport
      req.login(user, (err: any) => {
        if (err) {
          console.error("Login error:", err);
          return res.status(500).json({ message: "Login failed" });
        }
        
        // Automatically set active team if user has an existing team (backward compatibility)
        if (user.teamId) {
          setActiveTeam(req, user.teamId);
        }
        
        console.log(`✅ User logged in: ${user.email}`);
        res.json({ 
          message: "Login successful",
          user: safeUserData(user, user)
        });
      });
    } catch (error) {
      console.error("Error during login:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Email verification endpoint
  app.get('/api/auth/verify-email', async (req: any, res) => {
    try {
      const { token } = req.query;
      
      if (!token || typeof token !== 'string') {
        return res.status(400).json({ message: "Invalid verification token" });
      }
      
      const user = await storage.getUserByVerificationToken(token);
      if (!user) {
        return res.status(400).json({ message: "Invalid or expired verification token" });
      }
      
      // Check if token has expired
      if (user.verificationTokenExpiry && new Date() > new Date(user.verificationTokenExpiry)) {
        return res.status(400).json({ message: "Verification token has expired. Please register again." });
      }
      
      // Verify the user's email
      await storage.verifyUserEmail(user.id);
      
      console.log(`✅ Email verified for user: ${user.email}`);
      
      res.json({ 
        message: "Email verified successfully! You can now log in.",
        verified: true
      });
    } catch (error) {
      console.error("Error during email verification:", error);
      res.status(500).json({ message: "Verification failed" });
    }
  });

  // Resend verification email
  app.post('/api/auth/resend-verification', async (req: any, res) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }
      
      const user = await storage.getUserByEmail(email.toLowerCase());
      if (!user) {
        console.log(`⚠️ Verification resend requested for non-existent email: ${email}`);
        return res.status(404).json({ message: "No account found with this email address. Please check the email or create a new account." });
      }
      
      if (user.emailVerified) {
        return res.status(400).json({ message: "Email is already verified. You can log in now." });
      }
      
      // Generate new verification token
      const verificationToken = crypto.randomBytes(32).toString('hex');
      const tokenExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
      
      await storage.setVerificationToken(user.id, verificationToken, tokenExpiry);
      
      // Send verification email - use Replit domain for public URL
      const replitDomain = process.env.REPLIT_DOMAINS?.split(',')[0];
      const baseUrl = replitDomain ? `https://${replitDomain}` : `${req.protocol}://${req.get('host')}`;
      const emailSent = await sendVerificationEmail(
        user.email, 
        user.firstName || 'there', 
        verificationToken,
        baseUrl
      );
      
      if (emailSent) {
        console.log(`📧 Verification email resent to ${user.email}`);
        res.json({ message: "Verification email sent! Please check your inbox.", emailSent: true });
      } else {
        console.error(`❌ Failed to send verification email to ${user.email}`);
        res.status(500).json({ message: "Failed to send verification email. Please try again.", emailSent: false });
      }
    } catch (error) {
      console.error("Error resending verification:", error);
      res.status(500).json({ message: "Failed to resend verification email" });
    }
  });

  // Individual user registration (no team required)
  app.post('/api/auth/register-individual', async (req: any, res) => {
    try {
      const userData = registerIndividualSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email.toLowerCase());
      if (existingUser) {
        return res.status(400).json({ message: "User with this email already exists" });
      }
      
      // Hash password
      const hashedPassword = await hashPassword(userData.password);
      
      // Generate verification token
      const verificationToken = crypto.randomBytes(32).toString('hex');
      const tokenExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
      
      // Create user without team association
      const newUser = await storage.createIndividualUser({
        username: userData.username,
        email: userData.email.toLowerCase(),
        password: hashedPassword,
        firstName: userData.firstName,
        lastName: userData.lastName,
        role: userData.role,
      });
      
      // Store verification token
      await storage.setVerificationToken(newUser.id, verificationToken, tokenExpiry);
      
      console.log(`✅ Individual user registered: ${newUser.email}`);
      
      // Send verification email with retry - use Replit domain for public URL
      const replitDomain = process.env.REPLIT_DOMAINS?.split(',')[0];
      const baseUrl = replitDomain ? `https://${replitDomain}` : `${req.protocol}://${req.get('host')}`;
      
      let emailSent = false;
      for (let attempt = 1; attempt <= 3; attempt++) {
        console.log(`📧 Verification email attempt ${attempt}/3 for ${newUser.email}`);
        emailSent = await sendVerificationEmail(
          newUser.email, 
          newUser.firstName || 'there', 
          verificationToken,
          baseUrl
        );
        if (emailSent) {
          console.log(`📧 Verification email sent to ${newUser.email} on attempt ${attempt}`);
          break;
        }
        console.warn(`⚠️ Verification email attempt ${attempt} failed for ${newUser.email}`);
        if (attempt < 3) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      }
      
      if (!emailSent) {
        console.error(`❌ All verification email attempts failed for ${newUser.email}`);
      }
      
      // Don't auto-login - require email verification first
      // Respond immediately so the user knows registration succeeded
      res.json({ 
        message: "Registration successful. Please check your email to verify your account.", 
        requiresVerification: true,
        emailSent: emailSent
      });
    } catch (error) {
      console.error("Error during individual registration:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Registration failed" });
    }
  });

  // Legacy registration endpoint (team-based)
  app.post('/api/auth/register', async (req: any, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const { teamId, teamPassword } = req.body;
      
      if (!teamId || !teamPassword) {
        return res.status(400).json({ message: "Team selection and password are required" });
      }
      
      // Verify team exists and password is correct
      const team = await storage.getTeam(teamId);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      
      const teamPasswordValid = await bcrypt.compare(teamPassword, team.teamPassword);
      if (!teamPasswordValid) {
        return res.status(401).json({ message: "Invalid team password" });
      }
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email.toLowerCase());
      if (existingUser) {
        return res.status(400).json({ message: "User with this email already exists" });
      }
      
      // Check if username already exists in team
      const existingUsername = await storage.getUserByUsername(team.id, userData.username);
      if (existingUsername) {
        return res.status(400).json({ message: "Username already exists in this team" });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 12);
      
      // Create user
      const newUser = await storage.createUser({
        ...userData,
        teamId: team.id,
        password: hashedPassword,
        email: userData.email.toLowerCase(),
      });
      
      console.log(`✅ User registered: ${newUser.email} in team ${team.name}`);
      
      // Send welcome email (don't block registration if email fails)
      const baseUrl = `${req.protocol}://${req.get('host')}`;
      sendWelcomeEmail(newUser.email, newUser.firstName || 'there', baseUrl)
        .then(sent => {
          if (sent) {
            console.log(`📧 Welcome email sent to ${newUser.email}`);
          } else {
            console.warn(`⚠️ Failed to send welcome email to ${newUser.email}`);
          }
        })
        .catch(err => console.error(`❌ Error sending welcome email:`, err));
      
      // Automatically log in the user after registration
      req.login(newUser, (err: any) => {
        if (err) {
          console.error("Auto-login after registration failed:", err);
          return res.status(500).json({ message: "Registration successful but login failed" });
        }
        
        console.log(`✅ User auto-logged in after registration: ${newUser.email}`);
        
        // Return safe user data with authentication session established
        res.status(201).json({
          message: "Registration successful",
          user: safeUserData(newUser, newUser),
          team: {
            id: team.id,
            name: team.name,
          }
        });
      });
    } catch (error) {
      console.error("Error during registration:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Registration failed" });
    }
  });

  app.post('/api/auth/logout', isAuthenticated, async (req: any, res) => {
    try {
      // Clear active team from session
      clearActiveTeam(req);
      
      req.logout((err: any) => {
        if (err) {
          console.error("Logout error:", err);
          return res.status(500).json({ message: "Logout failed" });
        }
        
        console.log(`✅ User logged out`);
        res.json({ message: "Logout successful" });
      });
    } catch (error) {
      console.error("Error during logout:", error);
      res.status(500).json({ message: "Logout failed" });
    }
  });

  app.post('/api/auth/reset-password-request', async (req: any, res) => {
    try {
      const { email } = requestPasswordResetSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(email.toLowerCase());
      if (!user) {
        // For security, don't reveal if email exists
        return res.json({ message: "If the email exists, a password reset link has been sent" });
      }
      
      // Generate secure random token
      const { randomBytes } = await import('crypto');
      const resetToken = randomBytes(32).toString('hex');
      const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour from now
      
      // Store reset token
      await storage.createPasswordResetToken(user.id, resetToken, expiresAt);
      
      // Send reset email
      const baseUrl = req.get('origin') || 'http://localhost:5000';
      const emailSent = await sendPasswordResetEmail(user.email, resetToken, baseUrl);
      
      if (emailSent) {
        console.log(`✅ Password reset email sent to: ${user.email}`);
      } else {
        console.warn(`⚠️ Failed to send password reset email to: ${user.email}`);
      }
      
      res.json({ message: "If the email exists, a password reset link has been sent" });
    } catch (error) {
      console.error("Error requesting password reset:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid email address", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to process password reset request" });
    }
  });

  app.post('/api/auth/reset-password', async (req: any, res) => {
    try {
      const { token, newPassword } = resetPasswordSchema.parse(req.body);
      
      // Find and validate reset token
      const resetToken = await storage.getPasswordResetToken(token);
      if (!resetToken) {
        return res.status(400).json({ message: "Invalid or expired reset token" });
      }
      
      if (new Date() > resetToken.expiresAt) {
        return res.status(400).json({ message: "Reset token has expired" });
      }
      
      // Hash new password
      const hashedPassword = await bcrypt.hash(newPassword, 12);
      
      // Update user password
      const updatedUser = await storage.updateUserPassword(resetToken.userId, hashedPassword);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Mark token as used
      await storage.markPasswordResetTokenAsUsed(resetToken.id);
      
      // Auto-login the user by creating a session
      req.login(updatedUser, (err: any) => {
        if (err) {
          console.warn(`⚠️ Auto-login failed after password reset for: ${updatedUser.email}`);
          // Still return success since password was reset successfully
          return res.json({ 
            message: "Password reset successful",
            autoLogin: false 
          });
        }
        
        console.log(`✅ Password reset successful and user auto-logged in: ${updatedUser.email}`);
        
        res.json({ 
          message: "Password reset successful", 
          autoLogin: true,
          user: safeUserData(updatedUser)
        });
      });
    } catch (error) {
      console.error("Error resetting password:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to reset password" });
    }
  });

  // Change password for authenticated users
  app.post('/api/auth/change-password', isAuthenticated, async (req: any, res) => {
    try {
      const { currentPassword, newPassword } = changePasswordSchema.parse(req.body);
      
      // Get current user
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Verify current password
      const passwordValid = await bcrypt.compare(currentPassword, user.password);
      if (!passwordValid) {
        return res.status(401).json({ message: "Current password is incorrect" });
      }
      
      // Hash new password
      const hashedPassword = await bcrypt.hash(newPassword, 12);
      
      // Update user password
      const updatedUser = await storage.updateUserPassword(user.id, hashedPassword);
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to update password" });
      }
      
      console.log(`✅ Password changed successfully for user: ${updatedUser.email}`);
      
      // Rotate session for security (prevents session fixation)
      req.session.regenerate((err: any) => {
        if (err) {
          console.warn("Session regeneration failed after password change:", err);
          // Still return success since password was changed successfully
        }
        
        // Re-establish user session after regeneration
        req.login(updatedUser, (loginErr: any) => {
          if (loginErr) {
            console.warn("Re-login failed after password change:", loginErr);
          }
          
          res.json({ message: "Password changed successfully" });
        });
      });
    } catch (error) {
      console.error("Error changing password:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to change password" });
    }
  });

  // Team joining for authenticated users (supports multi-team membership)
  app.post('/api/teams/join', isAuthenticated, async (req: any, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const { teamCode, teamPassword } = joinTeamSchema.parse(req.body);
      
      // Look up team by code (case-insensitive)
      const team = await storage.getTeamByCode(teamCode);
      if (!team) {
        return res.status(404).json({ message: "Team not found. Please check the team code and try again." });
      }
      
      const teamPasswordValid = await bcrypt.compare(teamPassword, team.teamPassword);
      if (!teamPasswordValid) {
        return res.status(401).json({ message: "Invalid team password" });
      }
      
      // Check if user is already a member of this team
      const isAlreadyMember = await storage.isUserInTeam(req.user.id, team.id);
      if (isAlreadyMember) {
        return res.status(400).json({ message: "You are already a member of this team" });
      }
      
      // Check if username already exists in team
      const existingUsername = await storage.getUserByUsername(team.id, req.user.username);
      if (existingUsername && existingUsername.id !== req.user.id) {
        return res.status(400).json({ message: "Username already exists in this team" });
      }
      
      // Add user to team in userTeams junction table
      await storage.addUserToTeam(req.user.id, team.id, "teamsafe_member");
      
      // Update user's active team (backward compatibility with users.teamId)
      const updatedUser = await storage.updateUserTeam(req.user.id, team.id);
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to join team" });
      }
      
      // Initialize safety status for this team
      await storage.updateSafetyStatus(team.id, req.user.id, { status: "safe", location: null });
      
      console.log(`✅ User ${updatedUser.email} joined team ${team.name} (code: ${team.teamCode})`);
      
      // Set the active team in session
      setActiveTeam(req, team.id);
      
      const safeUser = safeUserData(updatedUser);
      res.json({ 
        message: "Successfully joined team", 
        user: safeUser,
        team: {
          id: team.id,
          name: team.name,
          teamCode: team.teamCode,
          description: team.description
        }
      });
    } catch (error) {
      console.error("Error joining team:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to join team" });
    }
  });

  // Team management routes
  app.post('/api/teams/create', isAuthenticated, async (req: any, res) => {
    try {
      const teamData = createTeamSchema.parse(req.body);
      
      // Hash the team password
      const hashedPassword = await bcrypt.hash(teamData.teamPassword, 12);
      
      const team = await storage.createTeam({
        ...teamData,
        teamPassword: hashedPassword,
      });
      
      console.log(`✅ Team created: ${team.name} (code: ${team.teamCode})`);
      
      // Add creator to the team in userTeams table
      await storage.addUserToTeam(req.user.id, team.id, "duty_manager");
      
      // Update user's active team (backward compatibility)
      await storage.updateUserTeam(req.user.id, team.id);
      
      // Initialize safety status for the creator
      await storage.updateSafetyStatus(team.id, req.user.id, { status: "safe", location: null });
      
      // Set the newly created team as active
      setActiveTeam(req, team.id);
      
      // Return team data with teamCode (for sharing) but without password hash
      res.status(201).json({
        id: team.id,
        name: team.name,
        teamCode: team.teamCode,
        description: team.description,
        createdAt: team.createdAt,
      });
    } catch (error) {
      console.error("Error creating team:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create team" });
    }
  });

  app.get('/api/teams/search', isAuthenticated, async (req: any, res) => {
    try {
      const { query } = searchTeamsSchema.parse(req.query);
      
      console.log(`🔍 Team search: query="${query}" by user=${req.user?.id}`);
      
      const teams = await storage.searchTeamsByDescription(query);
      
      console.log(`🔍 Team search results: found ${teams.length} teams for query "${query}"`);
      
      // Return team data without password hashes or sensitive codes
      const safeTeams = teams.map(team => ({
        id: team.id,
        name: team.name,
        description: team.description,
        createdAt: team.createdAt,
      }));
      
      res.json(safeTeams);
    } catch (error) {
      console.error("Error searching teams:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid search query", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to search teams" });
    }
  });

  app.get('/api/teams/current', isAuthenticated, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.id);
      if (!user || !user.teamId) {
        return res.status(404).json({ message: "User or team not found" });
      }
      
      const team = await storage.getTeam(user.teamId);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      
      // Return team data with teamCode (for sharing) but without password hash
      res.json({
        id: team.id,
        name: team.name,
        teamCode: team.teamCode,
        description: team.description,
        createdAt: team.createdAt,
      });
    } catch (error) {
      console.error("Error fetching current team:", error);
      res.status(500).json({ message: "Failed to fetch team" });
    }
  });

  // Get user's team memberships
  app.get('/api/teams/memberships', isAuthenticated, async (req: any, res) => {
    try {
      const memberships = await storage.getUserTeamMemberships(req.user.id);
      
      // Return memberships with team data including teamCode (for sharing)
      const safeMemberships = memberships.map(m => ({
        id: m.id,
        userId: m.userId,
        teamId: m.teamId,
        role: m.role,
        createdAt: m.createdAt,
        team: {
          id: m.team.id,
          name: m.team.name,
          teamCode: m.team.teamCode,
          description: m.team.description,
          createdAt: m.team.createdAt,
        },
        isActive: m.teamId === req.user.teamId, // Mark if this is the active team
      }));
      
      res.json(safeMemberships);
    } catch (error) {
      console.error("Error fetching team memberships:", error);
      res.status(500).json({ message: "Failed to fetch team memberships" });
    }
  });

  // Switch active team
  app.post('/api/teams/switch', isAuthenticated, async (req: any, res) => {
    try {
      const { teamId } = req.body;
      
      if (!teamId) {
        return res.status(400).json({ message: "Team ID is required" });
      }
      
      // Verify user is a member of this team
      const isMember = await storage.isUserInTeam(req.user.id, teamId);
      if (!isMember) {
        return res.status(403).json({ message: "You are not a member of this team" });
      }
      
      // Update user's active team
      const updatedUser = await storage.updateUserTeam(req.user.id, teamId);
      if (!updatedUser) {
        return res.status(500).json({ message: "Failed to switch team" });
      }
      
      // Set the active team in session
      setActiveTeam(req, teamId);
      
      // Get team details
      const team = await storage.getTeam(teamId);
      
      console.log(`✅ User ${updatedUser.email} switched to team ${team?.name}`);
      
      res.json({ 
        message: "Team switched successfully", 
        user: safeUserData(updatedUser),
        team: team ? {
          id: team.id,
          name: team.name,
          description: team.description,
        } : null
      });
    } catch (error) {
      console.error("Error switching team:", error);
      res.status(500).json({ message: "Failed to switch team" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
