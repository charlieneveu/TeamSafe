import { storage } from "./storage";

interface SafetyCheckScheduler {
  lastProcessedDate: string | null;
  reminderSentUsers: Set<string>;
  gracePeriodNotificationSent: Set<string>;
  dailyResetCompleted: boolean;
}

let scheduler: SafetyCheckScheduler = {
  lastProcessedDate: null,
  reminderSentUsers: new Set(),
  gracePeriodNotificationSent: new Set(),
  dailyResetCompleted: false
};

const FOUR_PM_HOUR = 16; // 4:00 PM in 24-hour format
const GRACE_PERIOD_HOUR = 16; // 4:20 PM in 24-hour format  
const GRACE_PERIOD_MINUTE = 20;

export function startSafetyReminderScheduler() {
  console.log("🕐 Starting 4pm safety reminder scheduler");
  
  // Check every minute for 4pm and 4:30pm deadlines
  setInterval(async () => {
    await checkSafetyReminders();
  }, 60 * 1000); // Check every minute
}

function getUKDateString(date: Date): string {
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/London',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(date).split('/').reverse().join('-');
}

async function checkSafetyReminders() {
  const now = new Date();
  const currentDateString = getUKDateString(now);
  
  // Get UK timezone time for accurate scheduling
  const ukTime = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Europe/London',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  }).formatToParts(now);
  
  const currentHour = parseInt(ukTime.find(part => part.type === 'hour')?.value || '0');
  const currentMinute = parseInt(ukTime.find(part => part.type === 'minute')?.value || '0');
  
  // Reset daily tracking and perform team status reset when date changes
  if (scheduler.lastProcessedDate !== currentDateString) {
    // Only perform daily reset during early morning hours (00:00-06:00) to prevent midday resets on app restart
    const isEarlyMorning = currentHour >= 0 && currentHour < 6;
    
    if (isEarlyMorning && !scheduler.dailyResetCompleted) {
      // Set flags BEFORE awaiting to prevent reentrancy race condition
      scheduler.dailyResetCompleted = true;
      scheduler.lastProcessedDate = currentDateString;
      
      await performDailyTeamStatusReset();
    } else if (!isEarlyMorning) {
      // If it's not early morning, just update the date tracking without reset
      scheduler.lastProcessedDate = currentDateString;
      scheduler.dailyResetCompleted = false;
    }
    
    // Clear daily reminder tracking regardless of reset
    scheduler.reminderSentUsers.clear();
    scheduler.gracePeriodNotificationSent.clear();
    console.log("🕐 Daily safety reminder tracking reset");
  }
  
  // Check for 4:00 PM reminder (check every minute from 4:00-4:05 to ensure we don't miss it)
  if (currentHour === FOUR_PM_HOUR && currentMinute >= 0 && currentMinute <= 5) {
    await sendFourPMReminders();
  }
  
  // Check for 4:20 PM grace period notification (check every minute from 4:20-4:25)
  if (currentHour === GRACE_PERIOD_HOUR && currentMinute >= GRACE_PERIOD_MINUTE && currentMinute <= GRACE_PERIOD_MINUTE + 5) {
    await sendGracePeriodNotifications();
  }
}

async function sendFourPMReminders() {
  try {
    // Get all users
    const allUsers = await storage.getAllUsers();
    
    for (const user of allUsers) {
      // Skip if already sent reminder today
      if (scheduler.reminderSentUsers.has(user.id)) {
        continue;
      }
      
      // ONLY send reminders to users who have started visits
      const activeVisit = await storage.getActiveVisitByClinicianId(user.id);
      if (!activeVisit) {
        continue; // Skip users who haven't started visits
      }
      
      // Check if user has checked in as safe today (UK date)
      const userSafetyStatus = await storage.getSafetyStatus(user.id);
      const today = getUKDateString(new Date());
      const lastUpdateToday = userSafetyStatus?.lastUpdate && 
        getUKDateString(new Date(userSafetyStatus.lastUpdate)) === today;
      
      // If user hasn't checked in as safe today, send reminder
      if (!lastUpdateToday || userSafetyStatus?.status !== "safe") {
        await logReminderToUser(user);
        scheduler.reminderSentUsers.add(user.id);
        console.log(`📧 4pm reminder sent to ${user.firstName || user.email} (has active visit)`);
      }
    }
  } catch (error) {
    console.error("Error sending 4pm reminders:", error);
  }
}

async function sendGracePeriodNotifications() {
  try {
    // Get all users and duty managers
    const allUsers = await storage.getAllUsers();
    const dutyManagers = allUsers.filter((u: any) => u.role === "duty_manager");
    
    // Check all users with active visits who haven't marked themselves safe after 4pm UK time
    for (const user of allUsers) {
      // Only check users who have active visits (same logic as 4pm reminders)
      const activeVisit = await storage.getActiveVisitByClinicianId(user.id);
      if (!activeVisit) {
        continue;
      }
      
      // Skip if already sent grace period notification today
      if (scheduler.gracePeriodNotificationSent.has(user.id)) {
        continue;
      }
      
      // Check if user has checked in as safe since 4pm UK time today
      const userSafetyStatus = await storage.getSafetyStatus(user.id);
      const today = getUKDateString(new Date());
      const lastUpdateToday = userSafetyStatus?.lastUpdate && 
        getUKDateString(new Date(userSafetyStatus.lastUpdate)) === today;
      
      // Check if last update was after 4pm UK time
      const lastUpdateAfter4PM = userSafetyStatus?.lastUpdate && (() => {
        const updateTime = new Date(userSafetyStatus.lastUpdate);
        const ukTimeParts = new Intl.DateTimeFormat('en-GB', {
          timeZone: 'Europe/London',
          hour: '2-digit',
          minute: '2-digit',
          hour12: false
        }).formatToParts(updateTime);
        
        const ukHour = parseInt(ukTimeParts.find(part => part.type === 'hour')?.value || '0');
        const ukMinute = parseInt(ukTimeParts.find(part => part.type === 'minute')?.value || '0');
        
        return ukHour > FOUR_PM_HOUR || (ukHour === FOUR_PM_HOUR && ukMinute >= 0);
      })();
      
      // If user still hasn't checked in as safe after 4pm UK time, notify duty managers
      if (!lastUpdateToday || userSafetyStatus?.status !== "safe" || !lastUpdateAfter4PM) {
        await notifyDutyManagersAboutOverdueUser(user, dutyManagers);
        scheduler.gracePeriodNotificationSent.add(user.id);
        console.log(`⚠️ Grace period notification sent for ${user.firstName || user.email} (has active visit)`);
      }
    }
  } catch (error) {
    console.error("Error sending grace period notifications:", error);
  }
}

async function logReminderToUser(user: any) {
  // Log safety reminder (Teams integration removed)
  try {
    const userName = user.firstName && user.lastName ? `${user.firstName} ${user.lastName}` : user.firstName || 'Team Member';
    const userEmail = user.email || 'unknown@teamsafe.com';
    
    console.log(`⏰ Safety reminder needed for ${userName} (${userEmail})`);
    
  } catch (error) {
    console.error(`Error logging reminder for user ${user.id}:`, error);
  }
}

async function notifyDutyManagersAboutOverdueUser(user: any, dutyManagers: any[]) {
  // Create alert for overdue user (Teams integration removed)
  try {
    const userName = user.firstName && user.lastName ? `${user.firstName} ${user.lastName}` : user.firstName || 'Team Member';
    const userEmail = user.email || 'unknown@teamsafe.com';
    
    // Create alert in the system instead of Teams notification
    await storage.createAlert({
      clinicianId: user.id,
      type: "safety_overdue",
      title: "Safety Check Overdue",
      description: `${userName} has not marked themselves as safe after their safety reminder. Please contact them to verify their wellbeing.`,
      priority: "high",
      severity: "red"
    });
    
    console.log(`⚠️ Safety overdue alert created for ${userName} (${userEmail}). ${dutyManagers.length} duty managers can see this alert.`);
    
  } catch (error) {
    console.error(`Error creating overdue alert for user ${user.id}:`, error);
  }
}

async function performDailyTeamStatusReset() {
  try {
    console.log("🌅 Starting daily team status reset");
    
    let usersReset = 0;
    let visitsCompleted = 0;
    let alertsResolved = 0;
    
    // Get all users
    const allUsers = await storage.getAllUsers();
    
    // STEP 1: Complete any active visits FIRST (before resetting safety status)
    // This prevents visit completion from overriding the offline status
    const uniqueActiveVisitIds = new Set<string>();
    for (const user of allUsers) {
      try {
        const activeVisit = await storage.getActiveVisitByClinicianId(user.id);
        if (activeVisit) {
          uniqueActiveVisitIds.add(activeVisit.id);
        }
      } catch (error) {
        console.error(`❌ Failed to get active visit for user ${user.id}:`, error);
      }
    }
    
    // Complete all unique active visits
    const visitIdsArray = Array.from(uniqueActiveVisitIds);
    for (const visitId of visitIdsArray) {
      try {
        await storage.updateVisitStatus(visitId, "completed", new Date());
        visitsCompleted++;
        console.log(`✅ Completed active visit ${visitId} for daily reset`);
      } catch (error) {
        console.error(`❌ Failed to complete visit ${visitId}:`, error);
      }
    }
    
    // STEP 2: Reset safety status for all users to safe (after completing visits)
    for (const user of allUsers) {
      try {
        await storage.updateSafetyStatus(user.id, {
          status: "safe",
          location: null
        });
        usersReset++;
        console.log(`🔄 Reset safety status for ${user.firstName || user.email} to safe`);
      } catch (error) {
        console.error(`❌ Failed to reset safety status for user ${user.id}:`, error);
      }
    }
    
    // Clear old safety alerts (resolve safety_reminder and safety_overdue alerts from previous days)
    const today = getUKDateString(new Date());
    const allAlerts = await storage.getUnresolvedAlerts();
    const alertsToResolve = allAlerts.filter((alert: any) => 
      alert.type === "safety_reminder" || 
      (alert.type === "safety_overdue" && getUKDateString(new Date(alert.createdAt)) !== today)
    );
    
    for (const alert of alertsToResolve) {
      try {
        await storage.markAlertAsResolved(alert.id);
        alertsResolved++;
        console.log(`🗑️ Resolved old safety alert ${alert.id} during reset`);
      } catch (error) {
        console.error(`❌ Failed to resolve alert ${alert.id}:`, error);
      }
    }
    
    console.log(`🌟 Daily team status reset completed successfully - ${usersReset}/${allUsers.length} users reset, ${visitsCompleted} visits completed, ${alertsResolved}/${alertsToResolve.length} alerts resolved`);
    
  } catch (error) {
    console.error("❌ Error during daily team status reset:", error);
  }
}